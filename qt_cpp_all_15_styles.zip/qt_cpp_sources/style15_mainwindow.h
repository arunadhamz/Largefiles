// Style 15: Left Tabs (Vertical QTabWidget) — Tabs stacked vertically on the left, West position
#ifndef STYLE15_MAINWINDOW_H
#define STYLE15_MAINWINDOW_H
#include <QMainWindow>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include <QStatusBar>
#include "theme_engine.h"
#include "pages.h"

class Style15MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style15MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Vertical Tabs");
        resize(1100, 700);
        m_comm = new CommBackend(this);

        // QTabWidget with West (left vertical) tab position
        auto *tabs = new QTabWidget;
        tabs->setTabPosition(QTabWidget::West);
        tabs->setStyleSheet(
            "QTabWidget::pane { border: none; border-left: 2px solid #3b82f6; }"
            "QTabBar::tab { width: 120px; padding: 14px 8px; font-size: 11px; text-align: left; "
            "    border: none; border-right: 3px solid transparent; }"
            "QTabBar::tab:selected { border-right: 3px solid #3b82f6; background: rgba(59,130,246,0.1); font-weight: bold; }"
            "QTabBar::tab:hover:!selected { background: rgba(59,130,246,0.05); }");

        QStringList names={"🏠 Home","🔌 Init","💡 PBIT","✅ Self Test","▶ Auto Mode","🔧 Manual","👥 Users","ℹ About"};
        QWidget *pages[] = { new HomePage, new InitPage(m_comm), new PBITPage(m_comm), new SelfTestPage(m_comm),
            new AutoModePage(m_comm), new ManualModePage(m_comm), new UserManagementPage, new AboutPage };
        for (int i = 0; i < 8; i++) tabs->addTab(pages[i], names[i]);

        // Menu bar with theme
        auto *viewMenu = menuBar()->addMenu("&View");
        auto *themeMenu = viewMenu->addMenu("Theme");
        QStringList themes={"Midnight","Arctic","Ember","Forest","Cyber"};
        for(int i=0;i<themes.size();i++)
            themeMenu->addAction(themes[i],[i]{ThemeEngine::apply((ThemeEngine::Theme)i);});
        menuBar()->addMenu("&Help")->addAction("About",[tabs]{tabs->setCurrentIndex(7);});

        setCentralWidget(tabs);
        auto *sb = new QStatusBar;
        sb->showMessage("Test System v2.0 | Style: Vertical Tabs | Connection: None");
        setStatusBar(sb);
    }
private:
    CommBackend *m_comm;
};
#endif
