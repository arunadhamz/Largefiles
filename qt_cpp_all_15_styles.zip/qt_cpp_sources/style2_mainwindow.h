#ifndef STYLE2_MAINWINDOW_H
#define STYLE2_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include <QDockWidget>
#include <QListWidget>
#include <QTreeWidget>
#include <QTabWidget>
#include <QSplitter>
#include <QToolButton>
#include <QButtonGroup>
#include <QPropertyAnimation>
#include <QGraphicsDropShadowEffect>
#include <QScrollArea>
#include <QProgressBar>
#include <QToolBox>
#include "theme_engine.h"
#include "pages.h"


class Style2MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style2MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Ribbon Toolbar");
        resize(1100, 700);
        setCentralWidget(new QWidget);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        // === MENU BAR (File, Edit, View, Help) ===
        auto *fileMenu = menuBar()->addMenu("&File");
        fileMenu->addAction("Export Report...");
        fileMenu->addSeparator();
        fileMenu->addAction("Exit", this, &QWidget::close);
        auto *viewMenu = menuBar()->addMenu("&View");
        viewMenu->addAction("Fullscreen", this, [this]{ isFullScreen() ? showNormal() : showFullScreen(); });
        menuBar()->addMenu("&Help")->addAction("About Qt", qApp, &QApplication::aboutQt);

        // === RIBBON (QTabWidget with tool buttons inside each tab) ===
        auto *ribbon = new QTabWidget;
        ribbon->setFixedHeight(100);
        ribbon->setStyleSheet(
            "QTabWidget::pane { border: 1px solid palette(mid); border-top: none; padding: 4px; }"
            "QTabBar::tab { padding: 6px 18px; font-weight: bold; min-width: 80px; }"
            "QTabBar::tab:selected { background: palette(base); }"
        );

        QStringList navItems = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        for (int i = 0; i < navItems.size(); i++) {
            auto *tabContent = new QWidget;
            auto *tabLayout = new QHBoxLayout(tabContent);
            tabLayout->setContentsMargins(8, 4, 8, 4);

            // Each ribbon tab has relevant tool buttons
            auto *goBtn = new QToolButton;
            goBtn->setText("Open\n" + navItems[i]);
            goBtn->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
            goBtn->setIconSize(QSize(32, 32));
            goBtn->setFixedSize(70, 60);
            goBtn->setStyleSheet("QToolButton { border: 1px solid transparent; border-radius: 4px; padding: 4px; }"
                                 "QToolButton:hover { border: 1px solid palette(mid); background: rgba(59,130,246,0.1); }");
            connect(goBtn, &QToolButton::clicked, this, [this, i]{ m_stack->setCurrentIndex(i); });
            tabLayout->addWidget(goBtn);

            // Separator line
            auto *sep = new QFrame;
            sep->setFrameShape(QFrame::VLine);
            sep->setStyleSheet("color: palette(mid);");
            tabLayout->addWidget(sep);

            // Quick action buttons per tab
            if (i == 0) { // Home
                auto *refresh = new QToolButton; refresh->setText("Refresh"); tabLayout->addWidget(refresh);
            } else if (i == 2) { // PBIT
                auto *req = new QToolButton; req->setText("Send\nRequest"); req->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
                req->setFixedSize(60, 60); tabLayout->addWidget(req);
                auto *clr = new QToolButton; clr->setText("Clear\nStatus"); clr->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
                clr->setFixedSize(60, 60); tabLayout->addWidget(clr);
            } else if (i == 4) { // Auto
                auto *start = new QToolButton; start->setText("Start"); tabLayout->addWidget(start);
                auto *stop = new QToolButton; stop->setText("Stop"); tabLayout->addWidget(stop);
                auto *rep = new QToolButton; rep->setText("Report"); tabLayout->addWidget(rep);
            }
            tabLayout->addStretch();
            ribbon->addTab(tabContent, navItems[i]);
        }
        connect(ribbon, &QTabWidget::currentChanged, this, [this](int idx){ m_stack->setCurrentIndex(idx); });

        // === ASSEMBLE: ribbon on top, stack below, status bar bottom ===
        auto *mainLayout = new QVBoxLayout;
        mainLayout->setContentsMargins(0, 0, 0, 0);
        mainLayout->setSpacing(0);
        mainLayout->addWidget(ribbon);
        mainLayout->addWidget(m_stack, 1);
        centralWidget()->setLayout(mainLayout);

        auto *sb = statusBar();
        sb->showMessage("Style 2: Ribbon Toolbar | Ready");
        
        auto *themeCombo = new QComboBox;
        themeCombo->addItems({"Midnight", "Arctic", "Ember", "Forest", "Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [](int idx){
            ThemeEngine::apply(static_cast<ThemeEngine::Theme>(idx));
        });
        sb->addPermanentWidget(themeCombo);
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
};

#endif
