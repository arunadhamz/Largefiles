// ═══════════════════════════════════════════════════════════════
// Style 2: Ribbon Toolbar
// Microsoft Office-style ribbon with tabbed toolbar groups
// ═══════════════════════════════════════════════════════════════

#ifndef STYLE2_MAINWINDOW_H
#define STYLE2_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include "theme_engine.h"
#include "pages.h"

class Style2MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style2MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Ribbon Toolbar");
        resize(1100, 700);
        setCentralWidget(new QWidget);

        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;

        // Add all pages
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        
        // Ribbon-style toolbar
        auto *mainLayout = new QVBoxLayout;
        mainLayout->setContentsMargins(0, 0, 0, 0);
        mainLayout->setSpacing(0);

        auto *ribbon = new QTabWidget;
        ribbon->setFixedHeight(90);
        QStringList navItems = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        for (int i = 0; i < navItems.size(); i++) {
            auto *tab = new QWidget;
            auto *tabLayout = new QHBoxLayout(tab);
            auto *navBtn = new QPushButton("Open " + navItems[i]);
            connect(navBtn, &QPushButton::clicked, this, [this, i]{ m_stack->setCurrentIndex(i); });
            tabLayout->addWidget(navBtn);
            tabLayout->addStretch();
            ribbon->addTab(tab, navItems[i]);
        }
        connect(ribbon, &QTabWidget::currentChanged, this, [this](int idx){ m_stack->setCurrentIndex(idx); });
        mainLayout->addWidget(ribbon);
        mainLayout->addWidget(m_stack);

        auto *statusBar = new QStatusBar;
        statusBar->showMessage("Ready | Disconnected");
        setStatusBar(statusBar);
        centralWidget()->setLayout(mainLayout);

        // Apply default theme
        ThemeEngine::apply(ThemeEngine::Midnight);
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
    QVector<QPushButton*> m_navButtons;
    QLabel *m_breadcrumb = nullptr;
};

#endif // STYLE2_MAINWINDOW_H
