QT += core gui widgets serialport network
CONFIG += c++17

TARGET = TestSystem
TEMPLATE = app

HEADERS += \
    common_types.h \
    theme_engine.h \
    pages.h \
    style_selector.h \
    style1_mainwindow.h \
    style2_mainwindow.h \
    style3_mainwindow.h \
    style4_mainwindow.h \
    style5_mainwindow.h \
    style6_mainwindow.h \
    style7_mainwindow.h \
    style8_mainwindow.h \
    style9_mainwindow.h \
    style10_mainwindow.h \
    style11_mainwindow.h \
    style12_mainwindow.h \
    style13_mainwindow.h \
    style14_mainwindow.h \
    style15_mainwindow.h

SOURCES += main.cpp
