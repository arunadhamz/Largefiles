#ifndef PAGES_H
#define PAGES_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QSpinBox>
#include <QTableWidget>
#include <QGroupBox>
#include <QCheckBox>
#include <QHeaderView>
#include <QMessageBox>
#include <QTimer>
#include <QInputDialog>
#include <QFileDialog>
#include <QTextStream>
#include "common_types.h"

// ─── Login Page ───
class LoginPage : public QWidget {
    Q_OBJECT
public:
    explicit LoginPage(QWidget *parent = nullptr) : QWidget(parent) {
        auto *layout = new QVBoxLayout(this);
        layout->setAlignment(Qt::AlignCenter);

        auto *card = new QFrame;
        card->setFixedWidth(360);
        card->setObjectName("loginCard");
        card->setStyleSheet("QFrame#loginCard { border: 1px solid palette(mid); border-radius: 8px; padding: 24px; }");
        auto *cl = new QVBoxLayout(card);
        cl->setSpacing(12);

        auto *logo = new QLabel("⬡");
        logo->setAlignment(Qt::AlignCenter);
        logo->setStyleSheet("font-size: 48px;");
        cl->addWidget(logo);

        auto *title = new QLabel("System Login");
        title->setAlignment(Qt::AlignCenter);
        title->setStyleSheet("font-size: 20px; font-weight: bold;");
        cl->addWidget(title);

        cl->addWidget(new QLabel("Username:"));
        m_username = new QLineEdit;
        m_username->setPlaceholderText("Enter username");
        cl->addWidget(m_username);

        cl->addWidget(new QLabel("Password:"));
        m_password = new QLineEdit;
        m_password->setPlaceholderText("Enter password");
        m_password->setEchoMode(QLineEdit::Password);
        cl->addWidget(m_password);

        auto *btnLayout = new QHBoxLayout;
        auto *loginBtn = new QPushButton("Login");
        auto *cancelBtn = new QPushButton("Cancel");
        cancelBtn->setObjectName("secondary");
        connect(loginBtn, &QPushButton::clicked, this, &LoginPage::onLogin);
        connect(cancelBtn, &QPushButton::clicked, this, [this]{ m_username->clear(); m_password->clear(); });
        btnLayout->addWidget(loginBtn);
        btnLayout->addWidget(cancelBtn);
        cl->addLayout(btnLayout);

        m_status = new QLabel;
        m_status->setAlignment(Qt::AlignCenter);
        cl->addWidget(m_status);

        layout->addWidget(card);
    }

signals:
    void loginSuccess(const QString &username);

private slots:
    void onLogin() {
        if (UserManager::authenticate(m_username->text(), m_password->text())) {
            emit loginSuccess(m_username->text());
        } else {
            m_status->setText("Invalid credentials");
            m_status->setStyleSheet("color: #ef4444;");
        }
    }

private:
    QLineEdit *m_username, *m_password;
    QLabel *m_status;
};

// ─── Home Page ───
class HomePage : public QWidget {
    Q_OBJECT
public:
    explicit HomePage(QWidget *parent = nullptr) : QWidget(parent) {
        auto *layout = new QGridLayout(this);
        layout->setSpacing(12);

        struct Card { QString title; QString value; QString color; };
        QVector<Card> cards = {
            {"System Status", "ONLINE", "#22c55e"},
            {"Active Tests", "0/12", "#3b82f6"},
            {"Pass Rate", "—", "#22c55e"},
            {"Uptime", "0h 0m", "#3b82f6"},
            {"Connection", "Disconnected", "#f59e0b"},
            {"Last PBIT", "Never", "#64748b"}
        };

        for (int i = 0; i < cards.size(); i++) {
            auto *group = new QGroupBox(cards[i].title);
            auto *gl = new QVBoxLayout(group);
            auto *val = new QLabel(cards[i].value);
            val->setStyleSheet(QString("font-size: 24px; font-weight: bold; color: %1;").arg(cards[i].color));
            val->setAlignment(Qt::AlignCenter);
            gl->addWidget(val);
            layout->addWidget(group, i / 3, i % 3);
        }
    }
};

// ─── Initialization Page ───
class InitPage : public QWidget {
    Q_OBJECT
public:
    explicit InitPage(CommBackend *comm, QWidget *parent = nullptr)
        : QWidget(parent), m_comm(comm) {
        auto *layout = new QVBoxLayout(this);
        layout->setSpacing(16);

        // Ethernet Group
        auto *ethGroup = new QGroupBox("Ethernet Configuration");
        auto *ethGrid = new QGridLayout(ethGroup);
        ethGrid->addWidget(new QLabel("IP Address:"), 0, 0);
        m_ip = new QLineEdit("192.168.1.100"); ethGrid->addWidget(m_ip, 0, 1);
        ethGrid->addWidget(new QLabel("Port:"), 0, 2);
        m_port = new QSpinBox; m_port->setRange(1, 65535); m_port->setValue(5000);
        ethGrid->addWidget(m_port, 0, 3);
        ethGrid->addWidget(new QLabel("Subnet:"), 1, 0);
        m_subnet = new QLineEdit("255.255.255.0"); ethGrid->addWidget(m_subnet, 1, 1);
        ethGrid->addWidget(new QLabel("Gateway:"), 1, 2);
        m_gateway = new QLineEdit("192.168.1.1"); ethGrid->addWidget(m_gateway, 1, 3);
        auto *ethBtn = new QPushButton("Connect Ethernet");
        connect(ethBtn, &QPushButton::clicked, this, &InitPage::connectEthernet);
        ethGrid->addWidget(ethBtn, 2, 0, 1, 2);
        m_ethStatus = new QLabel("Disconnected");
        m_ethStatus->setStyleSheet("color: #f59e0b;");
        ethGrid->addWidget(m_ethStatus, 2, 2, 1, 2);
        layout->addWidget(ethGroup);

        // UART Group
        auto *uartGroup = new QGroupBox("UART Configuration");
        auto *uartGrid = new QGridLayout(uartGroup);
        uartGrid->addWidget(new QLabel("COM Port:"), 0, 0);
        m_comPort = new QComboBox;
        for (const auto &info : QSerialPortInfo::availablePorts())
            m_comPort->addItem(info.portName());
        if (m_comPort->count() == 0) m_comPort->addItem("No ports found");
        uartGrid->addWidget(m_comPort, 0, 1);
        uartGrid->addWidget(new QLabel("Baud Rate:"), 0, 2);
        m_baudRate = new QComboBox;
        m_baudRate->addItems({"9600","19200","38400","57600","115200","230400","460800","921600"});
        m_baudRate->setCurrentText("115200");
        uartGrid->addWidget(m_baudRate, 0, 3);
        uartGrid->addWidget(new QLabel("Channel:"), 1, 0);
        m_channel = new QComboBox;
        m_channel->addItems({"CH0","CH1","CH2","CH3"});
        uartGrid->addWidget(m_channel, 1, 1);
        uartGrid->addWidget(new QLabel("Data Bits:"), 1, 2);
        auto *dataBits = new QComboBox; dataBits->addItems({"5","6","7","8"}); dataBits->setCurrentText("8");
        uartGrid->addWidget(dataBits, 1, 3);
        auto *uartBtn = new QPushButton("Connect UART");
        connect(uartBtn, &QPushButton::clicked, this, &InitPage::connectUart);
        uartGrid->addWidget(uartBtn, 2, 0, 1, 2);
        m_uartStatus = new QLabel("Disconnected");
        m_uartStatus->setStyleSheet("color: #f59e0b;");
        uartGrid->addWidget(m_uartStatus, 2, 2, 1, 2);
        layout->addWidget(uartGroup);
        layout->addStretch();
    }

private slots:
    void connectEthernet() {
        if (m_comm->connectEthernet(m_ip->text(), m_port->value())) {
            m_ethStatus->setText("Connected");
            m_ethStatus->setStyleSheet("color: #22c55e;");
        } else {
            m_ethStatus->setText("Connection Failed");
            m_ethStatus->setStyleSheet("color: #ef4444;");
        }
    }
    void connectUart() {
        int ch = m_channel->currentText().mid(2).toInt();
        if (m_comm->connectUart(m_comPort->currentText(), m_baudRate->currentText().toInt(), ch)) {
            m_uartStatus->setText("Connected");
            m_uartStatus->setStyleSheet("color: #22c55e;");
        } else {
            m_uartStatus->setText("Connection Failed");
            m_uartStatus->setStyleSheet("color: #ef4444;");
        }
    }

private:
    CommBackend *m_comm;
    QLineEdit *m_ip, *m_subnet, *m_gateway;
    QSpinBox *m_port;
    QComboBox *m_comPort, *m_baudRate, *m_channel;
    QLabel *m_ethStatus, *m_uartStatus;
};

// ─── PBIT Page ───
class PBITPage : public QWidget {
    Q_OBJECT
public:
    explicit PBITPage(CommBackend *comm, QWidget *parent = nullptr)
        : QWidget(parent), m_comm(comm) {
        auto *layout = new QVBoxLayout(this);

        auto *group = new QGroupBox("Power-on Built-In Test Status");
        auto *grid = new QGridLayout(group);

        QStringList components = {"Processor", "DDR Memory", "Flash Storage",
            "FPGA Core", "Ethernet PHY", "UART Controller",
            "DMA Engine", "Interrupt Controller", "Watchdog Timer", "Clock PLL"};

        for (int i = 0; i < components.size(); i++) {
            grid->addWidget(new QLabel(components[i]), i, 0);
            auto *led = new QLabel("●");
            led->setObjectName("led_off");
            led->setStyleSheet("font-size: 18px; color: #334155;");
            led->setAlignment(Qt::AlignCenter);
            m_leds.append(led);
            grid->addWidget(led, i, 1);
            auto *statusLabel = new QLabel("NOT TESTED");
            statusLabel->setStyleSheet("color: #64748b; font-size: 11px;");
            m_statusLabels.append(statusLabel);
            grid->addWidget(statusLabel, i, 2);
        }
        layout->addWidget(group);

        auto *btnLayout = new QHBoxLayout;
        auto *reqBtn = new QPushButton("Send PBIT Request");
        auto *refreshBtn = new QPushButton("Refresh Status");
        refreshBtn->setObjectName("secondary");
        connect(reqBtn, &QPushButton::clicked, this, &PBITPage::sendRequest);
        connect(refreshBtn, &QPushButton::clicked, this, &PBITPage::refreshStatus);
        btnLayout->addWidget(reqBtn);
        btnLayout->addWidget(refreshBtn);
        btnLayout->addStretch();
        layout->addLayout(btnLayout);
        layout->addStretch();

        connect(m_comm, &CommBackend::dataReceived, this, &PBITPage::onDataReceived);
    }

private slots:
    void sendRequest() {
        m_comm->sendCommand("PBIT_REQUEST\n");
        for (auto *led : m_leds) {
            led->setStyleSheet("font-size: 18px; color: #f59e0b;");
        }
        for (auto *lbl : m_statusLabels)
            lbl->setText("TESTING...");
    }

    void refreshStatus() {
        m_comm->sendCommand("PBIT_STATUS\n");
    }

    void onDataReceived(const QByteArray &data) {
        // Parse response: "PBIT:0=PASS,1=PASS,2=FAIL,..."
        QString resp = QString::fromUtf8(data).trimmed();
        if (!resp.startsWith("PBIT:")) return;
        QStringList results = resp.mid(5).split(",");
        for (int i = 0; i < qMin(results.size(), m_leds.size()); i++) {
            QStringList kv = results[i].split("=");
            if (kv.size() == 2) {
                int idx = kv[0].toInt();
                if (idx >= 0 && idx < m_leds.size()) {
                    bool pass = (kv[1] == "PASS");
                    m_leds[idx]->setStyleSheet(
                        QString("font-size: 18px; color: %1;").arg(pass ? "#22c55e" : "#ef4444"));
                    m_statusLabels[idx]->setText(pass ? "PASS" : "FAIL");
                    m_statusLabels[idx]->setStyleSheet(
                        QString("color: %1; font-size: 11px;").arg(pass ? "#22c55e" : "#ef4444"));
                }
            }
        }
    }

private:
    CommBackend *m_comm;
    QVector<QLabel*> m_leds;
    QVector<QLabel*> m_statusLabels;
};

// ─── Self Test Page ───
class SelfTestPage : public QWidget {
    Q_OBJECT
public:
    explicit SelfTestPage(CommBackend *comm, QWidget *parent = nullptr)
        : QWidget(parent), m_comm(comm) {
        auto *layout = new QVBoxLayout(this);

        auto *group = new QGroupBox("Self Test Suite");
        auto *gl = new QVBoxLayout(group);

        QStringList tests = {"CPU Core Test", "Cache L1/L2 Test", "Memory Bus Test",
            "IO Port Test", "Watchdog Test", "Timer Test", "Interrupt Test"};

        for (const auto &test : tests) {
            auto *row = new QHBoxLayout;
            auto *led = new QLabel("●");
            led->setStyleSheet("font-size: 16px; color: #334155;");
            auto *name = new QLabel(test);
            auto *status = new QLabel("PENDING");
            status->setStyleSheet("color: #64748b;");
            status->setFixedWidth(80);
            row->addWidget(led);
            row->addWidget(name, 1);
            row->addWidget(status);
            gl->addLayout(row);
            m_testLeds.append(led);
            m_testStatuses.append(status);
        }
        layout->addWidget(group);

        auto *btn = new QPushButton("Run Self Test");
        connect(btn, &QPushButton::clicked, this, [this]{
            m_comm->sendCommand("SELF_TEST_RUN\n");
            for (int i = 0; i < m_testLeds.size(); i++) {
                m_testLeds[i]->setStyleSheet("font-size: 16px; color: #f59e0b;");
                m_testStatuses[i]->setText("RUNNING...");
            }
        });
        layout->addWidget(btn);
        layout->addStretch();
    }

private:
    CommBackend *m_comm;
    QVector<QLabel*> m_testLeds, m_testStatuses;
};

// ─── Auto Mode Page ───
class AutoModePage : public QWidget {
    Q_OBJECT
public:
    explicit AutoModePage(CommBackend *comm, QWidget *parent = nullptr)
        : QWidget(parent), m_comm(comm), m_running(false) {
        auto *layout = new QVBoxLayout(this);

        // Controls
        auto *ctrlLayout = new QHBoxLayout;
        ctrlLayout->addWidget(new QLabel("Delay (ms):"));
        m_delay = new QSpinBox; m_delay->setRange(100, 60000); m_delay->setValue(500);
        ctrlLayout->addWidget(m_delay);
        m_startBtn = new QPushButton("Start");
        m_stopBtn = new QPushButton("Stop"); m_stopBtn->setStyleSheet("background: #ef4444;");
        m_stopBtn->setEnabled(false);
        auto *reportBtn = new QPushButton("Generate Report");
        reportBtn->setObjectName("secondary");
        connect(m_startBtn, &QPushButton::clicked, this, &AutoModePage::startAuto);
        connect(m_stopBtn, &QPushButton::clicked, this, &AutoModePage::stopAuto);
        connect(reportBtn, &QPushButton::clicked, this, &AutoModePage::generateReport);
        ctrlLayout->addWidget(m_startBtn);
        ctrlLayout->addWidget(m_stopBtn);
        ctrlLayout->addWidget(reportBtn);
        ctrlLayout->addStretch();
        layout->addLayout(ctrlLayout);

        // Test table
        m_table = new QTableWidget;
        m_table->setColumnCount(6);
        m_table->setHorizontalHeaderLabels({"Select", "Test Name", "Status", "Major Cycle", "Minor Cycle", "Duration"});
        m_table->horizontalHeader()->setStretchLastSection(true);
        m_table->setSelectionBehavior(QAbstractItemView::SelectRows);

        QStringList testNames = {"ALU Arithmetic", "FPU Operations", "DMA Transfer",
            "IRQ Handling", "Memory RW", "Cache Coherency", "Bus Arbitration",
            "Watchdog Response", "Timer Accuracy", "IO Loopback"};

        m_table->setRowCount(testNames.size());
        for (int i = 0; i < testNames.size(); i++) {
            auto *cb = new QCheckBox;
            m_table->setCellWidget(i, 0, cb);
            m_table->setItem(i, 1, new QTableWidgetItem(testNames[i]));
            m_table->setItem(i, 2, new QTableWidgetItem("—"));
            m_table->setItem(i, 3, new QTableWidgetItem("0"));
            m_table->setItem(i, 4, new QTableWidgetItem("0"));
            m_table->setItem(i, 5, new QTableWidgetItem("—"));
        }
        layout->addWidget(m_table);

        m_timer = new QTimer(this);
        connect(m_timer, &QTimer::timeout, this, &AutoModePage::runNextTest);
    }

private slots:
    void startAuto() {
        m_running = true;
        m_startBtn->setEnabled(false);
        m_stopBtn->setEnabled(true);
        m_currentTest = -1;
        m_timer->start(m_delay->value());
    }

    void stopAuto() {
        m_running = false;
        m_timer->stop();
        m_startBtn->setEnabled(true);
        m_stopBtn->setEnabled(false);
    }

    void runNextTest() {
        m_currentTest++;
        while (m_currentTest < m_table->rowCount()) {
            auto *cb = qobject_cast<QCheckBox*>(m_table->cellWidget(m_currentTest, 0));
            if (cb && cb->isChecked()) break;
            m_currentTest++;
        }
        if (m_currentTest >= m_table->rowCount()) {
            stopAuto();
            return;
        }
        m_table->item(m_currentTest, 2)->setText("RUNNING");
        QString cmd = QString("AUTO_TEST:%1\n").arg(m_table->item(m_currentTest, 1)->text());
        m_comm->sendCommand(cmd.toUtf8());
    }

    void generateReport() {
        QString path = QFileDialog::getSaveFileName(this, "Save Report", "", "CSV (*.csv);;Text (*.txt)");
        if (path.isEmpty()) return;
        QFile f(path);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream ts(&f);
            ts << "Test Name,Status,Major Cycle,Minor Cycle,Duration\n";
            for (int i = 0; i < m_table->rowCount(); i++) {
                auto *cb = qobject_cast<QCheckBox*>(m_table->cellWidget(i, 0));
                if (cb && cb->isChecked()) {
                    ts << m_table->item(i, 1)->text() << ","
                       << m_table->item(i, 2)->text() << ","
                       << m_table->item(i, 3)->text() << ","
                       << m_table->item(i, 4)->text() << ","
                       << m_table->item(i, 5)->text() << "\n";
                }
            }
            f.close();
            QMessageBox::information(this, "Report", "Report saved to:\n" + path);
        }
    }

private:
    CommBackend *m_comm;
    QTableWidget *m_table;
    QSpinBox *m_delay;
    QPushButton *m_startBtn, *m_stopBtn;
    QTimer *m_timer;
    bool m_running;
    int m_currentTest = -1;
};

// ─── Manual Mode Page ───
class ManualModePage : public QWidget {
    Q_OBJECT
public:
    explicit ManualModePage(CommBackend *comm, QWidget *parent = nullptr)
        : QWidget(parent), m_comm(comm) {
        auto *layout = new QVBoxLayout(this);

        // Processor Unit Selection
        auto *unitGroup = new QGroupBox("Select Processor Unit");
        auto *unitLayout = new QHBoxLayout(unitGroup);
        m_aluBtn = new QPushButton("ALU");
        m_fpuBtn = new QPushButton("FPU");
        m_fpuBtn->setObjectName("secondary");
        connect(m_aluBtn, &QPushButton::clicked, this, [this]{ selectUnit("ALU"); });
        connect(m_fpuBtn, &QPushButton::clicked, this, [this]{ selectUnit("FPU"); });
        unitLayout->addWidget(m_aluBtn);
        unitLayout->addWidget(m_fpuBtn);
        unitLayout->addStretch();
        layout->addWidget(unitGroup);

        // Operations
        m_opsGroup = new QGroupBox("ALU Operations");
        m_opsGrid = new QGridLayout(m_opsGroup);
        layout->addWidget(m_opsGroup);

        // Result
        auto *resGroup = new QGroupBox("Test Result");
        auto *resLayout = new QVBoxLayout(resGroup);
        m_result = new QLabel("No test run yet");
        m_result->setStyleSheet("font-size: 16px; font-weight: bold; padding: 8px;");
        m_result->setAlignment(Qt::AlignCenter);
        resLayout->addWidget(m_result);
        layout->addWidget(resGroup);

        layout->addStretch();
        selectUnit("ALU");
    }

private:
    void selectUnit(const QString &unit) {
        m_currentUnit = unit;
        // Clear old buttons
        QLayoutItem *item;
        while ((item = m_opsGrid->takeAt(0)) != nullptr) {
            delete item->widget();
            delete item;
        }

        QStringList ops;
        if (unit == "ALU") {
            ops = {"ADD", "SUB", "MUL", "DIV", "AND", "OR", "XOR", "NOT", "SHIFT_L", "SHIFT_R", "ROL", "ROR"};
            m_opsGroup->setTitle("ALU Operations");
            m_aluBtn->setObjectName("");
            m_fpuBtn->setObjectName("secondary");
        } else {
            ops = {"FADD", "FSUB", "FMUL", "FDIV", "FSQRT", "FABS", "FSIN", "FCOS", "FTAN", "FLOG", "FEXP", "FPOW"};
            m_opsGroup->setTitle("FPU Operations");
            m_fpuBtn->setObjectName("");
            m_aluBtn->setObjectName("secondary");
        }
        m_aluBtn->style()->unpolish(m_aluBtn); m_aluBtn->style()->polish(m_aluBtn);
        m_fpuBtn->style()->unpolish(m_fpuBtn); m_fpuBtn->style()->polish(m_fpuBtn);

        for (int i = 0; i < ops.size(); i++) {
            auto *btn = new QPushButton(ops[i]);
            btn->setObjectName("secondary");
            connect(btn, &QPushButton::clicked, this, [this, op=ops[i]]{
                m_result->setText("Running " + m_currentUnit + "::" + op + "...");
                m_result->setStyleSheet("font-size: 16px; font-weight: bold; color: #f59e0b; padding: 8px;");
                QString cmd = QString("MANUAL:%1:%2\n").arg(m_currentUnit, op);
                m_comm->sendCommand(cmd.toUtf8());
            });
            m_opsGrid->addWidget(btn, i / 4, i % 4);
        }
    }

    CommBackend *m_comm;
    QPushButton *m_aluBtn, *m_fpuBtn;
    QGroupBox *m_opsGroup;
    QGridLayout *m_opsGrid;
    QLabel *m_result;
    QString m_currentUnit = "ALU";
};

// ─── User Management Page ───
class UserManagementPage : public QWidget {
    Q_OBJECT
public:
    explicit UserManagementPage(QWidget *parent = nullptr) : QWidget(parent) {
        auto *layout = new QVBoxLayout(this);

        auto *btnLayout = new QHBoxLayout;
        auto *addBtn = new QPushButton("Add User");
        auto *removeBtn = new QPushButton("Remove User");
        removeBtn->setStyleSheet("background: #ef4444;");
        auto *renameBtn = new QPushButton("Rename User");
        renameBtn->setObjectName("secondary");
        connect(addBtn, &QPushButton::clicked, this, &UserManagementPage::addUser);
        connect(removeBtn, &QPushButton::clicked, this, &UserManagementPage::removeUser);
        connect(renameBtn, &QPushButton::clicked, this, &UserManagementPage::renameUser);
        btnLayout->addWidget(addBtn);
        btnLayout->addWidget(removeBtn);
        btnLayout->addWidget(renameBtn);
        btnLayout->addStretch();
        layout->addLayout(btnLayout);

        m_table = new QTableWidget;
        m_table->setColumnCount(3);
        m_table->setHorizontalHeaderLabels({"Username", "Role", "Last Login"});
        m_table->horizontalHeader()->setStretchLastSection(true);
        m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
        m_table->setSelectionMode(QAbstractItemView::SingleSelection);
        layout->addWidget(m_table);

        refreshTable();
    }

private slots:
    void addUser() {
        bool ok;
        QString name = QInputDialog::getText(this, "Add User", "Username:", QLineEdit::Normal, "", &ok);
        if (!ok || name.isEmpty()) return;
        QString pass = QInputDialog::getText(this, "Add User", "Password:", QLineEdit::Password, "", &ok);
        if (!ok || pass.isEmpty()) return;
        QStringList roles = {"Administrator", "Operator", "Read-Only"};
        QString role = QInputDialog::getItem(this, "Add User", "Role:", roles, 1, false, &ok);
        if (!ok) return;
        if (UserManager::addUser(name, pass, role))
            refreshTable();
        else
            QMessageBox::warning(this, "Error", "User already exists.");
    }

    void removeUser() {
        int row = m_table->currentRow();
        if (row < 0) return;
        QString name = m_table->item(row, 0)->text();
        if (QMessageBox::question(this, "Confirm", "Remove user '" + name + "'?") == QMessageBox::Yes) {
            UserManager::removeUser(name);
            refreshTable();
        }
    }

    void renameUser() {
        int row = m_table->currentRow();
        if (row < 0) return;
        QString oldName = m_table->item(row, 0)->text();
        bool ok;
        QString newName = QInputDialog::getText(this, "Rename", "New name:", QLineEdit::Normal, oldName, &ok);
        if (ok && !newName.isEmpty()) {
            UserManager::renameUser(oldName, newName);
            refreshTable();
        }
    }

private:
    void refreshTable() {
        auto users = UserManager::loadUsers();
        m_table->setRowCount(users.size());
        for (int i = 0; i < users.size(); i++) {
            m_table->setItem(i, 0, new QTableWidgetItem(users[i].username));
            m_table->setItem(i, 1, new QTableWidgetItem(users[i].role));
            m_table->setItem(i, 2, new QTableWidgetItem(users[i].lastLogin));
        }
    }

    QTableWidget *m_table;
};

// ─── About Page ───
class AboutPage : public QWidget {
    Q_OBJECT
public:
    explicit AboutPage(QWidget *parent = nullptr) : QWidget(parent) {
        auto *layout = new QVBoxLayout(this);
        layout->setAlignment(Qt::AlignCenter);

        auto *logo = new QLabel("⬡");
        logo->setAlignment(Qt::AlignCenter);
        logo->setStyleSheet("font-size: 64px;");
        layout->addWidget(logo);

        auto *title = new QLabel("Test System Application");
        title->setAlignment(Qt::AlignCenter);
        title->setStyleSheet("font-size: 22px; font-weight: bold;");
        layout->addWidget(title);

        auto *group = new QGroupBox("Application Info");
        auto *grid = new QGridLayout(group);
        group->setFixedWidth(400);

        QVector<QPair<QString,QString>> info = {
            {"Version", "2.0.1"},
            {"Build Date", __DATE__},
            {"Build Time", __TIME__},
            {"Qt Version", QT_VERSION_STR},
            {"Compiler", 
#ifdef __GNUC__
            QString("GCC %1.%2").arg(__GNUC__).arg(__GNUC_MINOR__)
#elif defined(_MSC_VER)
            QString("MSVC %1").arg(_MSC_VER)
#else
            "Unknown"
#endif
            },
            {"App Checksum", "Calculating..."}
        };

        for (int i = 0; i < info.size(); i++) {
            auto *key = new QLabel(info[i].first + ":");
            key->setStyleSheet("color: #64748b;");
            grid->addWidget(key, i, 0);
            auto *val = new QLabel(info[i].second);
            val->setStyleSheet("font-family: monospace;");
            if (info[i].first == "App Checksum") m_checksumLabel = val;
            grid->addWidget(val, i, 1);
        }
        layout->addWidget(group, 0, Qt::AlignCenter);

        auto *verifyBtn = new QPushButton("Verify Checksum");
        connect(verifyBtn, &QPushButton::clicked, this, [this]{
            m_checksumLabel->setText(AppChecksum::calculate());
        });
        layout->addWidget(verifyBtn, 0, Qt::AlignCenter);
        layout->addStretch();

        // Auto-calculate on show
        QTimer::singleShot(500, this, [this]{ m_checksumLabel->setText(AppChecksum::calculate()); });
    }

private:
    QLabel *m_checksumLabel = nullptr;
};

#endif // PAGES_H
