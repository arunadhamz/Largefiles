#ifndef THEME_ENGINE_H
#define THEME_ENGINE_H

#include <QApplication>
#include <QFile>
#include <QMap>
#include <QString>

class ThemeEngine {
public:
    enum Theme { Midnight, Arctic, Ember, Forest, Cyber };

    static void apply(Theme theme) {
        QString qss;
        switch (theme) {
        case Midnight:
            qss = R"(
                * { font-family: 'Segoe UI', sans-serif; }
                QMainWindow, QDialog { background: #0a0e1a; color: #e2e8f0; }
                QWidget { background: transparent; color: #e2e8f0; }
                QFrame#sidebar { background: #111827; border-right: 1px solid #1e293b; }
                QFrame#header { background: #111827; border-bottom: 1px solid #1e293b; }
                QPushButton { background: #3b82f6; color: white; border: none; border-radius: 4px; padding: 8px 16px; font-weight: bold; }
                QPushButton:hover { background: #60a5fa; }
                QPushButton:pressed { background: #2563eb; }
                QPushButton#secondary { background: #1a2035; color: #e2e8f0; border: 1px solid #1e293b; }
                QLineEdit, QComboBox, QSpinBox { background: #1a2035; border: 1px solid #1e293b; border-radius: 4px; padding: 6px 10px; color: #e2e8f0; }
                QLineEdit:focus, QComboBox:focus { border-color: #3b82f6; }
                QTableWidget { background: #111827; gridline-color: #1e293b; border: 1px solid #1e293b; }
                QTableWidget::item { padding: 4px 8px; }
                QTableWidget::item:selected { background: rgba(59,130,246,0.2); }
                QHeaderView::section { background: #1a2035; color: #64748b; border: none; padding: 6px 8px; font-weight: bold; }
                QLabel#led_pass { color: #22c55e; }
                QLabel#led_fail { color: #ef4444; }
                QLabel#led_off { color: #334155; }
                QGroupBox { border: 1px solid #1e293b; border-radius: 6px; margin-top: 12px; padding-top: 16px; }
                QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 6px; color: #64748b; }
                QTabWidget::pane { border: 1px solid #1e293b; background: #111827; }
                QTabBar::tab { background: #1a2035; color: #64748b; padding: 8px 16px; border: 1px solid #1e293b; }
                QTabBar::tab:selected { background: #111827; color: #3b82f6; border-bottom: 2px solid #3b82f6; }
                QScrollBar:vertical { background: #0a0e1a; width: 8px; }
                QScrollBar::handle:vertical { background: #1e293b; border-radius: 4px; }
                QStatusBar { background: #111827; color: #64748b; border-top: 1px solid #1e293b; }
                QProgressBar { background: #1a2035; border: 1px solid #1e293b; border-radius: 4px; text-align: center; }
                QProgressBar::chunk { background: #3b82f6; border-radius: 3px; }
            )";
            break;
        case Arctic:
            qss = R"(
                * { font-family: 'Segoe UI', sans-serif; }
                QMainWindow, QDialog { background: #f0f4f8; color: #1e293b; }
                QWidget { background: transparent; color: #1e293b; }
                QFrame#sidebar { background: #ffffff; border-right: 1px solid #cbd5e1; }
                QFrame#header { background: #ffffff; border-bottom: 1px solid #cbd5e1; }
                QPushButton { background: #0369a1; color: white; border: none; border-radius: 4px; padding: 8px 16px; font-weight: bold; }
                QPushButton:hover { background: #0284c7; }
                QPushButton#secondary { background: #e8eef4; color: #1e293b; border: 1px solid #cbd5e1; }
                QLineEdit, QComboBox, QSpinBox { background: #ffffff; border: 1px solid #cbd5e1; border-radius: 4px; padding: 6px 10px; color: #1e293b; }
                QTableWidget { background: #ffffff; gridline-color: #cbd5e1; border: 1px solid #cbd5e1; }
                QHeaderView::section { background: #e8eef4; color: #64748b; border: none; padding: 6px 8px; }
                QGroupBox { border: 1px solid #cbd5e1; border-radius: 6px; }
                QGroupBox::title { color: #64748b; }
                QTabBar::tab { background: #e8eef4; color: #64748b; padding: 8px 16px; }
                QTabBar::tab:selected { background: #ffffff; color: #0369a1; border-bottom: 2px solid #0369a1; }
            )";
            break;
        case Ember:
            qss = R"(
                * { font-family: 'Segoe UI', sans-serif; }
                QMainWindow, QDialog { background: #1a0a0a; color: #fce4e4; }
                QWidget { background: transparent; color: #fce4e4; }
                QFrame#sidebar { background: #2a1010; border-right: 1px solid #4a2020; }
                QPushButton { background: #ef4444; color: white; border: none; border-radius: 4px; padding: 8px 16px; }
                QPushButton:hover { background: #f87171; }
                QPushButton#secondary { background: #3a1515; color: #fce4e4; border: 1px solid #4a2020; }
                QLineEdit, QComboBox { background: #3a1515; border: 1px solid #4a2020; color: #fce4e4; border-radius: 4px; padding: 6px 10px; }
                QTableWidget { background: #2a1010; gridline-color: #4a2020; }
                QHeaderView::section { background: #3a1515; color: #b07070; }
            )";
            break;
        case Forest:
            qss = R"(
                * { font-family: 'Segoe UI', sans-serif; }
                QMainWindow, QDialog { background: #0a1a0a; color: #d4f4d4; }
                QWidget { background: transparent; color: #d4f4d4; }
                QFrame#sidebar { background: #0f2010; border-right: 1px solid #1a4a1a; }
                QPushButton { background: #22c55e; color: white; border: none; border-radius: 4px; padding: 8px 16px; }
                QPushButton:hover { background: #4ade80; }
                QPushButton#secondary { background: #153018; color: #d4f4d4; border: 1px solid #1a4a1a; }
                QLineEdit, QComboBox { background: #153018; border: 1px solid #1a4a1a; color: #d4f4d4; border-radius: 4px; padding: 6px 10px; }
                QTableWidget { background: #0f2010; gridline-color: #1a4a1a; }
                QHeaderView::section { background: #153018; color: #6b9b6b; }
            )";
            break;
        case Cyber:
            qss = R"(
                * { font-family: 'Segoe UI', sans-serif; }
                QMainWindow, QDialog { background: #0a000f; color: #e8d5f5; }
                QWidget { background: transparent; color: #e8d5f5; }
                QFrame#sidebar { background: #150020; border-right: 1px solid #30104a; }
                QPushButton { background: #a855f7; color: white; border: none; border-radius: 4px; padding: 8px 16px; }
                QPushButton:hover { background: #c084fc; }
                QPushButton#secondary { background: #200030; color: #e8d5f5; border: 1px solid #30104a; }
                QLineEdit, QComboBox { background: #200030; border: 1px solid #30104a; color: #e8d5f5; border-radius: 4px; padding: 6px 10px; }
                QTableWidget { background: #150020; gridline-color: #30104a; }
                QHeaderView::section { background: #200030; color: #9060b0; }
            )";
            break;
        }
        qApp->setStyleSheet(qss);
    }
};

#endif // THEME_ENGINE_H
