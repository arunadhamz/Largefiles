// ═══════════════════════════════════════════════════════════════
// Style Selector Dialog
// Shows a visual grid of all 15 styles for the user to pick
// ═══════════════════════════════════════════════════════════════

#ifndef STYLE_SELECTOR_H
#define STYLE_SELECTOR_H

#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QScrollArea>
#include <QFrame>
#include <QGroupBox>
#include <QMouseEvent>
#include <QPainter>
#include "theme_engine.h"

// ─── Clickable Style Card ───
class StyleCard : public QFrame {
    Q_OBJECT
public:
    StyleCard(int id, const QString &name, const QString &desc, 
              const QString &navType, QWidget *parent = nullptr)
        : QFrame(parent), m_id(id), m_name(name), m_selected(false)
    {
        setFixedSize(220, 160);
        setCursor(Qt::PointingHandCursor);
        setFrameStyle(QFrame::Box);
        setLineWidth(2);
        updateStyle();

        auto *layout = new QVBoxLayout(this);
        layout->setContentsMargins(10, 8, 10, 8);
        layout->setSpacing(4);

        // Mini layout preview
        auto *preview = new QFrame;
        preview->setFixedHeight(70);
        preview->setStyleSheet("background: rgba(128,128,128,0.1); border: 1px solid rgba(128,128,128,0.2); border-radius: 4px;");
        auto *previewLayout = new QHBoxLayout(preview);
        previewLayout->setContentsMargins(4, 4, 4, 4);
        previewLayout->setSpacing(2);

        // Draw a simple layout hint based on nav type
        if (navType == "sidebar" || navType == "icon-sidebar") {
            auto *side = new QFrame;
            side->setFixedWidth(navType == "icon-sidebar" ? 16 : 40);
            side->setStyleSheet("background: rgba(59,130,246,0.3); border-radius: 2px;");
            previewLayout->addWidget(side);
            auto *content = new QFrame;
            content->setStyleSheet("background: rgba(128,128,128,0.1); border-radius: 2px;");
            previewLayout->addWidget(content);
        } else if (navType == "top-tabs" || navType == "ribbon") {
            auto *inner = new QVBoxLayout;
            inner->setSpacing(2);
            auto *topBar = new QFrame;
            topBar->setFixedHeight(12);
            topBar->setStyleSheet("background: rgba(59,130,246,0.3); border-radius: 2px;");
            inner->addWidget(topBar);
            auto *content = new QFrame;
            content->setStyleSheet("background: rgba(128,128,128,0.1); border-radius: 2px;");
            inner->addWidget(content);
            previewLayout->addLayout(inner);
        } else if (navType == "bottom-bar") {
            auto *inner = new QVBoxLayout;
            inner->setSpacing(2);
            auto *content = new QFrame;
            content->setStyleSheet("background: rgba(128,128,128,0.1); border-radius: 2px;");
            inner->addWidget(content);
            auto *botBar = new QFrame;
            botBar->setFixedHeight(12);
            botBar->setStyleSheet("background: rgba(59,130,246,0.3); border-radius: 2px;");
            inner->addWidget(botBar);
            previewLayout->addLayout(inner);
        } else if (navType == "dual-panel") {
            auto *side1 = new QFrame;
            side1->setFixedWidth(16);
            side1->setStyleSheet("background: rgba(59,130,246,0.3); border-radius: 2px;");
            previewLayout->addWidget(side1);
            auto *content = new QFrame;
            content->setStyleSheet("background: rgba(128,128,128,0.1); border-radius: 2px;");
            previewLayout->addWidget(content);
            auto *side2 = new QFrame;
            side2->setFixedWidth(30);
            side2->setStyleSheet("background: rgba(59,130,246,0.15); border-radius: 2px;");
            previewLayout->addWidget(side2);
        } else {
            auto *content = new QFrame;
            content->setStyleSheet("background: rgba(128,128,128,0.1); border-radius: 2px;");
            previewLayout->addWidget(content);
        }
        layout->addWidget(preview);

        // Style number + name
        auto *header = new QHBoxLayout;
        auto *badge = new QLabel(QString("#%1").arg(id));
        badge->setStyleSheet("background: rgba(59,130,246,0.8); color: white; border-radius: 3px; "
                             "padding: 1px 6px; font-size: 10px; font-weight: bold;");
        badge->setFixedHeight(18);
        header->addWidget(badge);
        auto *nameLabel = new QLabel(name);
        nameLabel->setStyleSheet("font-size: 13px; font-weight: bold;");
        header->addWidget(nameLabel);
        header->addStretch();
        layout->addLayout(header);

        // Description
        auto *descLabel = new QLabel(desc);
        descLabel->setStyleSheet("font-size: 10px; color: rgba(128,128,128,0.9);");
        descLabel->setWordWrap(true);
        layout->addWidget(descLabel);
    }

    int styleId() const { return m_id; }

    void setSelected(bool sel) {
        m_selected = sel;
        updateStyle();
    }

signals:
    void clicked(int id);

protected:
    void mousePressEvent(QMouseEvent *) override {
        emit clicked(m_id);
    }

    void enterEvent(QEvent *) override {
        if (!m_selected)
            setStyleSheet("QFrame { border: 2px solid rgba(59,130,246,0.5); border-radius: 8px; "
                          "background: rgba(59,130,246,0.05); }");
    }

    void leaveEvent(QEvent *) override {
        updateStyle();
    }

private:
    void updateStyle() {
        if (m_selected)
            setStyleSheet("QFrame { border: 2px solid #3b82f6; border-radius: 8px; "
                          "background: rgba(59,130,246,0.1); }");
        else
            setStyleSheet("QFrame { border: 2px solid rgba(128,128,128,0.2); border-radius: 8px; "
                          "background: transparent; }");
    }

    int m_id;
    QString m_name;
    bool m_selected;
};


// ─── Main Style Selector Dialog ───
class StyleSelectorDialog : public QDialog {
    Q_OBJECT
public:
    explicit StyleSelectorDialog(QWidget *parent = nullptr) 
        : QDialog(parent), m_selectedStyle(1), m_selectedTheme(ThemeEngine::Midnight)
    {
        setWindowTitle("Choose Application Style");
        setMinimumSize(800, 620);
        resize(960, 680);

        auto *mainLayout = new QVBoxLayout(this);
        mainLayout->setSpacing(12);

        // Title
        auto *titleLabel = new QLabel("Select Your UI Style");
        titleLabel->setAlignment(Qt::AlignCenter);
        titleLabel->setStyleSheet("font-size: 22px; font-weight: bold; padding: 8px;");
        mainLayout->addWidget(titleLabel);

        auto *subtitleLabel = new QLabel("Choose a layout style and color theme for the application");
        subtitleLabel->setAlignment(Qt::AlignCenter);
        subtitleLabel->setStyleSheet("font-size: 12px; color: gray; margin-bottom: 8px;");
        mainLayout->addWidget(subtitleLabel);

        // Theme selector row
        auto *themeRow = new QHBoxLayout;
        themeRow->addStretch();
        themeRow->addWidget(new QLabel("Color Theme:"));
        m_themeCombo = new QComboBox;
        m_themeCombo->addItems({"Midnight (Dark Blue)", "Arctic (Light)", "Ember (Dark Red)", 
                                "Forest (Dark Green)", "Cyber (Dark Purple)"});
        m_themeCombo->setFixedWidth(200);
        connect(m_themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [this](int idx) {
            m_selectedTheme = static_cast<ThemeEngine::Theme>(idx);
        });
        themeRow->addWidget(m_themeCombo);
        themeRow->addStretch();
        mainLayout->addLayout(themeRow);

        // Scrollable grid of style cards
        auto *scrollArea = new QScrollArea;
        scrollArea->setWidgetResizable(true);
        scrollArea->setFrameShape(QFrame::NoFrame);
        scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        auto *gridWidget = new QWidget;
        m_grid = new QGridLayout(gridWidget);
        m_grid->setSpacing(12);
        m_grid->setContentsMargins(12, 8, 12, 8);

        // Define all 15 styles
        struct StyleInfo { int id; QString name; QString desc; QString navType; };
        QVector<StyleInfo> styles = {
            {1,  "Classic Sidebar",   "Traditional sidebar navigation with header bar",         "sidebar"},
            {2,  "Ribbon Toolbar",    "Office-style ribbon with tabbed toolbar groups",         "ribbon"},
            {3,  "Dashboard Grid",    "Grid-based dashboard with top tab navigation",           "top-tabs"},
            {4,  "Compact Sidebar",   "Icon-only collapsed sidebar with tooltips",              "icon-sidebar"},
            {5,  "Top Navigation",    "Horizontal top navigation with inline tabs",             "top-tabs"},
            {6,  "Split Panel",       "Dual-panel layout with resizable splitter",              "sidebar"},
            {7,  "Tab-Centric",       "Browser-style tabs as primary navigation",               "top-tabs"},
            {8,  "Wizard Flow",       "Step-by-step wizard with progress indicator",            "sidebar"},
            {9,  "Terminal Style",    "Command-line inspired monospace aesthetic",               "sidebar"},
            {10, "Material Drawer",   "Material Design hamburger menu with FAB",                "sidebar"},
            {11, "Bottom Tab Bar",    "Mobile-inspired bottom navigation bar",                  "bottom-bar"},
            {12, "Floating Sidebar",  "Detached floating glass-morphism nav panel",             "sidebar"},
            {13, "Command Palette",   "VS Code-style activity bar with search palette",         "icon-sidebar"},
            {14, "Dual Sidebar",      "Icon bar left + detail context panel right",             "dual-panel"},
            {15, "Carousel Nav",      "Full-screen pages with dot indicators",                  "sidebar"},
        };

        for (int i = 0; i < styles.size(); i++) {
            auto *card = new StyleCard(styles[i].id, styles[i].name, 
                                       styles[i].desc, styles[i].navType);
            connect(card, &StyleCard::clicked, this, &StyleSelectorDialog::onStyleClicked);
            m_grid->addWidget(card, i / 4, i % 4);
            m_cards.append(card);
        }
        // Select first by default
        if (!m_cards.isEmpty())
            m_cards[0]->setSelected(true);

        scrollArea->setWidget(gridWidget);
        mainLayout->addWidget(scrollArea, 1);

        // Bottom buttons
        auto *btnLayout = new QHBoxLayout;
        btnLayout->addStretch();

        auto *selectedLabel = new QLabel("Selected: #1 Classic Sidebar");
        selectedLabel->setStyleSheet("font-weight: bold; font-size: 13px;");
        m_selectedLabel = selectedLabel;
        btnLayout->addWidget(selectedLabel);
        btnLayout->addSpacing(20);

        auto *launchBtn = new QPushButton("  Launch Application  ");
        launchBtn->setStyleSheet("QPushButton { background: #3b82f6; color: white; border: none; "
                                 "border-radius: 6px; padding: 12px 32px; font-size: 14px; font-weight: bold; }"
                                 "QPushButton:hover { background: #60a5fa; }");
        connect(launchBtn, &QPushButton::clicked, this, &QDialog::accept);
        btnLayout->addWidget(launchBtn);

        auto *quitBtn = new QPushButton("Quit");
        quitBtn->setStyleSheet("QPushButton { background: rgba(128,128,128,0.2); border: 1px solid rgba(128,128,128,0.3); "
                                "border-radius: 6px; padding: 12px 24px; font-size: 14px; }");
        connect(quitBtn, &QPushButton::clicked, this, &QDialog::reject);
        btnLayout->addWidget(quitBtn);

        btnLayout->addStretch();
        mainLayout->addLayout(btnLayout);
    }

    int selectedStyle() const { return m_selectedStyle; }
    ThemeEngine::Theme selectedTheme() const { return m_selectedTheme; }

private slots:
    void onStyleClicked(int id) {
        m_selectedStyle = id;
        for (auto *card : m_cards)
            card->setSelected(card->styleId() == id);

        // Update label
        for (auto *card : m_cards) {
            if (card->styleId() == id) {
                m_selectedLabel->setText(QString("Selected: #%1").arg(id));
                break;
            }
        }
    }

private:
    int m_selectedStyle;
    ThemeEngine::Theme m_selectedTheme;
    QComboBox *m_themeCombo;
    QGridLayout *m_grid;
    QVector<StyleCard*> m_cards;
    QLabel *m_selectedLabel;
};

#endif // STYLE_SELECTOR_H
