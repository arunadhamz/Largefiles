// Style 9: Material Drawer — Hamburger menu toggles slide-out drawer overlay, FAB button
#ifndef STYLE9_MAINWINDOW_H
#define STYLE9_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include <QGraphicsDropShadowEffect>
#include "theme_engine.h"
#include "pages.h"

class Style9MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style9MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Material Drawer");
        resize(1100, 700);
        auto *central = new QWidget; setCentralWidget(central);
        central->setLayout(new QVBoxLayout);
        central->layout()->setContentsMargins(0,0,0,0);
        central->layout()->setSpacing(0);

        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        // === APP BAR (Material-style colored header) ===
        auto *appBar = new QFrame; appBar->setFixedHeight(56);
        appBar->setStyleSheet("background: #3b82f6;");
        auto *shadow = new QGraphicsDropShadowEffect; shadow->setBlurRadius(12);
        shadow->setColor(QColor(0,0,0,80)); shadow->setOffset(0,2); appBar->setGraphicsEffect(shadow);
        auto *abl = new QHBoxLayout(appBar); abl->setContentsMargins(8,0,16,0);
        // Hamburger button
        auto *menuBtn = new QPushButton("☰");
        menuBtn->setFixedSize(44,44);
        menuBtn->setStyleSheet("QPushButton { font-size: 22px; color: white; background: transparent; border: none; border-radius: 22px; }"
                               "QPushButton:hover { background: rgba(255,255,255,0.15); }");
        connect(menuBtn, &QPushButton::clicked, this, [this]{ toggleDrawer(); });
        abl->addWidget(menuBtn);
        m_titleLabel = new QLabel("Home");
        m_titleLabel->setStyleSheet("font-size: 18px; font-weight: bold; color: white; padding-left: 8px;");
        abl->addWidget(m_titleLabel); abl->addStretch();
        auto *tc = new QComboBox; tc->addItems({"Midnight","Arctic","Ember","Forest","Cyber"});
        tc->setStyleSheet("QComboBox{background:rgba(255,255,255,0.2);color:white;border:none;padding:4px 8px;border-radius:4px;}");
        connect(tc,QOverload<int>::of(&QComboBox::currentIndexChanged),[](int i){ThemeEngine::apply((ThemeEngine::Theme)i);});
        abl->addWidget(tc);
        static_cast<QVBoxLayout*>(central->layout())->addWidget(appBar);

        // === Content area (stack is behind drawer) ===
        auto *contentArea = new QWidget;
        auto *contentLayout = new QVBoxLayout(contentArea);
        contentLayout->setContentsMargins(0,0,0,0);
        contentLayout->addWidget(m_stack);
        static_cast<QVBoxLayout*>(central->layout())->addWidget(contentArea, 1);

        // === DRAWER (overlay, initially hidden) ===
        m_overlay = new QFrame(central);
        m_overlay->setStyleSheet("background: rgba(0,0,0,0.5);");
        m_overlay->hide();
        m_overlay->installEventFilter(this);

        m_drawer = new QFrame(central);
        m_drawer->setFixedWidth(280);
        m_drawer->setStyleSheet("background: palette(window); border-right: 1px solid rgba(128,128,128,0.3);");
        auto *dl = new QVBoxLayout(m_drawer); dl->setContentsMargins(0,0,0,0); dl->setSpacing(0);
        // Drawer header
        auto *dHeader = new QFrame; dHeader->setFixedHeight(120);
        dHeader->setStyleSheet("background: #3b82f6; padding: 16px;");
        auto *dhl = new QVBoxLayout(dHeader); dhl->addStretch();
        auto *userIcon = new QLabel("👤"); userIcon->setStyleSheet("font-size: 36px; color: white;");
        dhl->addWidget(userIcon);
        auto *userName = new QLabel("admin"); userName->setStyleSheet("font-size: 14px; color: white; font-weight: bold;");
        dhl->addWidget(userName);
        dl->addWidget(dHeader);
        // Drawer nav items
        QStringList names = {"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
        QStringList icons = {"🏠","🔌","💡","✅","▶","🔧","👥","ℹ"};
        for (int i = 0; i < names.size(); i++) {
            auto *item = new QPushButton(QString("  %1   %2").arg(icons[i], names[i]));
            item->setStyleSheet("QPushButton { text-align: left; padding: 14px 24px; border: none; font-size: 13px; }"
                "QPushButton:hover { background: rgba(59,130,246,0.1); }");
            connect(item, &QPushButton::clicked, this, [this,i,names]{ 
                m_stack->setCurrentIndex(i); m_titleLabel->setText(names[i]); toggleDrawer(); });
            dl->addWidget(item);
        }
        dl->addStretch();
        m_drawer->hide();

        // === FAB (Floating Action Button) ===
        m_fab = new QPushButton("▶");
        m_fab->setParent(central);
        m_fab->setFixedSize(56,56);
        m_fab->setStyleSheet("QPushButton { background: #3b82f6; color: white; border: none; border-radius: 28px; "
            "font-size: 20px; } QPushButton:hover { background: #60a5fa; }");
        auto *fabShadow = new QGraphicsDropShadowEffect; fabShadow->setBlurRadius(16);
        fabShadow->setColor(QColor(59,130,246,120)); fabShadow->setOffset(0,4);
        m_fab->setGraphicsEffect(fabShadow);
    }
protected:
    void resizeEvent(QResizeEvent *e) override {
        QMainWindow::resizeEvent(e);
        auto *c = centralWidget();
        m_overlay->setGeometry(0, 56, c->width(), c->height()-56);
        m_drawer->setGeometry(0, 56, 280, c->height()-56);
        m_fab->move(c->width()-80, c->height()-80);
    }
    bool eventFilter(QObject *obj, QEvent *e) override {
        if (obj == m_overlay && e->type() == QEvent::MouseButtonPress) { toggleDrawer(); return true; }
        return QMainWindow::eventFilter(obj, e);
    }
private:
    void toggleDrawer() {
        bool show = m_drawer->isHidden();
        m_overlay->setVisible(show); m_drawer->setVisible(show);
        if (show) { m_drawer->raise(); }
    }
    QStackedWidget *m_stack; CommBackend *m_comm;
    QFrame *m_overlay, *m_drawer; QLabel *m_titleLabel; QPushButton *m_fab;
};
#endif
