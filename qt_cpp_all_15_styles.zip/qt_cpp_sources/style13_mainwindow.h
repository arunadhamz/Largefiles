// Style 13: Dual Sidebar — Icon bar LEFT (48px) + Content + Detail panel RIGHT (220px)
#ifndef STYLE13_MAINWINDOW_H
#define STYLE13_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include "theme_engine.h"
#include "pages.h"

class Style13MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style13MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Dual Sidebar");
        resize(1200, 700);
        auto *central = new QWidget; setCentralWidget(central);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        auto *mainLayout = new QHBoxLayout(central);
        mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0);

        // === LEFT ICON BAR (48px) ===
        auto *iconBar = new QFrame; iconBar->setFixedWidth(48);
        iconBar->setStyleSheet("background: rgba(20,20,40,0.95);");
        auto *ibl = new QVBoxLayout(iconBar); ibl->setContentsMargins(0,8,0,8); ibl->setSpacing(4);
        QStringList icons={"🏠","🔌","💡","✅","▶","🔧","👥","ℹ"};
        QStringList names={"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
        for(int i=0;i<icons.size();i++){
            auto *btn=new QPushButton(icons[i]); btn->setFixedSize(48,40); btn->setToolTip(names[i]);
            btn->setStyleSheet("QPushButton{font-size:18px;border:none;}QPushButton:hover{background:rgba(255,255,255,0.1);}");
            connect(btn,&QPushButton::clicked,this,[this,i,names]{m_stack->setCurrentIndex(i);updateAll(i);});
            ibl->addWidget(btn); m_iconBtns.append(btn);
        }
        ibl->addStretch();
        mainLayout->addWidget(iconBar);

        // === CENTER: Header + Content ===
        auto *centerPanel = new QWidget;
        auto *cpl = new QVBoxLayout(centerPanel); cpl->setContentsMargins(0,0,0,0); cpl->setSpacing(0);
        auto *header = new QFrame; header->setObjectName("header"); header->setFixedHeight(48);
        auto *hl = new QHBoxLayout(header); hl->setContentsMargins(16,0,16,0);
        m_title = new QLabel("Home"); m_title->setStyleSheet("font-size: 16px; font-weight: bold;");
        hl->addWidget(m_title); hl->addStretch();
        auto *tc=new QComboBox;tc->addItems({"Midnight","Arctic","Ember","Forest","Cyber"});
        connect(tc,QOverload<int>::of(&QComboBox::currentIndexChanged),[](int i){ThemeEngine::apply((ThemeEngine::Theme)i);});
        hl->addWidget(tc);
        cpl->addWidget(header);
        cpl->addWidget(m_stack, 1);
        mainLayout->addWidget(centerPanel, 1);

        // === RIGHT DETAIL PANEL (220px) ===
        auto *detailPanel = new QFrame; detailPanel->setFixedWidth(220);
        detailPanel->setStyleSheet("border-left: 1px solid rgba(128,128,128,0.2);");
        auto *dpl = new QVBoxLayout(detailPanel); dpl->setContentsMargins(12,12,12,12); dpl->setSpacing(8);
        auto *dpTitle = new QLabel("DETAILS"); dpTitle->setStyleSheet("font-size: 10px; font-weight: bold; color: gray;");
        dpl->addWidget(dpTitle);
        // Context-sensitive detail labels
        m_detailTitle = new QLabel("Home"); m_detailTitle->setStyleSheet("font-size: 14px; font-weight: bold;");
        dpl->addWidget(m_detailTitle);
        m_detailDesc = new QLabel("System overview and status dashboard");
        m_detailDesc->setWordWrap(true); m_detailDesc->setStyleSheet("font-size: 11px; color: gray;");
        dpl->addWidget(m_detailDesc);
        auto *sep = new QFrame; sep->setFixedHeight(1); sep->setStyleSheet("background: rgba(128,128,128,0.2);");
        dpl->addWidget(sep);
        // Quick actions in detail panel
        auto *qaTitle = new QLabel("QUICK ACTIONS"); qaTitle->setStyleSheet("font-size: 10px; font-weight: bold; color: gray; padding-top: 8px;");
        dpl->addWidget(qaTitle);
        for (const auto &action : QStringList{"Refresh","Export","Settings"}) {
            auto *ab = new QPushButton(action); ab->setObjectName("secondary");
            ab->setStyleSheet("QPushButton{padding:6px 12px;font-size:11px;border:1px solid rgba(128,128,128,0.3);border-radius:4px;}"
                "QPushButton:hover{background:rgba(59,130,246,0.1);}");
            dpl->addWidget(ab);
        }
        dpl->addStretch();
        // Connection status in detail panel
        auto *connTitle = new QLabel("CONNECTION"); connTitle->setStyleSheet("font-size:10px;font-weight:bold;color:gray;");
        dpl->addWidget(connTitle);
        auto *connStatus = new QLabel("● Disconnected"); connStatus->setStyleSheet("font-size:11px;color:#f59e0b;");
        dpl->addWidget(connStatus);
        mainLayout->addWidget(detailPanel);

        updateAll(0);
    }
private:
    void updateAll(int idx) {
        QStringList names={"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
        QStringList descs={"System overview and status dashboard","Configure Ethernet and UART connections",
            "Power-on Built-In Test with LED status","Run system self-test diagnostics",
            "Automated test execution with reports","Manual ALU/FPU processor testing",
            "Add, remove, rename user accounts","Application version and checksum"};
        m_title->setText(names[idx]); m_detailTitle->setText(names[idx]); m_detailDesc->setText(descs[idx]);
        for(int i=0;i<m_iconBtns.size();i++)
            m_iconBtns[i]->setStyleSheet(i==idx
                ?"QPushButton{font-size:18px;border:none;border-left:3px solid #3b82f6;background:rgba(59,130,246,0.15);}"
                :"QPushButton{font-size:18px;border:none;}QPushButton:hover{background:rgba(255,255,255,0.1);}");
    }
    QStackedWidget *m_stack; CommBackend *m_comm;
    QVector<QPushButton*> m_iconBtns; QLabel *m_title, *m_detailTitle, *m_detailDesc;
};
#endif
