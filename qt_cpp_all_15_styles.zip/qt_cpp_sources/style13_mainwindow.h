// ═══════════════════════════════════════════════════════════════
// Style 13: Command Palette
// VS Code-style with command palette as primary nav
// ═══════════════════════════════════════════════════════════════

#ifndef STYLE13_MAINWINDOW_H
#define STYLE13_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include "theme_engine.h"
#include "pages.h"

class Style13MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style13MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Command Palette");
        resize(1100, 700);
        setCentralWidget(new QWidget);

        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;

        // Add all pages
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        
        // Compact icon sidebar
        auto *sidebar = new QFrame;
        sidebar->setObjectName("sidebar");
        sidebar->setFixedWidth(56);
        auto *sideLayout = new QVBoxLayout(sidebar);
        sideLayout->setContentsMargins(4, 8, 4, 8);
        sideLayout->setSpacing(8);

        QStringList icons = {"🏠", "⚙", "🔌", "✓", "▶", "🔧", "👥", "ℹ"};
        QStringList tips = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        for (int i = 0; i < icons.size(); i++) {
            auto *btn = new QPushButton(icons[i]);
            btn->setFixedSize(40, 40);
            btn->setToolTip(tips[i]);
            btn->setStyleSheet("font-size: 18px; border-radius: 8px; padding: 0;");
            connect(btn, &QPushButton::clicked, this, [this, i]{ m_stack->setCurrentIndex(i); });
            sideLayout->addWidget(btn);
            m_navButtons.append(btn);
        }
        sideLayout->addStretch();

        auto *header = new QFrame;
        header->setObjectName("header");
        header->setFixedHeight(44);
        auto *headerLayout = new QHBoxLayout(header);
        m_breadcrumb = new QLabel("Home");
        m_breadcrumb->setStyleSheet("font-size: 14px; font-weight: bold;");
        headerLayout->addWidget(m_breadcrumb);
        headerLayout->addStretch();

        auto *mainLayout = new QHBoxLayout;
        mainLayout->setContentsMargins(0, 0, 0, 0);
        mainLayout->setSpacing(0);
        mainLayout->addWidget(sidebar);

        auto *rightPanel = new QVBoxLayout;
        rightPanel->setContentsMargins(0, 0, 0, 0);
        rightPanel->setSpacing(0);
        rightPanel->addWidget(header);
        rightPanel->addWidget(m_stack);
        mainLayout->addLayout(rightPanel);

        centralWidget()->setLayout(mainLayout);

        // Apply default theme
        ThemeEngine::apply(ThemeEngine::Midnight);
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
    QVector<QPushButton*> m_navButtons;
    QLabel *m_breadcrumb = nullptr;
};

#endif // STYLE13_MAINWINDOW_H
