// Style 14: Dashboard Grid — No sidebar, top toolbar, pages shown as grid cards user can click
#ifndef STYLE14_MAINWINDOW_H
#define STYLE14_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include <QScrollArea>
#include "theme_engine.h"
#include "pages.h"

class DashboardCard : public QFrame {
    Q_OBJECT
public:
    DashboardCard(const QString &icon, const QString &title, const QString &desc, QWidget *parent=nullptr)
        : QFrame(parent) {
        setFixedSize(220, 140);
        setCursor(Qt::PointingHandCursor);
        setStyleSheet("QFrame { border: 1px solid rgba(128,128,128,0.2); border-radius: 8px; padding: 16px; }"
                      "QFrame:hover { border-color: #3b82f6; background: rgba(59,130,246,0.05); }");
        auto *l = new QVBoxLayout(this); l->setSpacing(6);
        auto *ic = new QLabel(icon); ic->setStyleSheet("font-size: 28px;"); l->addWidget(ic);
        auto *t = new QLabel(title); t->setStyleSheet("font-size: 14px; font-weight: bold;"); l->addWidget(t);
        auto *d = new QLabel(desc); d->setStyleSheet("font-size: 10px; color: gray;"); d->setWordWrap(true); l->addWidget(d);
        l->addStretch();
    }
signals: void clicked();
protected: void mousePressEvent(QMouseEvent*) override { emit clicked(); }
};

class Style14MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style14MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Dashboard Grid");
        resize(1100, 700);
        auto *central = new QWidget; setCentralWidget(central);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;

        // Page 0 = Dashboard home (grid of cards)
        auto *dashPage = new QWidget;
        auto *dashLayout = new QVBoxLayout(dashPage);
        dashLayout->setContentsMargins(32,24,32,24);
        auto *welcomeLabel = new QLabel("Welcome to Test System");
        welcomeLabel->setStyleSheet("font-size: 24px; font-weight: bold;");
        dashLayout->addWidget(welcomeLabel);
        auto *subLabel = new QLabel("Select a module to get started");
        subLabel->setStyleSheet("font-size: 13px; color: gray; padding-bottom: 16px;");
        dashLayout->addWidget(subLabel);

        auto *grid = new QGridLayout; grid->setSpacing(16);
        QStringList icons={"🏠","🔌","💡","✅","▶","🔧","👥","ℹ"};
        QStringList names={"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
        QStringList descs={"Overview dashboard","Ethernet & UART config","Built-in test status","System diagnostics",
            "Automated testing","Manual ALU/FPU","User accounts","Version & checksum"};
        for (int i = 0; i < 8; i++) {
            auto *card = new DashboardCard(icons[i], names[i], descs[i]);
            connect(card, &DashboardCard::clicked, this, [this,i,names]{ m_stack->setCurrentIndex(i+1); m_backBtn->show(); m_titleLabel->setText(names[i]); });
            grid->addWidget(card, i/4, i%4);
        }
        dashLayout->addLayout(grid);
        dashLayout->addStretch();
        m_stack->addWidget(dashPage);

        // Add actual pages (indices 1-8)
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        auto *mainLayout = new QVBoxLayout(central);
        mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0);

        // Toolbar
        auto *toolbar = new QFrame; toolbar->setObjectName("header"); toolbar->setFixedHeight(48);
        auto *tl = new QHBoxLayout(toolbar); tl->setContentsMargins(16,0,16,0);
        m_backBtn = new QPushButton("← Dashboard");
        m_backBtn->setStyleSheet("QPushButton{border:none;padding:6px 12px;font-size:12px;color:#3b82f6;}QPushButton:hover{background:rgba(59,130,246,0.1);border-radius:4px;}");
        connect(m_backBtn, &QPushButton::clicked, this, [this]{ m_stack->setCurrentIndex(0); m_backBtn->hide(); m_titleLabel->setText("Dashboard"); });
        m_backBtn->hide();
        tl->addWidget(m_backBtn);
        m_titleLabel = new QLabel("Dashboard"); m_titleLabel->setStyleSheet("font-size: 16px; font-weight: bold;");
        tl->addWidget(m_titleLabel); tl->addStretch();
        auto *tc=new QComboBox;tc->addItems({"Midnight","Arctic","Ember","Forest","Cyber"});
        connect(tc,QOverload<int>::of(&QComboBox::currentIndexChanged),[](int i){ThemeEngine::apply((ThemeEngine::Theme)i);});
        tl->addWidget(tc);
        mainLayout->addWidget(toolbar);
        mainLayout->addWidget(m_stack, 1);
    }
private:
    QStackedWidget *m_stack; CommBackend *m_comm;
    QPushButton *m_backBtn; QLabel *m_titleLabel;
};
#endif
