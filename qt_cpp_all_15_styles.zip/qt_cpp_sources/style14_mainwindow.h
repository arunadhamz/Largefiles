// ═══════════════════════════════════════════════════════════════
// Style 14: Dual Sidebar
// Two sidebars: icon bar left, detail panel right
// ═══════════════════════════════════════════════════════════════

#ifndef STYLE14_MAINWINDOW_H
#define STYLE14_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include "theme_engine.h"
#include "pages.h"

class Style14MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style14MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Dual Sidebar");
        resize(1100, 700);
        setCentralWidget(new QWidget);

        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;

        // Add all pages
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        
        // Sidebar
        auto *sidebar = new QFrame;
        sidebar->setObjectName("sidebar");
        sidebar->setFixedWidth(200);
        auto *sideLayout = new QVBoxLayout(sidebar);
        sideLayout->setContentsMargins(8, 16, 8, 16);
        sideLayout->setSpacing(4);

        auto *appTitle = new QLabel("Test System");
        appTitle->setStyleSheet("font-size: 16px; font-weight: bold; padding: 8px;");
        sideLayout->addWidget(appTitle);
        sideLayout->addSpacing(12);

        QStringList navItems = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        for (int i = 0; i < navItems.size(); i++) {
            auto *btn = new QPushButton(navItems[i]);
            btn->setObjectName("secondary");
            btn->setCheckable(true);
            btn->setStyleSheet("text-align: left; padding: 10px 16px; border-radius: 6px;");
            connect(btn, &QPushButton::clicked, this, [this, i]{ m_stack->setCurrentIndex(i); });
            sideLayout->addWidget(btn);
            m_navButtons.append(btn);
        }
        sideLayout->addStretch();

        auto *themeGroup = new QGroupBox("Theme");
        auto *themeLayout = new QVBoxLayout(themeGroup);
        auto *themeCombo = new QComboBox;
        themeCombo->addItems({"Midnight", "Arctic", "Ember", "Forest", "Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [](int idx){
            ThemeEngine::apply(static_cast<ThemeEngine::Theme>(idx));
        });
        themeLayout->addWidget(themeCombo);
        sideLayout->addWidget(themeGroup);

        // Header
        auto *header = new QFrame;
        header->setObjectName("header");
        header->setFixedHeight(48);
        auto *headerLayout = new QHBoxLayout(header);
        m_breadcrumb = new QLabel("Home");
        m_breadcrumb->setStyleSheet("font-size: 14px; font-weight: bold;");
        headerLayout->addWidget(m_breadcrumb);
        headerLayout->addStretch();
        auto *userLabel = new QLabel;
        headerLayout->addWidget(userLabel);

        // Main layout
        auto *mainLayout = new QHBoxLayout;
        mainLayout->setContentsMargins(0, 0, 0, 0);
        mainLayout->setSpacing(0);
        mainLayout->addWidget(sidebar);

        auto *rightPanel = new QVBoxLayout;
        rightPanel->setContentsMargins(0, 0, 0, 0);
        rightPanel->setSpacing(0);
        rightPanel->addWidget(header);
        rightPanel->addWidget(m_stack);
        mainLayout->addLayout(rightPanel);

        centralWidget()->setLayout(mainLayout);

        // Apply default theme
        ThemeEngine::apply(ThemeEngine::Midnight);
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
    QVector<QPushButton*> m_navButtons;
    QLabel *m_breadcrumb = nullptr;
};

#endif // STYLE14_MAINWINDOW_H
