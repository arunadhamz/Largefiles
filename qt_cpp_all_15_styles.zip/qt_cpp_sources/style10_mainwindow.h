// Style 10: Bottom Tab Bar — Mobile-style bottom navigation with icons+labels, minimal header
#ifndef STYLE10_MAINWINDOW_H
#define STYLE10_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include "theme_engine.h"
#include "pages.h"

class Style10MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style10MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Bottom Tab Bar");
        resize(1100, 700);
        auto *central = new QWidget; setCentralWidget(central);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        auto *mainLayout = new QVBoxLayout(central);
        mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0);

        // Minimal header: just title + theme
        auto *header = new QFrame; header->setObjectName("header"); header->setFixedHeight(44);
        auto *hl = new QHBoxLayout(header); hl->setContentsMargins(16,0,16,0);
        m_pageTitle = new QLabel("Home"); m_pageTitle->setStyleSheet("font-size: 18px; font-weight: bold;");
        hl->addWidget(m_pageTitle); hl->addStretch();
        auto *tc = new QComboBox; tc->addItems({"Midnight","Arctic","Ember","Forest","Cyber"});
        connect(tc,QOverload<int>::of(&QComboBox::currentIndexChanged),[](int i){ThemeEngine::apply((ThemeEngine::Theme)i);});
        hl->addWidget(tc);
        mainLayout->addWidget(header);

        // Content
        mainLayout->addWidget(m_stack, 1);

        // === BOTTOM TAB BAR ===
        auto *bottomBar = new QFrame; bottomBar->setObjectName("header"); bottomBar->setFixedHeight(64);
        bottomBar->setStyleSheet("border-top: 1px solid rgba(128,128,128,0.3);");
        auto *bl = new QHBoxLayout(bottomBar); bl->setContentsMargins(0,0,0,0); bl->setSpacing(0);
        QStringList icons = {"🏠","🔌","💡","✅","▶","🔧","👥","ℹ"};
        QStringList names = {"Home","Init","PBIT","Test","Auto","Manual","Users","About"};
        for (int i = 0; i < icons.size(); i++) {
            auto *btn = new QPushButton(icons[i] + "\n" + names[i]);
            btn->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
            btn->setStyleSheet("QPushButton { border: none; font-size: 10px; padding: 4px 0; border-top: 2px solid transparent; }"
                "QPushButton:hover { background: rgba(59,130,246,0.08); }");
            connect(btn, &QPushButton::clicked, this, [this,i,names]{ 
                m_stack->setCurrentIndex(i); 
                QStringList fullNames = {"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
                m_pageTitle->setText(fullNames[i]); 
                updateBottomBar(i); 
            });
            bl->addWidget(btn);
            m_bottomBtns.append(btn);
        }
        mainLayout->addWidget(bottomBar);
        updateBottomBar(0);
    }
private:
    void updateBottomBar(int idx) {
        for (int i = 0; i < m_bottomBtns.size(); i++) {
            m_bottomBtns[i]->setStyleSheet(i == idx
                ? "QPushButton { border: none; font-size: 10px; padding: 4px 0; border-top: 3px solid #3b82f6; color: #3b82f6; font-weight: bold; background: rgba(59,130,246,0.08); }"
                : "QPushButton { border: none; font-size: 10px; padding: 4px 0; border-top: 2px solid transparent; } QPushButton:hover { background: rgba(59,130,246,0.05); }");
        }
    }
    QStackedWidget *m_stack; CommBackend *m_comm;
    QVector<QPushButton*> m_bottomBtns; QLabel *m_pageTitle;
};
#endif
