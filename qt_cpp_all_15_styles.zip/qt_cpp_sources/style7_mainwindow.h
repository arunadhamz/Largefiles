// Style 7: Wizard/Stepper — Horizontal step indicators at top, Next/Back navigation at bottom
#ifndef STYLE7_MAINWINDOW_H
#define STYLE7_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include "theme_engine.h"
#include "pages.h"

class Style7MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style7MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Wizard Flow");
        resize(1100, 700);
        auto *central = new QWidget; setCentralWidget(central);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        auto *mainLayout = new QVBoxLayout(central);
        mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0);

        // Title bar
        auto *titleBar = new QFrame; titleBar->setObjectName("header"); titleBar->setFixedHeight(44);
        auto *tl = new QHBoxLayout(titleBar); tl->setContentsMargins(16,0,16,0);
        tl->addWidget(new QLabel("⬡ Test System — Wizard Mode"));
        tl->addStretch();
        auto *tc = new QComboBox; tc->addItems({"Midnight","Arctic","Ember","Forest","Cyber"});
        connect(tc,QOverload<int>::of(&QComboBox::currentIndexChanged),[](int i){ThemeEngine::apply((ThemeEngine::Theme)i);});
        tl->addWidget(tc);
        mainLayout->addWidget(titleBar);

        // === STEP INDICATOR BAR ===
        m_stepBar = new QFrame; m_stepBar->setFixedHeight(64);
        m_stepBar->setStyleSheet("background: rgba(59,130,246,0.05); border-bottom: 1px solid rgba(128,128,128,0.2);");
        m_stepLayout = new QHBoxLayout(m_stepBar);
        m_stepLayout->setContentsMargins(40,8,40,8);
        QStringList names = {"Home","Init","PBIT","Self Test","Auto","Manual","Users","About"};
        for (int i = 0; i < names.size(); i++) {
            if (i > 0) {
                auto *line = new QFrame; line->setFixedHeight(2); line->setMinimumWidth(20);
                line->setStyleSheet("background: rgba(128,128,128,0.3);");
                line->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
                m_stepLayout->addWidget(line);
                m_lines.append(line);
            }
            auto *stepW = new QWidget;
            auto *sl = new QVBoxLayout(stepW); sl->setSpacing(4); sl->setAlignment(Qt::AlignCenter);
            auto *circle = new QLabel(QString::number(i+1));
            circle->setFixedSize(28,28); circle->setAlignment(Qt::AlignCenter);
            circle->setStyleSheet("border-radius: 14px; background: rgba(128,128,128,0.3); font-size: 12px; font-weight: bold;");
            sl->addWidget(circle, 0, Qt::AlignCenter);
            auto *label = new QLabel(names[i]);
            label->setStyleSheet("font-size: 9px;"); label->setAlignment(Qt::AlignCenter);
            sl->addWidget(label);
            m_stepLayout->addWidget(stepW);
            m_circles.append(circle);
        }
        mainLayout->addWidget(m_stepBar);

        // Content
        mainLayout->addWidget(m_stack, 1);

        // === BOTTOM NAV: Back / Page info / Next ===
        auto *bottomBar = new QFrame; bottomBar->setObjectName("header"); bottomBar->setFixedHeight(52);
        auto *bl = new QHBoxLayout(bottomBar); bl->setContentsMargins(24,0,24,0);
        m_backBtn = new QPushButton("← Back"); m_backBtn->setObjectName("secondary");
        m_backBtn->setFixedWidth(100);
        connect(m_backBtn, &QPushButton::clicked, this, [this]{ goTo(m_stack->currentIndex()-1); });
        bl->addWidget(m_backBtn);
        bl->addStretch();
        m_pageInfo = new QLabel("Step 1 of 8"); m_pageInfo->setStyleSheet("font-size: 12px;");
        bl->addWidget(m_pageInfo);
        bl->addStretch();
        m_nextBtn = new QPushButton("Next →"); m_nextBtn->setFixedWidth(100);
        connect(m_nextBtn, &QPushButton::clicked, this, [this]{ goTo(m_stack->currentIndex()+1); });
        bl->addWidget(m_nextBtn);
        mainLayout->addWidget(bottomBar);

        goTo(0);
    }
private:
    void goTo(int idx) {
        if (idx < 0 || idx >= m_stack->count()) return;
        m_stack->setCurrentIndex(idx);
        m_backBtn->setEnabled(idx > 0);
        m_nextBtn->setEnabled(idx < m_stack->count()-1);
        m_pageInfo->setText(QString("Step %1 of %2").arg(idx+1).arg(m_stack->count()));
        for (int i = 0; i < m_circles.size(); i++) {
            if (i < idx) m_circles[i]->setStyleSheet("border-radius: 14px; background: #22c55e; color: white; font-size: 12px; font-weight: bold;");
            else if (i == idx) m_circles[i]->setStyleSheet("border-radius: 14px; background: #3b82f6; color: white; font-size: 12px; font-weight: bold;");
            else m_circles[i]->setStyleSheet("border-radius: 14px; background: rgba(128,128,128,0.3); font-size: 12px; font-weight: bold;");
        }
        for (int i = 0; i < m_lines.size(); i++) {
            m_lines[i]->setStyleSheet(i < idx ? "background: #22c55e;" : "background: rgba(128,128,128,0.3);");
        }
    }
    QStackedWidget *m_stack; CommBackend *m_comm;
    QFrame *m_stepBar; QHBoxLayout *m_stepLayout;
    QVector<QLabel*> m_circles; QVector<QFrame*> m_lines;
    QPushButton *m_backBtn, *m_nextBtn; QLabel *m_pageInfo;
};
#endif
