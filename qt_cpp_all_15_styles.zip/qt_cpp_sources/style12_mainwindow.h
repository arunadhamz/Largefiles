// Style 12: VS Code Layout — Activity bar (icons) + Explorer panel + Editor area + status bar
#ifndef STYLE12_MAINWINDOW_H
#define STYLE12_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include <QListWidget>
#include <QStatusBar>
#include "theme_engine.h"
#include "pages.h"

class Style12MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style12MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - VS Code Style");
        resize(1100, 700);
        auto *central = new QWidget; setCentralWidget(central);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        auto *mainLayout = new QHBoxLayout(central);
        mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0);

        // === ACTIVITY BAR (48px icon column, far left) ===
        auto *actBar = new QFrame; actBar->setFixedWidth(48);
        actBar->setStyleSheet("background: rgba(30,30,50,0.95); border-right: 1px solid rgba(128,128,128,0.15);");
        auto *abl = new QVBoxLayout(actBar); abl->setContentsMargins(0,4,0,4); abl->setSpacing(0);
        QStringList icons = {"🏠","🔌","💡","✅","▶","🔧","👥","ℹ"};
        for (int i = 0; i < icons.size(); i++) {
            auto *btn = new QPushButton(icons[i]);
            btn->setFixedSize(48,42);
            btn->setStyleSheet("QPushButton{font-size:18px;border:none;border-left:2px solid transparent;}"
                "QPushButton:hover{background:rgba(255,255,255,0.08);}");
            connect(btn, &QPushButton::clicked, this, [this,i]{ m_stack->setCurrentIndex(i); m_explorer->setCurrentRow(i); updateActivity(i); });
            abl->addWidget(btn); m_actBtns.append(btn);
        }
        abl->addStretch();
        // Theme cycle button at bottom
        auto *thBtn = new QPushButton("🎨"); thBtn->setFixedSize(48,42);
        thBtn->setStyleSheet("QPushButton{font-size:16px;border:none;}QPushButton:hover{background:rgba(255,255,255,0.08);}");
        connect(thBtn,&QPushButton::clicked,this,[this]{m_ti=(m_ti+1)%5;ThemeEngine::apply((ThemeEngine::Theme)m_ti);});
        abl->addWidget(thBtn);
        mainLayout->addWidget(actBar);

        // === EXPLORER PANEL (200px, secondary nav) ===
        auto *explorerPanel = new QFrame; explorerPanel->setFixedWidth(200);
        explorerPanel->setStyleSheet("border-right: 1px solid rgba(128,128,128,0.15);");
        auto *epl = new QVBoxLayout(explorerPanel); epl->setContentsMargins(0,0,0,0); epl->setSpacing(0);
        auto *epTitle = new QLabel("  EXPLORER");
        epTitle->setStyleSheet("font-size: 10px; font-weight: bold; color: gray; padding: 10px 8px 6px;");
        epl->addWidget(epTitle);
        m_explorer = new QListWidget;
        m_explorer->setStyleSheet("QListWidget{border:none;font-size:12px;}"
            "QListWidget::item{padding:8px 12px;}"
            "QListWidget::item:selected{background:rgba(59,130,246,0.15);border-left:2px solid #3b82f6;}");
        QStringList names={"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
        m_explorer->addItems(names);
        connect(m_explorer, &QListWidget::currentRowChanged, this, [this](int i){ 
            if(i>=0) { m_stack->setCurrentIndex(i); updateActivity(i); }
        });
        epl->addWidget(m_explorer);
        mainLayout->addWidget(explorerPanel);

        // === EDITOR AREA (main content) ===
        auto *editorArea = new QWidget;
        auto *eal = new QVBoxLayout(editorArea); eal->setContentsMargins(0,0,0,0); eal->setSpacing(0);
        // Tab bar showing open "file"
        auto *tabBar = new QFrame; tabBar->setFixedHeight(32);
        tabBar->setStyleSheet("background: rgba(128,128,128,0.05); border-bottom: 1px solid rgba(128,128,128,0.15);");
        auto *tbl = new QHBoxLayout(tabBar); tbl->setContentsMargins(0,0,0,0);
        m_openTab = new QLabel("  Home"); m_openTab->setFixedHeight(32);
        m_openTab->setStyleSheet("background: transparent; padding: 0 16px; font-size: 12px; border-bottom: 2px solid #3b82f6;");
        tbl->addWidget(m_openTab); tbl->addStretch();
        eal->addWidget(tabBar);
        eal->addWidget(m_stack, 1);
        mainLayout->addWidget(editorArea, 1);

        // Status bar
        auto *sb = new QStatusBar;
        sb->setStyleSheet("QStatusBar { font-size: 11px; }");
        sb->showMessage("Ln 1, Col 1    UTF-8    Style: VS Code    ⬡ TestSystem v2.0");
        setStatusBar(sb);

        updateActivity(0);
    }
private:
    void updateActivity(int idx) {
        QStringList names={"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
        m_openTab->setText("  " + names[idx]);
        for(int i=0;i<m_actBtns.size();i++)
            m_actBtns[i]->setStyleSheet(i==idx
                ? "QPushButton{font-size:18px;border:none;border-left:2px solid #3b82f6;background:rgba(59,130,246,0.1);}"
                : "QPushButton{font-size:18px;border:none;border-left:2px solid transparent;}QPushButton:hover{background:rgba(255,255,255,0.08);}");
    }
    QStackedWidget *m_stack; CommBackend *m_comm;
    QVector<QPushButton*> m_actBtns; QListWidget *m_explorer; QLabel *m_openTab; int m_ti=0;
};
#endif
