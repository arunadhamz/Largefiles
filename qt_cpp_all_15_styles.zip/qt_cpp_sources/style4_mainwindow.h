#ifndef STYLE4_MAINWINDOW_H
#define STYLE4_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include <QDockWidget>
#include <QListWidget>
#include <QTreeWidget>
#include <QTabWidget>
#include <QSplitter>
#include <QToolButton>
#include <QButtonGroup>
#include <QPropertyAnimation>
#include <QGraphicsDropShadowEffect>
#include <QScrollArea>
#include <QProgressBar>
#include <QToolBox>
#include "theme_engine.h"
#include "pages.h"


class Style4MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style4MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Compact Icon Rail");
        resize(1100, 700);
        setCentralWidget(new QWidget);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        // === ICON RAIL (48px wide, icon-only buttons) ===
        auto *rail = new QFrame;
        rail->setObjectName("sidebar");
        rail->setFixedWidth(52);
        auto *railLayout = new QVBoxLayout(rail);
        railLayout->setContentsMargins(4, 8, 4, 8);
        railLayout->setSpacing(6);
        railLayout->setAlignment(Qt::AlignTop | Qt::AlignHCenter);

        // App icon at top
        auto *appIcon = new QLabel("⬡");
        appIcon->setAlignment(Qt::AlignCenter);
        appIcon->setStyleSheet("font-size: 22px; padding: 6px 0;");
        railLayout->addWidget(appIcon);

        auto *topSep = new QFrame; topSep->setFrameShape(QFrame::HLine);
        topSep->setStyleSheet("color: palette(mid);");
        railLayout->addWidget(topSep);

        QStringList navIcons = {"🏠", "🔌", "💡", "✔", "▶", "🔧", "👥", "ℹ"};
        QStringList navTips = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        for (int i = 0; i < navIcons.size(); i++) {
            auto *btn = new QPushButton(navIcons[i]);
            btn->setFixedSize(40, 40);
            btn->setToolTip(navTips[i]);
            btn->setCheckable(true);
            btn->setAutoExclusive(true);
            btn->setStyleSheet(
                "QPushButton { font-size: 18px; border: none; border-radius: 8px; }"
                "QPushButton:checked { background: rgba(59,130,246,0.25); }"
                "QPushButton:hover { background: rgba(59,130,246,0.1); }"
            );
            if (i == 0) btn->setChecked(true);
            connect(btn, &QPushButton::clicked, this, [this, i]{ switchPage(i); });
            railLayout->addWidget(btn, 0, Qt::AlignCenter);
        }
        railLayout->addStretch();

        // Theme button at bottom
        
        auto *themeCombo = new QComboBox;
        themeCombo->addItems({"Midnight", "Arctic", "Ember", "Forest", "Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [](int idx){
            ThemeEngine::apply(static_cast<ThemeEngine::Theme>(idx));
        });
        themeCombo->setFixedWidth(44);
        themeCombo->setStyleSheet("font-size: 9px; padding: 2px;");
        railLayout->addWidget(themeCombo, 0, Qt::AlignCenter);

        // === HEADER with breadcrumb ===
        auto *header = new QFrame;
        header->setObjectName("header");
        header->setFixedHeight(44);
        auto *hLayout = new QHBoxLayout(header);
        hLayout->setContentsMargins(16, 0, 16, 0);
        m_breadcrumb = new QLabel("Home");
        m_breadcrumb->setStyleSheet("font-size: 15px; font-weight: bold;");
        hLayout->addWidget(m_breadcrumb);
        hLayout->addStretch();

        // === ASSEMBLE ===
        auto *mainLayout = new QHBoxLayout;
        mainLayout->setContentsMargins(0,0,0,0);
        mainLayout->setSpacing(0);
        mainLayout->addWidget(rail);
        auto *right = new QVBoxLayout;
        right->setContentsMargins(0,0,0,0);
        right->setSpacing(0);
        right->addWidget(header);
        right->addWidget(m_stack, 1);
        mainLayout->addLayout(right, 1);
        centralWidget()->setLayout(mainLayout);
    }

private slots:
    
    void switchPage(int idx) {
        if (idx >= 0 && idx < m_stack->count()) {
            m_stack->setCurrentIndex(idx);
            QStringList names = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
            if (m_breadcrumb && idx < names.size())
                m_breadcrumb->setText(names[idx]);
        }
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
    QLabel *m_breadcrumb = nullptr;
};

#endif
