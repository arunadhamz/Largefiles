// ═══════════════════════════════════════════════════════════════
// Qt C++ Test System Application
// Supports 15 different UI styles with theme switching
// Now with GUI Style Selector on startup!
// ═══════════════════════════════════════════════════════════════

#include <QApplication>
#include <QCommandLineParser>
#include "theme_engine.h"
#include "pages.h"
#include "style_selector.h"

// Include all style main windows
#include "style1_mainwindow.h"
#include "style2_mainwindow.h"
#include "style3_mainwindow.h"
#include "style4_mainwindow.h"
#include "style5_mainwindow.h"
#include "style6_mainwindow.h"
#include "style7_mainwindow.h"
#include "style8_mainwindow.h"
#include "style9_mainwindow.h"
#include "style10_mainwindow.h"
#include "style11_mainwindow.h"
#include "style12_mainwindow.h"
#include "style13_mainwindow.h"
#include "style14_mainwindow.h"
#include "style15_mainwindow.h"

static QMainWindow* createMainWindow(int styleId) {
    switch (styleId) {
    case 1:  return new Style1MainWindow;
    case 2:  return new Style2MainWindow;
    case 3:  return new Style3MainWindow;
    case 4:  return new Style4MainWindow;
    case 5:  return new Style5MainWindow;
    case 6:  return new Style6MainWindow;
    case 7:  return new Style7MainWindow;
    case 8:  return new Style8MainWindow;
    case 9:  return new Style9MainWindow;
    case 10: return new Style10MainWindow;
    case 11: return new Style11MainWindow;
    case 12: return new Style12MainWindow;
    case 13: return new Style13MainWindow;
    case 14: return new Style14MainWindow;
    case 15: return new Style15MainWindow;
    default: return new Style1MainWindow;
    }
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    app.setApplicationName("TestSystem");
    app.setApplicationVersion("2.0.1");

    // Optional: command-line override (skip selector dialog)
    QCommandLineParser parser;
    parser.setApplicationDescription("Test System Application with Multiple UI Styles");
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption styleOption(QStringList() << "s" << "style",
        "UI style (1-15). Skips selector dialog.", "style", "0");
    parser.addOption(styleOption);

    QCommandLineOption themeOption(QStringList() << "t" << "theme",
        "Theme: midnight|arctic|ember|forest|cyber", "theme", "midnight");
    parser.addOption(themeOption);

    parser.process(app);

    int styleId = parser.value(styleOption).toInt();
    ThemeEngine::Theme theme = ThemeEngine::Midnight;

    // ─── If no --style argument, show the Style Selector Dialog ───
    if (styleId < 1 || styleId > 15) {
        StyleSelectorDialog selector;
        if (selector.exec() != QDialog::Accepted)
            return 0; // User clicked Quit

        styleId = selector.selectedStyle();
        theme = selector.selectedTheme();
    } else {
        // Parse theme from command line
        QString themeName = parser.value(themeOption).toLower();
        if (themeName == "arctic")      theme = ThemeEngine::Arctic;
        else if (themeName == "ember")  theme = ThemeEngine::Ember;
        else if (themeName == "forest") theme = ThemeEngine::Forest;
        else if (themeName == "cyber")  theme = ThemeEngine::Cyber;
    }

    // Apply chosen theme
    ThemeEngine::apply(theme);

    // ─── Show Login Page ───
    LoginPage login;
    login.setWindowTitle("Test System - Login");
    login.resize(420, 380);

    QMainWindow *mainWindow = nullptr;

    QObject::connect(&login, &LoginPage::loginSuccess, [&](const QString &user) {
        login.hide();

        mainWindow = createMainWindow(styleId);
        mainWindow->setWindowTitle(mainWindow->windowTitle() + QString::fromUtf8(" \xe2\x80\x94 ") + user);
        mainWindow->show();
    });

    login.show();
    return app.exec();
}
