// Style 8: Terminal/Console — Dark monospace, command input at bottom, log-style output
#ifndef STYLE8_MAINWINDOW_H
#define STYLE8_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QLineEdit>
#include <QTextEdit>
#include <QSplitter>
#include "theme_engine.h"
#include "pages.h"

class Style8MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style8MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Terminal Style");
        resize(1100, 700);
        auto *central = new QWidget; setCentralWidget(central);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        auto *mainLayout = new QVBoxLayout(central);
        mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0);

        // Terminal title bar (green on black)
        auto *titleBar = new QFrame; titleBar->setFixedHeight(28);
        titleBar->setStyleSheet("background: #1a1a2e; border-bottom: 1px solid #00ff41;");
        auto *tl = new QHBoxLayout(titleBar); tl->setContentsMargins(8,0,8,0);
        auto *termTitle = new QLabel("test-system@localhost:~$");
        termTitle->setStyleSheet("font-family: 'Courier New', monospace; font-size: 12px; color: #00ff41;");
        tl->addWidget(termTitle); tl->addStretch();
        mainLayout->addWidget(titleBar);

        // Splitter: left log panel | right page content
        auto *splitter = new QSplitter(Qt::Horizontal);

        // Left: Terminal log output
        auto *logPanel = new QWidget;
        auto *logLayout = new QVBoxLayout(logPanel);
        logLayout->setContentsMargins(0,0,0,0); logLayout->setSpacing(0);
        
        // Navigation via command-style buttons
        auto *cmdNav = new QFrame;
        cmdNav->setStyleSheet("background: #0c0c0c; border-bottom: 1px solid #1a1a2e;");
        auto *cmdNavLayout = new QVBoxLayout(cmdNav);
        cmdNavLayout->setContentsMargins(4,4,4,4); cmdNavLayout->setSpacing(2);
        QStringList names = {"home","init","pbit","selftest","auto","manual","users","about"};
        QStringList display = {"[0] home","[1] init","[2] pbit","[3] selftest","[4] auto","[5] manual","[6] users","[7] about"};
        for (int i = 0; i < display.size(); i++) {
            auto *btn = new QPushButton(display[i]);
            btn->setStyleSheet("QPushButton { text-align: left; font-family: 'Courier New', monospace; font-size: 11px; "
                "color: #00ff41; background: transparent; border: none; padding: 3px 8px; }"
                "QPushButton:hover { background: #1a1a2e; }");
            connect(btn, &QPushButton::clicked, this, [this,i]{ m_stack->setCurrentIndex(i); logCommand(i); });
            cmdNavLayout->addWidget(btn);
            m_cmdBtns.append(btn);
        }
        cmdNavLayout->addStretch();
        logLayout->addWidget(cmdNav);

        // Log output
        m_log = new QTextEdit; m_log->setReadOnly(true);
        m_log->setStyleSheet("QTextEdit { background: #0c0c0c; color: #00ff41; font-family: 'Courier New', monospace; "
            "font-size: 11px; border: none; }");
        m_log->append("[system] Test System v2.0 initialized");
        m_log->append("[system] Type command or select module");
        m_log->append("─────────────────────────────────");
        logLayout->addWidget(m_log);

        splitter->addWidget(logPanel);
        splitter->addWidget(m_stack);
        splitter->setSizes({250, 750});
        mainLayout->addWidget(splitter, 1);

        // Bottom command input
        auto *cmdBar = new QFrame; cmdBar->setFixedHeight(36);
        cmdBar->setStyleSheet("background: #0c0c0c; border-top: 1px solid #1a1a2e;");
        auto *cmdLayout = new QHBoxLayout(cmdBar); cmdLayout->setContentsMargins(8,0,8,0);
        auto *prompt = new QLabel("$"); prompt->setStyleSheet("color: #00ff41; font-family: monospace; font-size: 14px; font-weight: bold;");
        cmdLayout->addWidget(prompt);
        auto *cmdInput = new QLineEdit;
        cmdInput->setStyleSheet("QLineEdit { background: transparent; border: none; color: #00ff41; "
            "font-family: 'Courier New', monospace; font-size: 12px; }");
        cmdInput->setPlaceholderText("Enter command: home, init, pbit, selftest, auto, manual, users, about, theme <name>");
        connect(cmdInput, &QLineEdit::returnPressed, this, [this,cmdInput,names]{
            QString cmd = cmdInput->text().trimmed().toLower();
            int idx = names.indexOf(cmd);
            if (idx >= 0) { m_stack->setCurrentIndex(idx); logCommand(idx); }
            else if (cmd.startsWith("theme ")) {
                QStringList t={"midnight","arctic","ember","forest","cyber"};
                int ti = t.indexOf(cmd.mid(6).trimmed());
                if (ti >= 0) { ThemeEngine::apply((ThemeEngine::Theme)ti); m_log->append("[theme] Switched to "+t[ti]); }
            }
            else m_log->append("[error] Unknown command: " + cmd);
            cmdInput->clear();
        });
        cmdLayout->addWidget(cmdInput);
        mainLayout->addWidget(cmdBar);
    }
private:
    void logCommand(int idx) {
        QStringList n={"home","init","pbit","selftest","auto","manual","users","about"};
        m_log->append(QString("[nav] Switched to: %1").arg(n[idx]));
        for(int i=0;i<m_cmdBtns.size();i++)
            m_cmdBtns[i]->setStyleSheet(i==idx
                ? "QPushButton { text-align:left; font-family:'Courier New',monospace; font-size:11px; color:#0c0c0c; background:#00ff41; border:none; padding:3px 8px; }"
                : "QPushButton { text-align:left; font-family:'Courier New',monospace; font-size:11px; color:#00ff41; background:transparent; border:none; padding:3px 8px; }"
                  "QPushButton:hover { background:#1a1a2e; }");
    }
    QStackedWidget *m_stack; CommBackend *m_comm;
    QTextEdit *m_log; QVector<QPushButton*> m_cmdBtns;
};
#endif
