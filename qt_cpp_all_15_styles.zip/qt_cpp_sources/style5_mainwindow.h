#ifndef STYLE5_MAINWINDOW_H
#define STYLE5_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include <QDockWidget>
#include <QListWidget>
#include <QTreeWidget>
#include <QTabWidget>
#include <QSplitter>
#include <QToolButton>
#include <QButtonGroup>
#include <QPropertyAnimation>
#include <QGraphicsDropShadowEffect>
#include <QScrollArea>
#include <QProgressBar>
#include <QToolBox>
#include "theme_engine.h"
#include "pages.h"


class Style5MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style5MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Top Navigation");
        resize(1100, 700);
        setCentralWidget(new QWidget);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        // === TOP NAVIGATION BAR (full width, two rows) ===
        // Row 1: Logo + theme
        auto *topBar = new QFrame;
        topBar->setObjectName("header");
        topBar->setFixedHeight(48);
        topBar->setStyleSheet("QFrame#header { background: #1e40af; border: none; }");
        auto *topLayout = new QHBoxLayout(topBar);
        topLayout->setContentsMargins(20, 0, 20, 0);
        auto *logo = new QLabel("⬡ TEST SYSTEM");
        logo->setStyleSheet("color: white; font-size: 16px; font-weight: bold; letter-spacing: 2px;");
        topLayout->addWidget(logo);
        topLayout->addStretch();
        
        auto *themeCombo = new QComboBox;
        themeCombo->addItems({"Midnight", "Arctic", "Ember", "Forest", "Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [](int idx){
            ThemeEngine::apply(static_cast<ThemeEngine::Theme>(idx));
        });
        themeCombo->setStyleSheet("background: rgba(255,255,255,0.2); color: white; border: none; padding: 4px 8px;");
        topLayout->addWidget(themeCombo);

        // Row 2: Navigation buttons
        auto *navBar = new QFrame;
        navBar->setObjectName("header");
        navBar->setFixedHeight(42);
        navBar->setStyleSheet("QFrame#header { background: #1e3a8a; border: none; }");
        auto *navLayout = new QHBoxLayout(navBar);
        navLayout->setContentsMargins(20, 0, 20, 0);
        navLayout->setSpacing(0);

        QStringList navItems = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        for (int i = 0; i < navItems.size(); i++) {
            auto *btn = new QPushButton(navItems[i]);
            btn->setCheckable(true);
            btn->setAutoExclusive(true);
            btn->setStyleSheet(
                "QPushButton { color: rgba(255,255,255,0.7); border: none; padding: 8px 16px; font-size: 12px; }"
                "QPushButton:checked { color: white; background: rgba(255,255,255,0.15); font-weight: bold; }"
                "QPushButton:hover { color: white; background: rgba(255,255,255,0.1); }"
            );
            if (i == 0) btn->setChecked(true);
            connect(btn, &QPushButton::clicked, this, [this, i]{ m_stack->setCurrentIndex(i); });
            navLayout->addWidget(btn);
        }
        navLayout->addStretch();

        // === ASSEMBLE ===
        auto *mainLayout = new QVBoxLayout;
        mainLayout->setContentsMargins(0,0,0,0);
        mainLayout->setSpacing(0);
        mainLayout->addWidget(topBar);
        mainLayout->addWidget(navBar);
        mainLayout->addWidget(m_stack, 1);
        centralWidget()->setLayout(mainLayout);

        statusBar()->showMessage("Style 5: Top Navigation | Ready");
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
};

#endif
