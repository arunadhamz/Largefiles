// ═══════════════════════════════════════════════════════════════
// Style 5: Top Navigation
// Horizontal top navigation with dropdown menus
// ═══════════════════════════════════════════════════════════════

#ifndef STYLE5_MAINWINDOW_H
#define STYLE5_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include "theme_engine.h"
#include "pages.h"

class Style5MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style5MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Top Navigation");
        resize(1100, 700);
        setCentralWidget(new QWidget);

        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;

        // Add all pages
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        
        // Top tab bar navigation
        auto *mainLayout = new QVBoxLayout;
        mainLayout->setContentsMargins(0, 0, 0, 0);
        mainLayout->setSpacing(0);

        auto *header = new QFrame;
        header->setObjectName("header");
        header->setFixedHeight(52);
        auto *headerLayout = new QHBoxLayout(header);
        auto *logo = new QLabel("⬡ Test System");
        logo->setStyleSheet("font-size: 16px; font-weight: bold;");
        headerLayout->addWidget(logo);
        headerLayout->addSpacing(20);

        QStringList navItems = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        for (int i = 0; i < navItems.size(); i++) {
            auto *btn = new QPushButton(navItems[i]);
            btn->setCheckable(true);
            btn->setFlat(true);
            btn->setStyleSheet("padding: 8px 12px; border: none; border-bottom: 2px solid transparent;");
            connect(btn, &QPushButton::clicked, this, [this, i]{ m_stack->setCurrentIndex(i); });
            headerLayout->addWidget(btn);
            m_navButtons.append(btn);
        }
        headerLayout->addStretch();

        auto *themeCombo = new QComboBox;
        themeCombo->addItems({"Midnight", "Arctic", "Ember", "Forest", "Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [](int idx){
            ThemeEngine::apply(static_cast<ThemeEngine::Theme>(idx));
        });
        headerLayout->addWidget(themeCombo);

        mainLayout->addWidget(header);
        mainLayout->addWidget(m_stack);

        auto *statusBar = new QStatusBar;
        statusBar->showMessage("Ready");
        setStatusBar(statusBar);

        centralWidget()->setLayout(mainLayout);

        // Apply default theme
        ThemeEngine::apply(ThemeEngine::Midnight);
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
    QVector<QPushButton*> m_navButtons;
    QLabel *m_breadcrumb = nullptr;
};

#endif // STYLE5_MAINWINDOW_H
