#ifndef COMMON_TYPES_H
#define COMMON_TYPES_H

#include <QString>
#include <QVector>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QFile>
#include <QDir>
#include <QCryptographicHash>
#include <QDateTime>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTcpSocket>

// ─── Shared Data Structures ───
struct TestResult {
    QString testName;
    bool selected = false;
    QString status = "PENDING"; // PASS, FAIL, PENDING, RUNNING
    int majorCycle = 0;
    int minorCycle = 0;
};

struct UserCredential {
    QString username;
    QString passwordHash;
    QString role; // Administrator, Operator, Read-Only
    QString lastLogin;
};

struct PBITStatus {
    QString componentName;
    bool tested = false;
    bool passed = false;
};

struct ConnectionConfig {
    // Ethernet
    QString ipAddress = "192.168.1.100";
    int port = 5000;
    QString subnet = "255.255.255.0";
    QString gateway = "192.168.1.1";
    // UART
    QString comPort = "COM1";
    int baudRate = 115200;
    int channel = 0;
    QString dataBits = "8";
    QString parity = "None";
    QString stopBits = "1";
};

// ─── User Manager (file-based, app directory) ───
class UserManager {
public:
    static QString credFilePath() {
        return QDir(QCoreApplication::applicationDirPath()).filePath("users.json");
    }

    static QVector<UserCredential> loadUsers() {
        QVector<UserCredential> users;
        QFile f(credFilePath());
        if (!f.open(QIODevice::ReadOnly)) {
            // Create default admin
            UserCredential admin;
            admin.username = "admin";
            admin.passwordHash = hashPassword("admin123");
            admin.role = "Administrator";
            admin.lastLogin = QDateTime::currentDateTime().toString(Qt::ISODate);
            users.append(admin);
            saveUsers(users);
            return users;
        }
        QJsonDocument doc = QJsonDocument::fromJson(f.readAll());
        f.close();
        for (const auto &val : doc.array()) {
            QJsonObject obj = val.toObject();
            UserCredential u;
            u.username = obj["username"].toString();
            u.passwordHash = obj["passwordHash"].toString();
            u.role = obj["role"].toString();
            u.lastLogin = obj["lastLogin"].toString();
            users.append(u);
        }
        return users;
    }

    static void saveUsers(const QVector<UserCredential> &users) {
        QJsonArray arr;
        for (const auto &u : users) {
            QJsonObject obj;
            obj["username"] = u.username;
            obj["passwordHash"] = u.passwordHash;
            obj["role"] = u.role;
            obj["lastLogin"] = u.lastLogin;
            arr.append(obj);
        }
        QFile f(credFilePath());
        if (f.open(QIODevice::WriteOnly)) {
            f.write(QJsonDocument(arr).toJson());
            f.close();
        }
    }

    static QString hashPassword(const QString &pw) {
        return QCryptographicHash::hash(pw.toUtf8(), QCryptographicHash::Sha256).toHex();
    }

    static bool authenticate(const QString &user, const QString &pass) {
        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == user && u.passwordHash == hashPassword(pass)) {
                u.lastLogin = QDateTime::currentDateTime().toString(Qt::ISODate);
                saveUsers(users);
                return true;
            }
        }
        return false;
    }

    static bool addUser(const QString &user, const QString &pass, const QString &role) {
        auto users = loadUsers();
        for (const auto &u : users)
            if (u.username == user) return false;
        UserCredential nu;
        nu.username = user;
        nu.passwordHash = hashPassword(pass);
        nu.role = role;
        nu.lastLogin = "Never";
        users.append(nu);
        saveUsers(users);
        return true;
    }

    static bool removeUser(const QString &user) {
        auto users = loadUsers();
        for (int i = 0; i < users.size(); i++) {
            if (users[i].username == user) {
                users.removeAt(i);
                saveUsers(users);
                return true;
            }
        }
        return false;
    }

    static bool renameUser(const QString &oldName, const QString &newName) {
        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == oldName) {
                u.username = newName;
                saveUsers(users);
                return true;
            }
        }
        return false;
    }
};

// ─── App Checksum Calculator ───
class AppChecksum {
public:
    static QString calculate() {
        QFile f(QCoreApplication::applicationFilePath());
        if (!f.open(QIODevice::ReadOnly)) return "ERROR";
        QCryptographicHash hash(QCryptographicHash::Sha256);
        hash.addData(&f);
        f.close();
        return hash.result().toHex().left(16).toUpper();
    }
};

// ─── Communication Backend ───
class CommBackend : public QObject {
    Q_OBJECT
public:
    explicit CommBackend(QObject *parent = nullptr) : QObject(parent) {
        m_socket = new QTcpSocket(this);
        m_serial = new QSerialPort(this);
        connect(m_socket, &QTcpSocket::readyRead, this, &CommBackend::onSocketData);
        connect(m_serial, &QSerialPort::readyRead, this, &CommBackend::onSerialData);
    }

    bool connectEthernet(const QString &ip, int port) {
        m_socket->connectToHost(ip, port);
        return m_socket->waitForConnected(3000);
    }

    bool connectUart(const QString &portName, int baud, int channel) {
        Q_UNUSED(channel);
        m_serial->setPortName(portName);
        m_serial->setBaudRate(baud);
        m_serial->setDataBits(QSerialPort::Data8);
        m_serial->setParity(QSerialPort::NoParity);
        m_serial->setStopBits(QSerialPort::OneStop);
        return m_serial->open(QIODevice::ReadWrite);
    }

    void sendCommand(const QByteArray &cmd) {
        if (m_socket->state() == QAbstractSocket::ConnectedState)
            m_socket->write(cmd);
        else if (m_serial->isOpen())
            m_serial->write(cmd);
    }

    void disconnect() {
        m_socket->disconnectFromHost();
        m_serial->close();
    }

signals:
    void dataReceived(const QByteArray &data);

private slots:
    void onSocketData() { emit dataReceived(m_socket->readAll()); }
    void onSerialData() { emit dataReceived(m_serial->readAll()); }

private:
    QTcpSocket *m_socket;
    QSerialPort *m_serial;
};

#endif // COMMON_TYPES_H
