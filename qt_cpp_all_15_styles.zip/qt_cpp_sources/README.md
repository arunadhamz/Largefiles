# Qt C++ Test System Application — 15 UI Styles

## Overview
A comprehensive test system application with 15 different UI layout styles,
5 color themes, and full pages for Login, Home, Initialization, PBIT,
Self Test, Auto Mode, Manual Mode, User Management, and About.

## Features
- **15 UI Styles**: Sidebar, Ribbon, Dashboard, Compact, Top Nav, Split Panel,
  Tab-Centric, Wizard, Terminal, Material, Bottom Tab, Floating, Command Palette,
  Dual Sidebar, Carousel
- **5 Themes**: Midnight (dark blue), Arctic (light), Ember (dark red),
  Forest (dark green), Cyber (dark purple)
- **Pages**: Login, Home, Init (Ethernet+UART), PBIT (LED status), Self Test,
  Auto Mode (table+report), Manual Mode (ALU/FPU), User Management, About (checksum)

## Build

### Using qmake:
```bash
qmake TestSystem.pro
make
```

### Using CMake:
```bash
mkdir build && cd build
cmake ..
make
```

## Run
```bash
./TestSystem --style 1 --theme midnight
./TestSystem -s 5 -t arctic
```

## Style Reference
| # | Name | Navigation |
|---|------|-----------|
| 1 | Classic Sidebar | Fixed left sidebar with breadcrumb header |
| 2 | Ribbon Toolbar | Office-style ribbon tabs with tool groups |
| 3 | Dashboard Grid | Top tabs with grid widget layout |
| 4 | Compact Sidebar | Icon-only sidebar (56px) with tooltips |
| 5 | Top Navigation | Horizontal nav bar with dropdowns |
| 6 | Split Panel | Tree view + resizable content panel |
| 7 | Tab-Centric | Browser-style document tabs |
| 8 | Wizard Flow | Step-by-step with progress indicator |
| 9 | Terminal Style | Command bar + log output (monospace) |
| 10 | Material Drawer | Hamburger menu + FAB buttons |
| 11 | Bottom Tab Bar | Mobile-style bottom navigation |
| 12 | Floating Sidebar | Glass-morphism floating nav panel |
| 13 | Command Palette | VS Code-style activity bar + palette |
| 14 | Dual Sidebar | Icon bar + detail panel (left+right) |
| 15 | Carousel Nav | Full-screen pages with dot indicators |

## Dependencies
- Qt 5.15+ (Core, Gui, Widgets, SerialPort, Network)
- C++17 compiler
