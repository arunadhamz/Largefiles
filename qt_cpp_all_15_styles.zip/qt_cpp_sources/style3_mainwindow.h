#ifndef STYLE3_MAINWINDOW_H
#define STYLE3_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include <QDockWidget>
#include <QListWidget>
#include <QTreeWidget>
#include <QTabWidget>
#include <QSplitter>
#include <QToolButton>
#include <QButtonGroup>
#include <QPropertyAnimation>
#include <QGraphicsDropShadowEffect>
#include <QScrollArea>
#include <QProgressBar>
#include <QToolBox>
#include "theme_engine.h"
#include "pages.h"


class Style3MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style3MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Top Tabs");
        resize(1100, 700);
        m_comm = new CommBackend(this);

        // === USE QTabWidget directly as central widget ===
        auto *tabs = new QTabWidget;
        tabs->setTabPosition(QTabWidget::North);
        tabs->setDocumentMode(true);
        tabs->setStyleSheet(
            "QTabBar { font-size: 13px; }"
            "QTabBar::tab { padding: 10px 22px; min-width: 90px; }"
            "QTabBar::tab:selected { font-weight: bold; border-bottom: 3px solid #3b82f6; }"
        );

        QStringList navItems = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        QStringList navIcons = {"🏠", "🔌", "💡", "✔", "▶", "🔧", "👥", "ℹ"};

        // Each tab wraps the page in a QScrollArea
        tabs->addTab(wrapScroll(new HomePage), navIcons[0] + " " + navItems[0]);
        tabs->addTab(wrapScroll(new InitPage(m_comm)), navIcons[1] + " " + navItems[1]);
        tabs->addTab(wrapScroll(new PBITPage(m_comm)), navIcons[2] + " " + navItems[2]);
        tabs->addTab(wrapScroll(new SelfTestPage(m_comm)), navIcons[3] + " " + navItems[3]);
        tabs->addTab(wrapScroll(new AutoModePage(m_comm)), navIcons[4] + " " + navItems[4]);
        tabs->addTab(wrapScroll(new ManualModePage(m_comm)), navIcons[5] + " " + navItems[5]);
        tabs->addTab(wrapScroll(new UserManagementPage), navIcons[6] + " " + navItems[6]);
        tabs->addTab(wrapScroll(new AboutPage), navIcons[7] + " " + navItems[7]);

        setCentralWidget(tabs);

        
        auto *themeCombo = new QComboBox;
        themeCombo->addItems({"Midnight", "Arctic", "Ember", "Forest", "Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [](int idx){
            ThemeEngine::apply(static_cast<ThemeEngine::Theme>(idx));
        });
        statusBar()->addPermanentWidget(themeCombo);
        statusBar()->showMessage("Style 3: Top Tabs | Ready");
    }

private:
    QWidget* wrapScroll(QWidget *page) {
        auto *scroll = new QScrollArea;
        scroll->setWidget(page);
        scroll->setWidgetResizable(true);
        scroll->setFrameShape(QFrame::NoFrame);
        return scroll;
    }
    CommBackend *m_comm;
};

#endif
