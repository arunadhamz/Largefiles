// Style 11: Sidebar RIGHT — Navigation sidebar on the RIGHT side (reversed layout), header left-aligned
#ifndef STYLE11_MAINWINDOW_H
#define STYLE11_MAINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include "theme_engine.h"
#include "pages.h"

class Style11MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style11MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Right Sidebar");
        resize(1100, 700);
        auto *central = new QWidget; setCentralWidget(central);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        m_stack->addWidget(new HomePage); m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm)); m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm)); m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage); m_stack->addWidget(new AboutPage);

        auto *mainLayout = new QHBoxLayout(central);
        mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0);

        // LEFT: Header + Content
        auto *leftPanel = new QWidget;
        auto *ll = new QVBoxLayout(leftPanel); ll->setContentsMargins(0,0,0,0); ll->setSpacing(0);
        auto *header = new QFrame; header->setObjectName("header"); header->setFixedHeight(52);
        auto *hl = new QHBoxLayout(header); hl->setContentsMargins(20,0,20,0);
        auto *logo = new QLabel("⬡ Test System"); logo->setStyleSheet("font-size: 16px; font-weight: bold;");
        hl->addWidget(logo); hl->addStretch();
        m_pageLabel = new QLabel("Home"); m_pageLabel->setStyleSheet("font-size: 14px; font-weight: bold; color: #3b82f6;");
        hl->addWidget(m_pageLabel);
        ll->addWidget(header);
        ll->addWidget(m_stack, 1);
        mainLayout->addWidget(leftPanel, 1);

        // RIGHT: Sidebar (180px, right side)
        auto *sidebar = new QFrame; sidebar->setObjectName("sidebar");
        sidebar->setFixedWidth(180);
        sidebar->setStyleSheet("QFrame#sidebar { border-left: 1px solid rgba(128,128,128,0.2); }");
        auto *sl = new QVBoxLayout(sidebar); sl->setContentsMargins(0,12,0,12); sl->setSpacing(2);
        auto *navTitle = new QLabel("  NAVIGATION"); navTitle->setStyleSheet("font-size: 10px; font-weight: bold; color: gray; padding: 8px 12px;");
        sl->addWidget(navTitle);
        QStringList names={"Home","Initialization","PBIT","Self Test","Auto Mode","Manual Mode","Users","About"};
        for (int i = 0; i < names.size(); i++) {
            auto *btn = new QPushButton(names[i]);
            btn->setStyleSheet("QPushButton { text-align: right; padding: 10px 16px; border: none; font-size: 12px; }"
                "QPushButton:hover { background: rgba(59,130,246,0.08); }");
            connect(btn, &QPushButton::clicked, this, [this,i,names]{ m_stack->setCurrentIndex(i); m_pageLabel->setText(names[i]); updateNav(i); });
            sl->addWidget(btn); m_navBtns.append(btn);
        }
        sl->addStretch();
        auto *tc = new QComboBox; tc->addItems({"Midnight","Arctic","Ember","Forest","Cyber"});
        connect(tc,QOverload<int>::of(&QComboBox::currentIndexChanged),[](int i){ThemeEngine::apply((ThemeEngine::Theme)i);});
        sl->addWidget(tc);
        mainLayout->addWidget(sidebar);
        updateNav(0);
    }
private:
    void updateNav(int idx) {
        for(int i=0;i<m_navBtns.size();i++)
            m_navBtns[i]->setStyleSheet(i==idx
                ? "QPushButton{text-align:right;padding:10px 16px;border:none;font-size:12px;font-weight:bold;border-right:3px solid #3b82f6;background:rgba(59,130,246,0.1);}"
                : "QPushButton{text-align:right;padding:10px 16px;border:none;font-size:12px;}QPushButton:hover{background:rgba(59,130,246,0.06);}");
    }
    QStackedWidget *m_stack; CommBackend *m_comm;
    QVector<QPushButton*> m_navBtns; QLabel *m_pageLabel;
};
#endif
