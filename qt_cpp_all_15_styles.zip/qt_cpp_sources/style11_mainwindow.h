// ═══════════════════════════════════════════════════════════════
// Style 11: Bottom Tab Bar
// Mobile-inspired bottom navigation with tab bar
// ═══════════════════════════════════════════════════════════════

#ifndef STYLE11_MAINWINDOW_H
#define STYLE11_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include "theme_engine.h"
#include "pages.h"

class Style11MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style11MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Bottom Tab Bar");
        resize(1100, 700);
        setCentralWidget(new QWidget);

        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;

        // Add all pages
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        
        // Bottom tab bar navigation
        auto *mainLayout = new QVBoxLayout;
        mainLayout->setContentsMargins(0, 0, 0, 0);
        mainLayout->setSpacing(0);

        auto *header = new QFrame;
        header->setObjectName("header");
        header->setFixedHeight(44);
        auto *headerLayout = new QHBoxLayout(header);
        m_breadcrumb = new QLabel("Home");
        m_breadcrumb->setStyleSheet("font-size: 16px; font-weight: bold;");
        headerLayout->addWidget(m_breadcrumb);
        headerLayout->addStretch();

        mainLayout->addWidget(header);
        mainLayout->addWidget(m_stack, 1);

        // Bottom bar
        auto *bottomBar = new QFrame;
        bottomBar->setObjectName("header");
        bottomBar->setFixedHeight(56);
        auto *bottomLayout = new QHBoxLayout(bottomBar);

        QStringList icons = {"🏠", "⚙", "🔌", "✓", "▶", "🔧", "👥", "ℹ"};
        QStringList labels = {"Home", "Init", "PBIT", "Test", "Auto", "Manual", "Users", "About"};
        for (int i = 0; i < icons.size(); i++) {
            auto *btn = new QPushButton(icons[i] + "\n" + labels[i]);
            btn->setStyleSheet("font-size: 10px; padding: 4px;");
            connect(btn, &QPushButton::clicked, this, [this, i]{ m_stack->setCurrentIndex(i); });
            bottomLayout->addWidget(btn);
            m_navButtons.append(btn);
        }
        mainLayout->addWidget(bottomBar);
        centralWidget()->setLayout(mainLayout);

        // Apply default theme
        ThemeEngine::apply(ThemeEngine::Midnight);
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
    QVector<QPushButton*> m_navButtons;
    QLabel *m_breadcrumb = nullptr;
};

#endif // STYLE11_MAINWINDOW_H
