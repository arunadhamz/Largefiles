// Style 6: Tab-Centric — QTabWidget as the main container, browser-like tabs, no sidebar
#ifndef STYLE6_MAINWINDOW_H
#define STYLE6_MAINWINDOW_H
#include <QMainWindow>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include <QStatusBar>
#include "theme_engine.h"
#include "pages.h"

class Style6MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style6MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Tab Centric");
        resize(1100, 700);
        m_comm = new CommBackend(this);
        m_tabs = new QTabWidget;
        m_tabs->setTabPosition(QTabWidget::North);
        m_tabs->setMovable(true);
        m_tabs->setStyleSheet(
            "QTabWidget::pane { border: none; border-top: 2px solid #3b82f6; }"
            "QTabBar::tab { padding: 10px 20px; margin-right: 2px; border-top-left-radius: 6px; border-top-right-radius: 6px; font-size: 12px; }"
            "QTabBar::tab:selected { background: rgba(59,130,246,0.15); font-weight: bold; }"
            "QTabBar::tab:hover:!selected { background: rgba(59,130,246,0.08); }");
        QStringList names = {"🏠 Home", "🔌 Init", "💡 PBIT", "✅ Self Test", "▶ Auto", "🔧 Manual", "👥 Users", "ℹ About"};
        QWidget *pages[] = { new HomePage, new InitPage(m_comm), new PBITPage(m_comm), new SelfTestPage(m_comm),
            new AutoModePage(m_comm), new ManualModePage(m_comm), new UserManagementPage, new AboutPage };
        for (int i = 0; i < 8; i++) m_tabs->addTab(pages[i], names[i]);
        auto *toolbar = new QFrame; toolbar->setObjectName("header"); toolbar->setFixedHeight(36);
        auto *tbLayout = new QHBoxLayout(toolbar); tbLayout->setContentsMargins(12,0,12,0);
        auto *appLabel = new QLabel("⬡ Test System v2.0"); appLabel->setStyleSheet("font-size: 12px; font-weight: bold;");
        tbLayout->addWidget(appLabel); tbLayout->addStretch();
        auto *themeCombo = new QComboBox; themeCombo->addItems({"Midnight","Arctic","Ember","Forest","Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),[](int i){ThemeEngine::apply((ThemeEngine::Theme)i);});
        tbLayout->addWidget(new QLabel("Theme:")); tbLayout->addWidget(themeCombo);
        auto *central = new QWidget; auto *cl = new QVBoxLayout(central); cl->setContentsMargins(0,0,0,0); cl->setSpacing(0);
        cl->addWidget(toolbar); cl->addWidget(m_tabs); setCentralWidget(central);
        setStatusBar(new QStatusBar); statusBar()->showMessage("8 tabs open");
    }
private:
    QTabWidget *m_tabs; CommBackend *m_comm;
};
#endif
