#ifndef STYLE1_MAINWINDOW_H
#define STYLE1_MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMenuBar>
#include <QToolBar>
#include <QDockWidget>
#include <QListWidget>
#include <QTreeWidget>
#include <QTabWidget>
#include <QSplitter>
#include <QToolButton>
#include <QButtonGroup>
#include <QPropertyAnimation>
#include <QGraphicsDropShadowEffect>
#include <QScrollArea>
#include <QProgressBar>
#include <QToolBox>
#include "theme_engine.h"
#include "pages.h"


class Style1MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit Style1MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Test System - Classic Sidebar");
        resize(1100, 700);
        setCentralWidget(new QWidget);
        m_comm = new CommBackend(this);
        m_stack = new QStackedWidget;
        
        m_stack->addWidget(new HomePage);
        m_stack->addWidget(new InitPage(m_comm));
        m_stack->addWidget(new PBITPage(m_comm));
        m_stack->addWidget(new SelfTestPage(m_comm));
        m_stack->addWidget(new AutoModePage(m_comm));
        m_stack->addWidget(new ManualModePage(m_comm));
        m_stack->addWidget(new UserManagementPage);
        m_stack->addWidget(new AboutPage);

        // === LEFT SIDEBAR 200px with text buttons ===
        auto *sidebar = new QFrame;
        sidebar->setObjectName("sidebar");
        sidebar->setFixedWidth(200);
        auto *sideLayout = new QVBoxLayout(sidebar);
        sideLayout->setContentsMargins(0, 0, 0, 12);
        sideLayout->setSpacing(0);

        // Logo area at top of sidebar
        auto *logoFrame = new QFrame;
        logoFrame->setFixedHeight(64);
        logoFrame->setStyleSheet("background: rgba(59,130,246,0.15); border-bottom: 1px solid rgba(59,130,246,0.3);");
        auto *logoLayout = new QHBoxLayout(logoFrame);
        auto *logoIcon = new QLabel("⬡");
        logoIcon->setStyleSheet("font-size: 28px;");
        logoLayout->addWidget(logoIcon);
        auto *logoText = new QLabel("Test System");
        logoText->setStyleSheet("font-size: 15px; font-weight: bold;");
        logoLayout->addWidget(logoText);
        logoLayout->addStretch();
        sideLayout->addWidget(logoFrame);

        sideLayout->addSpacing(8);

        QStringList navItems = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
        QStringList navIcons = {"🏠", "🔌", "💡", "✔", "▶", "🔧", "👥", "ℹ"};
        for (int i = 0; i < navItems.size(); i++) {
            auto *btn = new QPushButton(navIcons[i] + "  " + navItems[i]);
            btn->setCheckable(true);
            btn->setAutoExclusive(true);
            btn->setStyleSheet(
                "QPushButton { text-align: left; padding: 10px 16px; border: none; border-radius: 0; "
                "border-left: 3px solid transparent; font-size: 13px; }"
                "QPushButton:checked { border-left: 3px solid #3b82f6; background: rgba(59,130,246,0.1); font-weight: bold; }"
                "QPushButton:hover { background: rgba(59,130,246,0.05); }"
            );
            if (i == 0) btn->setChecked(true);
            connect(btn, &QPushButton::clicked, this, [this, i]{ switchPage(i); });
            sideLayout->addWidget(btn);
            m_navButtons.append(btn);
        }
        sideLayout->addStretch();

        // Theme selector at sidebar bottom
        auto *themeFrame = new QFrame;
        themeFrame->setStyleSheet("border-top: 1px solid palette(mid); padding: 8px;");
        auto *tf = new QVBoxLayout(themeFrame);
        auto *themeLabel = new QLabel("Theme");
        themeLabel->setStyleSheet("font-size: 10px; color: gray; text-transform: uppercase; letter-spacing: 1px;");
        tf->addWidget(themeLabel);
        
        auto *themeCombo = new QComboBox;
        themeCombo->addItems({"Midnight", "Arctic", "Ember", "Forest", "Cyber"});
        connect(themeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [](int idx){
            ThemeEngine::apply(static_cast<ThemeEngine::Theme>(idx));
        });
        tf->addWidget(themeCombo);
        sideLayout->addWidget(themeFrame);

        // === TOP HEADER BAR ===
        auto *header = new QFrame;
        header->setObjectName("header");
        header->setFixedHeight(48);
        auto *headerLayout = new QHBoxLayout(header);
        headerLayout->setContentsMargins(16, 0, 16, 0);
        m_breadcrumb = new QLabel("Home");
        m_breadcrumb->setStyleSheet("font-size: 16px; font-weight: bold;");
        headerLayout->addWidget(m_breadcrumb);
        headerLayout->addStretch();
        auto *connStatus = new QLabel("● Disconnected");
        connStatus->setStyleSheet("color: #f59e0b; font-size: 12px;");
        headerLayout->addWidget(connStatus);

        // === ASSEMBLE: sidebar | (header / stack) ===
        auto *mainLayout = new QHBoxLayout;
        mainLayout->setContentsMargins(0, 0, 0, 0);
        mainLayout->setSpacing(0);
        mainLayout->addWidget(sidebar);
        auto *rightPanel = new QVBoxLayout;
        rightPanel->setContentsMargins(0, 0, 0, 0);
        rightPanel->setSpacing(0);
        rightPanel->addWidget(header);
        rightPanel->addWidget(m_stack);
        mainLayout->addLayout(rightPanel, 1);
        centralWidget()->setLayout(mainLayout);

        auto *sb = new QStatusBar;
        sb->showMessage("Ready");
        setStatusBar(sb);
    }

private slots:
    
    void switchPage(int idx) {
        if (idx >= 0 && idx < m_stack->count()) {
            m_stack->setCurrentIndex(idx);
            QStringList names = {"Home", "Initialization", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"};
            if (m_breadcrumb && idx < names.size())
                m_breadcrumb->setText(names[idx]);
        }
    }

private:
    QStackedWidget *m_stack;
    CommBackend *m_comm;
    QVector<QPushButton*> m_navButtons;
    QLabel *m_breadcrumb = nullptr;
};

#endif
