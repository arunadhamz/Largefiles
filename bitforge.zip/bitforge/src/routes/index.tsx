import { createFileRoute } from "@tanstack/react-router";
import { Bell, Plus, Moon, ChevronDown, FileText, Rocket, Circle } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Embedded C Programming Practice | BitForge" },
      { name: "description", content: "Hands-on Embedded C tasks and quizzes: bits, pointers, structs, buffers and more." },
      { property: "og:title", content: "Embedded C Programming Practice | BitForge" },
      { property: "og:description", content: "Hands-on Embedded C tasks and quizzes for firmware developers." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Item = { t: string; k: "Task" | "Quiz" };
const T = (...a: string[]): Item[] => a.map((t) => ({ t, k: "Task" }));
const Q = (...a: string[]): Item[] => a.map((t) => ({ t, k: "Quiz" }));

const sections: { name: string; items: Item[] }[] = [
  { name: "Bitwise Operations", items: [...T("Turn a Register Bit On or Off", "Flip a Single Bit", "Test Whether Bit N Is High", "Enable a Flag in an 8-bit Port", "Disable a Flag in an 8-bit Port", "Mask Several Bits in a 32-bit Word", "Isolate the Most Significant One", "Bit Helpers Written as Macros", "Print Status Flags by Name"), ...Q("Bitwise Basics I", "Bitwise Basics II")] },
  { name: "Bit Field Operations", items: [...T("Read the Upper Nibble", "Write a Multi-bit Field", "Pull a Field out of a 32-bit Word", "Overwrite a Field Safely", "Program a Baud Divider Field", "Pack Settings into a 16-bit Word"), ...Q("Bit Fields I")] },
  { name: "Bitwise Rotation and Counting", items: [...T("Population Count", "Rotate an 8-bit Value Left", "Rotate a 32-bit Value Right", "Power-of-Two Check", "Reverse the Bits of a Byte"), ...Q("Rotation & Counting I")] },
  { name: "Array Manipulation", items: [...T("Reverse a Sample Buffer", "Find the Peak ADC Reading", "Moving Average Filter", "Remove Duplicate Readings"), ...Q("Arrays I")] },
  { name: "Pointer", items: [...T("Swap via Pointers", "Walk an Array with Pointer Math", "Function Pointer Dispatch Table", "Access a Memory-Mapped Register"), ...Q("Pointers I", "Pointers II")] },
  { name: "Unions", items: [...T("Inspect Float Bytes with a Union", "Packet Header Overlay"), ...Q("Unions I")] },
  { name: "Structures", items: [...T("Sensor Record Struct", "Struct Padding and Alignment", "Array of Device Configs"), ...Q("Structures I")] },
  { name: "Circular Buffers and Stack", items: [...T("Ring Buffer Push and Pop", "Detect Full and Empty States", "Fixed-size Stack"), ...Q("Buffers I")] },
  { name: "Strings and Character Handling", items: [...T("Custom String Length", "Parse a Command Line Token", "Integer to ASCII"), ...Q("Strings I")] },
  { name: "Searching and Sorting", items: [...T("Binary Search a Lookup Table", "Insertion Sort in Place"), ...Q("Search & Sort I")] },
  { name: "Data Conversion and Encoding", items: [...T("Endianness Swap", "BCD to Binary", "Simple Checksum"), ...Q("Encoding I")] },
  { name: "Arithmetic Edge Cases", items: [...T("Detect Unsigned Overflow", "Saturating Addition", "Fixed-point Multiply"), ...Q("Arithmetic I")] },
];

const leaders = [
  ["arjun_dev", 131], ["mcu_maria", 128], ["k.tanaka", 124], ["firmwarefox", 119], ["lena.b", 113],
] as const;

function Index() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <header className="sticky top-0 z-20 border-b bg-background">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-8 px-4">
          <span className="text-2xl font-bold tracking-tight">
            Bit<span className="text-primary">Forge</span>
          </span>
          <nav className="hidden items-center gap-6 text-[17px] sm:flex">
            <button className="flex items-center gap-1">Skills <ChevronDown className="h-4 w-4" /></button>
            <a href="#">Tests</a>
          </nav>
          <div className="ml-auto flex items-center gap-6 text-muted-foreground">
            <span className="relative"><Bell className="h-5 w-5" /><span className="absolute -right-2 -top-2 rounded-full bg-destructive px-1.5 text-[10px] text-destructive-foreground">1</span></span>
            <Plus className="h-5 w-5" />
            <Moon className="h-5 w-5" />
            <button className="rounded-md bg-primary px-12 py-2 text-sm font-medium text-primary-foreground">Login</button>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="hero-grid absolute inset-0" />
        <div className="relative flex flex-col items-center px-4 py-20 text-center">
          <div className="flex h-24 w-24 items-center justify-center rounded-md bg-gold text-7xl font-bold text-primary-foreground">C</div>
          <h1 className="mt-4 text-4xl font-bold">Embedded C Programming</h1>
          <p className="mt-3 text-muted-foreground">Core C skills every firmware engineer needs.</p>
        </div>
      </section>

      <main className="mx-auto grid max-w-6xl gap-12 px-4 pb-20 lg:grid-cols-[1fr_350px]">
        <div className="space-y-8">
          {sections.map((s) => (
            <div key={s.name} className="overflow-hidden rounded-md border">
              <div className="flex items-center justify-between border-b bg-muted/50 px-3 py-3">
                <h2 className="text-lg font-medium">{s.name}</h2>
                <a href="#" className="flex items-center gap-1 text-primary"><FileText className="h-4 w-4" />Quick Guide</a>
              </div>
              {s.items.map((it) => (
                <a key={it.t} href="#" className="flex items-center gap-6 border-b px-7 py-3 text-lg last:border-0 hover:bg-muted/40">
                  <Circle className="h-5 w-5 shrink-0 text-border" />
                  <span className="flex-1">{it.t}</span>
                  <span className={it.k === "Task" ? "text-base text-gold" : "text-base text-primary"}>{it.k}</span>
                </a>
              ))}
            </div>
          ))}
        </div>

        <aside className="space-y-8 lg:sticky lg:top-24 lg:self-start">
          <button className="flex w-full items-center justify-center gap-3 rounded-md border border-primary bg-primary/5 py-2.5 font-medium text-primary"><Rocket className="h-4 w-4" />Quick Start Guide</button>
          <button className="flex w-full items-center justify-center gap-3 rounded-md border py-2.5 font-medium"><FileText className="h-4 w-4" />View Quick Guides</button>
          <div className="rounded-xl border p-6 text-center">
            <h3 className="font-medium">Your Achievements</h3>
            <div className="mx-auto mt-6 flex h-28 w-28 items-center justify-center rounded-full border-4 border-muted bg-muted/50 text-4xl font-bold text-muted-foreground">C</div>
          </div>
          <div className="rounded-xl border p-6">
            <div className="mb-4 flex justify-between"><h3 className="font-medium">Leaderboard</h3><span className="text-sm text-muted-foreground">Top <b className="text-foreground">20</b> of <b className="text-foreground">5K</b></span></div>
            <div className="divide-y rounded-md border">
              {leaders.map(([n, c], i) => (
                <div key={n} className="flex items-center gap-4 px-6 py-4">
                  <span className="w-4 text-xl font-semibold text-gold">{i + 1}</span>
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/15 font-semibold text-primary">{n.charAt(0).toUpperCase()}</div>
                  <div><div className="text-sm">{n}</div><div className="text-xs text-muted-foreground">Solved {c} problems</div></div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
}
