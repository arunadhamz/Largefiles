# ============================================================================
# LoadingScreenDemo.pro - Qt Project File
# ============================================================================

QT += core gui widgets network

CONFIG += c++17

TARGET = LoadingScreenDemo
TEMPLATE = app

HEADERS += \
    LoadingScreen.h \
    ConnectionManager.h

SOURCES += \
    main.cpp
