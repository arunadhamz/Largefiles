# Qt C++ Loading Screens - Quick Reference

## 15 Loading Screen Models

| #  | Class Name              | Visual Style                                      |
|----|-------------------------|---------------------------------------------------|
| 1  | `LoadingSpinningArc`    | Classic spinning arc spinner                      |
| 2  | `LoadingPulsatingDots`  | 8 dots in circle, pulsating size & opacity        |
| 3  | `LoadingWaveBar`        | Horizontal progress bar with wave animation       |
| 4  | `LoadingRotatingCubes`  | 3 colored cubes rotating & scaling                |
| 5  | `LoadingDNAHelix`       | Double helix with connecting lines (3D depth)     |
| 6  | `LoadingRadarSweep`     | Radar screen with rotating sweep line             |
| 7  | `LoadingBouncingBalls`  | 5 colored balls bouncing with shadows             |
| 8  | `LoadingMatrixRain`     | Matrix-style falling katakana characters          |
| 9  | `LoadingOrbitRings`     | 3 planets orbiting a central sun                  |
| 10 | `LoadingHeartbeat`      | ECG / heartbeat line with glow effect             |
| 11 | `LoadingGears`          | 2 interlocking gears rotating                     |
| 12 | `LoadingParticleVortex` | 60 rainbow particles in spiral vortex             |
| 13 | `LoadingFlipDots`       | 5x7 dot grid with wave ripple effect              |
| 14 | `LoadingWifiPulse`      | WiFi signal arcs pulsing outward                  |
| 15 | `LoadingGradientRing`   | Rainbow gradient ring with % counter              |

## Quick Usage (Standalone)

```cpp
// Create any loading screen
LoadingRadarSweep *loader = new LoadingRadarSweep(parentWidget);
loader->setStatusText("Please wait...");
loader->start();   // Shows and animates

// Later...
loader->stop();    // Hides and stops animation
```

## Usage with ConnectionManager

```cpp
// 1. Create manager
ConnectionManager *conn = new ConnectionManager(this /*parentWidget*/, this);

// 2. Pick a loading model
conn->setLoadingModel(ConnectionManager::RadarSweep);

// 3. Connect signals
connect(conn, &ConnectionManager::connectionSuccess, this, [](){ /* handle */ });
connect(conn, &ConnectionManager::connectionFailed,  this, [](const QString &e){ /* handle */ });

// 4. Connect — loading screen appears automatically
conn->connectToServer("192.168.1.100", 8080, 10000);
```

## Build

```bash
qmake LoadingScreenDemo.pro
make
./LoadingScreenDemo
```

## Customization Tips

- Change colors in each model's `paintEvent()`
- Adjust speed: modify the `m_angle` increment in `onTick()`
- Resize: change `setFixedSize()` in base class constructor
- Add your own model: inherit `LoadingScreenBase`, override `paintEvent()`
