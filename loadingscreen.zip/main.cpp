// ============================================================================
// main.cpp - Example usage of ConnectionManager with Loading Screens
// ============================================================================

#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>
#include <QComboBox>
#include <QLineEdit>
#include <QLabel>
#include <QMessageBox>
#include <QSpinBox>
#include "ConnectionManager.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr) : QMainWindow(parent)
    {
        setWindowTitle("Loading Screen Demo - Connection Test");
        setFixedSize(500, 400);

        QWidget *central = new QWidget(this);
        QVBoxLayout *layout = new QVBoxLayout(central);
        layout->setSpacing(12);
        layout->setContentsMargins(30, 20, 30, 20);

        // Title
        QLabel *title = new QLabel("Qt Loading Screen Demo");
        title->setFont(QFont("Segoe UI", 18, QFont::Bold));
        title->setAlignment(Qt::AlignCenter);
        layout->addWidget(title);

        // Model selector
        layout->addWidget(new QLabel("Select Loading Screen Model:"));
        m_modelCombo = new QComboBox();
        m_modelCombo->addItem("1  - Spinning Arc",     ConnectionManager::SpinningArc);
        m_modelCombo->addItem("2  - Pulsating Dots",   ConnectionManager::PulsatingDots);
        m_modelCombo->addItem("3  - Wave Bar",         ConnectionManager::WaveBar);
        m_modelCombo->addItem("4  - Rotating Cubes",   ConnectionManager::RotatingCubes);
        m_modelCombo->addItem("5  - DNA Helix",        ConnectionManager::DNAHelix);
        m_modelCombo->addItem("6  - Radar Sweep",      ConnectionManager::RadarSweep);
        m_modelCombo->addItem("7  - Bouncing Balls",   ConnectionManager::BouncingBalls);
        m_modelCombo->addItem("8  - Matrix Rain",      ConnectionManager::MatrixRain);
        m_modelCombo->addItem("9  - Orbit Rings",      ConnectionManager::OrbitRings);
        m_modelCombo->addItem("10 - Heartbeat / ECG",  ConnectionManager::Heartbeat);
        m_modelCombo->addItem("11 - Gears",            ConnectionManager::Gears);
        m_modelCombo->addItem("12 - Particle Vortex",  ConnectionManager::ParticleVortex);
        m_modelCombo->addItem("13 - Flip Dots",        ConnectionManager::FlipDots);
        m_modelCombo->addItem("14 - Wifi Pulse",       ConnectionManager::WifiPulse);
        m_modelCombo->addItem("15 - Gradient Ring",    ConnectionManager::GradientRing);
        layout->addWidget(m_modelCombo);

        // Host & Port
        layout->addWidget(new QLabel("Host:"));
        m_hostEdit = new QLineEdit("192.168.1.100");
        layout->addWidget(m_hostEdit);

        QHBoxLayout *portLayout = new QHBoxLayout();
        portLayout->addWidget(new QLabel("Port:"));
        m_portSpin = new QSpinBox();
        m_portSpin->setRange(1, 65535);
        m_portSpin->setValue(8080);
        portLayout->addWidget(m_portSpin);
        layout->addLayout(portLayout);

        // Connect button
        m_connectBtn = new QPushButton("Connect");
        m_connectBtn->setFixedHeight(45);
        m_connectBtn->setFont(QFont("Segoe UI", 12, QFont::Bold));
        m_connectBtn->setStyleSheet(
            "QPushButton { background: #0078D4; color: white; border-radius: 8px; }"
            "QPushButton:hover { background: #1A8AE8; }"
            "QPushButton:pressed { background: #005A9E; }"
        );
        layout->addWidget(m_connectBtn);

        // Status label
        m_statusLabel = new QLabel("Status: Idle");
        m_statusLabel->setAlignment(Qt::AlignCenter);
        layout->addWidget(m_statusLabel);

        layout->addStretch();
        setCentralWidget(central);

        // ---------------------------------------------------------------
        // CREATE ConnectionManager AND WIRE SIGNALS
        // ---------------------------------------------------------------
        m_connMgr = new ConnectionManager(this, this);

        connect(m_connectBtn, &QPushButton::clicked, this, &MainWindow::onConnectClicked);

        connect(m_connMgr, &ConnectionManager::connectionSuccess, this, [this]() {
            m_statusLabel->setText("Status: Connected!");
            m_statusLabel->setStyleSheet("color: green; font-weight: bold;");
        });

        connect(m_connMgr, &ConnectionManager::connectionFailed, this, [this](const QString &err) {
            m_statusLabel->setText("Status: Failed - " + err);
            m_statusLabel->setStyleSheet("color: red;");
        });

        connect(m_connMgr, &ConnectionManager::connectionLost, this, [this]() {
            m_statusLabel->setText("Status: Disconnected");
            m_statusLabel->setStyleSheet("color: orange;");
        });
    }

private slots:
    void onConnectClicked()
    {
        // 1) Set the loading model from combo box
        auto model = static_cast<ConnectionManager::LoadingModel>(
            m_modelCombo->currentData().toInt()
        );
        m_connMgr->setLoadingModel(model);

        // 2) Start the connection (loading screen appears automatically)
        QString host = m_hostEdit->text().trimmed();
        quint16 port = (quint16)m_portSpin->value();

        m_statusLabel->setText("Status: Connecting...");
        m_statusLabel->setStyleSheet("color: #0078D4;");

        m_connMgr->connectToServer(host, port, 8000); // 8 sec timeout
    }

private:
    ConnectionManager *m_connMgr;
    QComboBox   *m_modelCombo;
    QLineEdit   *m_hostEdit;
    QSpinBox    *m_portSpin;
    QPushButton *m_connectBtn;
    QLabel      *m_statusLabel;
};


// ============================================================================
// main()
// ============================================================================
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    MainWindow window;
    window.show();
    return app.exec();
}

#include "main.moc"
