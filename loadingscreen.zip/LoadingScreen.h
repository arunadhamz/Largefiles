#ifndef LOADINGSCREEN_H
#define LOADINGSCREEN_H

#include <QWidget>
#include <QTimer>
#include <QPainter>
#include <QPainterPath>
#include <QLabel>
#include <QVBoxLayout>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include <QtMath>
#include <QFont>
#include <QColor>
#include <QLinearGradient>
#include <QRadialGradient>
#include <QConicalGradient>
#include <QElapsedTimer>

// ============================================================================
// BASE CLASS - All loading screens inherit from this
// ============================================================================
class LoadingScreenBase : public QWidget
{
    Q_OBJECT

public:
    explicit LoadingScreenBase(QWidget *parent = nullptr)
        : QWidget(parent), m_angle(0), m_statusText("Connecting...")
    {
        setAttribute(Qt::WA_TranslucentBackground);
        setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
        setFixedSize(400, 300);

        m_timer = new QTimer(this);
        connect(m_timer, &QTimer::timeout, this, &LoadingScreenBase::onTick);
    }

    virtual ~LoadingScreenBase() = default;

    void start() {
        m_angle = 0;
        m_timer->start(16); // ~60 FPS
        show();
    }

    void stop() {
        m_timer->stop();
        hide();
    }

    void setStatusText(const QString &text) {
        m_statusText = text;
        update();
    }

protected:
    QTimer *m_timer;
    int m_angle;
    QString m_statusText;

    virtual void onTick() {
        m_angle = (m_angle + 3) % 360;
        update();
    }

    void drawBackground(QPainter &p) {
        p.setRenderHint(QPainter::Antialiasing);
        p.setBrush(QColor(30, 30, 40, 230));
        p.setPen(Qt::NoPen);
        p.drawRoundedRect(rect(), 15, 15);
    }

    void drawStatusText(QPainter &p) {
        p.setPen(QColor(200, 200, 220));
        p.setFont(QFont("Segoe UI", 11));
        p.drawText(QRect(0, height() - 50, width(), 40),
                   Qt::AlignCenter, m_statusText);
    }
};


// ============================================================================
// MODEL 1: Spinning Arc (Classic Spinner)
// ============================================================================
class LoadingSpinningArc : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingSpinningArc(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        QRect arcRect(width()/2 - 40, height()/2 - 60, 80, 80);
        QPen pen(QColor(0, 180, 255), 5, Qt::SolidLine, Qt::RoundCap);
        p.setPen(pen);
        p.drawArc(arcRect, m_angle * 16, 270 * 16);

        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 2: Pulsating Dots
// ============================================================================
class LoadingPulsatingDots : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingPulsatingDots(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int centerX = width() / 2;
        int centerY = height() / 2 - 20;
        int dotCount = 8;

        for (int i = 0; i < dotCount; ++i) {
            qreal phase = qDegreesToRadians((qreal)(m_angle + i * (360 / dotCount)));
            qreal scale = (qSin(phase) + 1.0) / 2.0;
            int radius = 4 + (int)(scale * 8);
            int alpha = 80 + (int)(scale * 175);

            qreal dx = qCos(qDegreesToRadians((qreal)(i * 360 / dotCount))) * 50;
            qreal dy = qSin(qDegreesToRadians((qreal)(i * 360 / dotCount))) * 50;

            p.setBrush(QColor(0, 200, 150, alpha));
            p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(centerX + dx, centerY + dy), radius, radius);
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 3: Progress Bar Wave
// ============================================================================
class LoadingWaveBar : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingWaveBar(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int barY = height() / 2 - 10;
        int barW = 300;
        int barH = 8;
        int startX = (width() - barW) / 2;

        // Track
        p.setBrush(QColor(60, 60, 80));
        p.setPen(Qt::NoPen);
        p.drawRoundedRect(startX, barY, barW, barH, 4, 4);

        // Wave fill
        for (int x = 0; x < barW; ++x) {
            qreal wave = qSin(qDegreesToRadians((qreal)(m_angle * 3 + x * 4))) * 0.3 + 0.7;
            qreal pos = (qreal)x / barW;
            qreal pulse = qSin(qDegreesToRadians((qreal)(m_angle * 2))) * 0.5 + 0.5;
            if (pos < pulse) {
                int alpha = (int)(wave * 255);
                p.setPen(QColor(80, 160, 255, alpha));
                p.drawLine(startX + x, barY, startX + x, barY + barH);
            }
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 4: Rotating Cubes
// ============================================================================
class LoadingRotatingCubes : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingRotatingCubes(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int cy = height() / 2 - 20;

        for (int i = 0; i < 3; ++i) {
            qreal phase = qDegreesToRadians((qreal)(m_angle + i * 120));
            qreal scale = (qSin(phase) + 1.0) / 2.0;
            int size = 15 + (int)(scale * 20);
            int offset = (i - 1) * 55;

            p.save();
            p.translate(cx + offset, cy);
            p.rotate(m_angle + i * 45);

            QColor color;
            if (i == 0) color = QColor(255, 100, 100, 200);
            else if (i == 1) color = QColor(100, 255, 100, 200);
            else color = QColor(100, 100, 255, 200);

            p.setBrush(color);
            p.setPen(Qt::NoPen);
            p.drawRect(-size/2, -size/2, size, size);
            p.restore();
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 5: DNA Helix
// ============================================================================
class LoadingDNAHelix : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingDNAHelix(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int cy = height() / 2 - 20;
        int points = 20;

        for (int i = 0; i < points; ++i) {
            qreal t = qDegreesToRadians((qreal)(m_angle * 2 + i * 18));
            qreal x1 = qCos(t) * 60;
            qreal x2 = qCos(t + M_PI) * 60;
            qreal y = (i - points / 2) * 8;
            qreal z1 = (qSin(t) + 1.0) / 2.0;
            qreal z2 = (qSin(t + M_PI) + 1.0) / 2.0;

            // Connecting line
            p.setPen(QPen(QColor(100, 100, 150, 80), 1));
            p.drawLine(QPointF(cx + x1, cy + y), QPointF(cx + x2, cy + y));

            // Strand 1
            int r1 = 3 + (int)(z1 * 5);
            p.setBrush(QColor(0, 200, 255, 80 + (int)(z1 * 175)));
            p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(cx + x1, cy + y), r1, r1);

            // Strand 2
            int r2 = 3 + (int)(z2 * 5);
            p.setBrush(QColor(255, 100, 200, 80 + (int)(z2 * 175)));
            p.drawEllipse(QPointF(cx + x2, cy + y), r2, r2);
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 6: Radar Sweep
// ============================================================================
class LoadingRadarSweep : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingRadarSweep(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int cy = height() / 2 - 20;
        int radius = 60;

        // Rings
        p.setPen(QPen(QColor(0, 255, 100, 40), 1));
        p.setBrush(Qt::NoBrush);
        for (int i = 1; i <= 3; ++i)
            p.drawEllipse(QPointF(cx, cy), radius * i / 3, radius * i / 3);

        // Cross
        p.drawLine(cx - radius, cy, cx + radius, cy);
        p.drawLine(cx, cy - radius, cx, cy + radius);

        // Sweep cone
        QConicalGradient cg(cx, cy, -m_angle);
        cg.setColorAt(0.0, QColor(0, 255, 100, 150));
        cg.setColorAt(0.15, QColor(0, 255, 100, 0));
        cg.setColorAt(1.0, QColor(0, 255, 100, 0));

        p.setBrush(cg);
        p.setPen(Qt::NoPen);
        p.drawEllipse(QPointF(cx, cy), radius, radius);

        // Sweep line
        qreal rad = qDegreesToRadians((qreal)m_angle);
        p.setPen(QPen(QColor(0, 255, 100, 200), 2));
        p.drawLine(QPointF(cx, cy),
                   QPointF(cx + qCos(rad) * radius, cy + qSin(rad) * radius));

        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 7: Bouncing Balls
// ============================================================================
class LoadingBouncingBalls : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingBouncingBalls(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int baseY = height() / 2 + 20;
        QColor colors[] = {
            QColor(255, 80, 80), QColor(80, 200, 255),
            QColor(255, 200, 50), QColor(80, 255, 150), QColor(200, 100, 255)
        };

        for (int i = 0; i < 5; ++i) {
            qreal phase = qDegreesToRadians((qreal)(m_angle * 3 + i * 40));
            qreal bounce = qAbs(qSin(phase)) * 80;
            int x = cx + (i - 2) * 35;
            int y = baseY - (int)bounce;

            // Shadow
            p.setBrush(QColor(0, 0, 0, 50));
            p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(x, baseY + 5), 10, 3);

            // Ball
            QRadialGradient rg(x - 3, y - 3, 14);
            rg.setColorAt(0, colors[i].lighter(150));
            rg.setColorAt(1, colors[i]);
            p.setBrush(rg);
            p.drawEllipse(QPointF(x, y), 12, 12);
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 8: Matrix Rain
// ============================================================================
class LoadingMatrixRain : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingMatrixRain(QWidget *parent = nullptr)
        : LoadingScreenBase(parent)
    {
        m_font = QFont("Courier", 10, QFont::Bold);
        for (int i = 0; i < 20; ++i) {
            m_drops.append(qrand() % 300);
        }
    }

protected:
    QFont m_font;
    QList<int> m_drops;

    void onTick() override {
        m_angle = (m_angle + 3) % 360;
        for (int i = 0; i < m_drops.size(); ++i) {
            m_drops[i] += 3 + (i % 5);
            if (m_drops[i] > 280) m_drops[i] = 0;
        }
        update();
    }

    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);
        p.setFont(m_font);

        int startX = 50;
        for (int i = 0; i < m_drops.size(); ++i) {
            int x = startX + i * 16;
            int y = m_drops[i];

            for (int j = 0; j < 8; ++j) {
                int charY = y - j * 14;
                if (charY < 10 || charY > 270) continue;
                int alpha = 255 - j * 30;
                if (alpha < 0) alpha = 0;

                QColor color = (j == 0) ? QColor(200, 255, 200, alpha)
                                        : QColor(0, 180, 0, alpha);
                p.setPen(color);
                QChar ch((ushort)(0x30A0 + (qrand() % 96))); // Katakana chars
                p.drawText(x, charY, QString(ch));
            }
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 9: Orbit Rings
// ============================================================================
class LoadingOrbitRings : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingOrbitRings(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int cy = height() / 2 - 20;

        // Center dot
        p.setBrush(QColor(255, 220, 100));
        p.setPen(Qt::NoPen);
        p.drawEllipse(QPointF(cx, cy), 8, 8);

        // 3 orbit rings
        struct Orbit { int rx; int ry; qreal speed; QColor color; };
        Orbit orbits[] = {
            {35, 20, 1.0, QColor(0, 180, 255)},
            {55, 30, 0.7, QColor(255, 100, 150)},
            {75, 40, 0.4, QColor(100, 255, 180)}
        };

        for (int i = 0; i < 3; ++i) {
            // Orbit path
            p.setPen(QPen(orbits[i].color.darker(200), 1, Qt::DashLine));
            p.setBrush(Qt::NoBrush);
            p.drawEllipse(QPointF(cx, cy), orbits[i].rx, orbits[i].ry);

            // Planet
            qreal rad = qDegreesToRadians(m_angle * orbits[i].speed);
            qreal px = cx + qCos(rad) * orbits[i].rx;
            qreal py = cy + qSin(rad) * orbits[i].ry;

            p.setBrush(orbits[i].color);
            p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(px, py), 6, 6);
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 10: Heartbeat / ECG Line
// ============================================================================
class LoadingHeartbeat : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingHeartbeat(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cy = height() / 2 - 20;
        int startX = 40;
        int endX = width() - 40;

        QPainterPath path;
        path.moveTo(startX, cy);

        for (int x = startX; x < endX; ++x) {
            qreal t = (qreal)(x - startX) / (endX - startX);
            qreal shifted = t * 360 + m_angle * 3;
            qreal mod = fmod(shifted, 360.0);
            qreal y = 0;

            // ECG spike pattern
            if (mod > 160 && mod < 170) y = -30;
            else if (mod > 170 && mod < 175) y = 40;
            else if (mod > 175 && mod < 185) y = -50;
            else if (mod > 185 && mod < 195) y = 25;
            else if (mod > 195 && mod < 200) y = -10;
            else y = qSin(qDegreesToRadians(mod * 0.5)) * 3;

            path.lineTo(x, cy + y);
        }

        // Glow effect
        p.setPen(QPen(QColor(0, 255, 100, 40), 6, Qt::SolidLine, Qt::RoundCap));
        p.drawPath(path);
        p.setPen(QPen(QColor(0, 255, 100, 200), 2, Qt::SolidLine, Qt::RoundCap));
        p.drawPath(path);

        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 11: Gear Rotation
// ============================================================================
class LoadingGears : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingGears(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void drawGear(QPainter &p, int cx, int cy, int outerR, int innerR,
                  int teeth, qreal angle, QColor color) {
        QPainterPath path;
        int steps = teeth * 2;
        for (int i = 0; i <= steps; ++i) {
            qreal a = qDegreesToRadians(angle + (qreal)i * 360.0 / steps);
            int r = (i % 2 == 0) ? outerR : innerR;
            qreal x = cx + qCos(a) * r;
            qreal y = cy + qSin(a) * r;
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.closeSubpath();

        // Cut center hole
        QPainterPath hole;
        hole.addEllipse(QPointF(cx, cy), innerR * 0.4, innerR * 0.4);

        p.setBrush(color);
        p.setPen(QPen(color.darker(130), 1));
        p.drawPath(path.subtracted(hole));
    }

    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        drawGear(p, width()/2 - 30, height()/2 - 30, 35, 25, 10,
                 m_angle, QColor(100, 160, 255, 200));
        drawGear(p, width()/2 + 25, height()/2 + 5, 25, 18, 8,
                 -m_angle * 1.25, QColor(255, 160, 80, 200));

        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 12: Particle Vortex
// ============================================================================
class LoadingParticleVortex : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingParticleVortex(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int cy = height() / 2 - 20;
        int count = 60;

        for (int i = 0; i < count; ++i) {
            qreal t = (qreal)i / count;
            qreal spiralAngle = qDegreesToRadians(m_angle * 2 + t * 720);
            qreal radius = 10 + t * 55;
            qreal x = cx + qCos(spiralAngle) * radius;
            qreal y = cy + qSin(spiralAngle) * radius;

            int alpha = (int)(t * 200) + 55;
            qreal size = 1.5 + t * 3;

            QColor color;
            color.setHsvF(t * 0.6 + fmod(m_angle / 360.0, 1.0), 0.8, 1.0, alpha / 255.0);
            p.setBrush(color);
            p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(x, y), size, size);
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 13: Flip Clock Dots
// ============================================================================
class LoadingFlipDots : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingFlipDots(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int rows = 5, cols = 7;
        int dotSize = 10;
        int spacing = 18;
        int startX = width()/2 - (cols * spacing) / 2;
        int startY = height()/2 - (rows * spacing) / 2 - 10;

        for (int r = 0; r < rows; ++r) {
            for (int c = 0; c < cols; ++c) {
                int x = startX + c * spacing;
                int y = startY + r * spacing;

                qreal dist = qSqrt((r - rows/2.0) * (r - rows/2.0) +
                                   (c - cols/2.0) * (c - cols/2.0));
                qreal phase = qDegreesToRadians(m_angle * 3 - dist * 40);
                qreal flip = (qSin(phase) + 1.0) / 2.0;

                QColor on(0, 200, 255);
                QColor off(40, 50, 60);
                int re = off.red() + (int)(flip * (on.red() - off.red()));
                int ge = off.green() + (int)(flip * (on.green() - off.green()));
                int be = off.blue() + (int)(flip * (on.blue() - off.blue()));

                p.setBrush(QColor(re, ge, be));
                p.setPen(Qt::NoPen);
                p.drawRoundedRect(x, y, dotSize, dotSize, 2, 2);
            }
        }
        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 14: Wifi Signal Pulse
// ============================================================================
class LoadingWifiPulse : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingWifiPulse(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int cy = height() / 2 + 10;

        // Wifi arcs (3 levels)
        for (int i = 0; i < 3; ++i) {
            qreal phase = qDegreesToRadians((qreal)(m_angle * 3 - i * 60));
            qreal pulse = (qSin(phase) + 1.0) / 2.0;
            int alpha = 60 + (int)(pulse * 195);

            int arcRadius = 25 + i * 22;
            QRect arcRect(cx - arcRadius, cy - arcRadius,
                          arcRadius * 2, arcRadius * 2);

            p.setPen(QPen(QColor(0, 180, 255, alpha), 4, Qt::SolidLine, Qt::RoundCap));
            p.setBrush(Qt::NoBrush);
            p.drawArc(arcRect, 45 * 16, 90 * 16); // Upper arc
        }

        // Center dot
        qreal dotPulse = (qSin(qDegreesToRadians((qreal)(m_angle * 4))) + 1.0) / 2.0;
        int dotR = 5 + (int)(dotPulse * 4);
        p.setBrush(QColor(0, 220, 255));
        p.setPen(Qt::NoPen);
        p.drawEllipse(QPointF(cx, cy), dotR, dotR);

        // Label
        p.setPen(QColor(200, 200, 220));
        p.setFont(QFont("Segoe UI", 9));
        p.drawText(QRect(0, cy - 85, width(), 30),
                   Qt::AlignCenter, "Establishing Connection...");

        drawStatusText(p);
    }
};


// ============================================================================
// MODEL 15: Gradient Ring Morph
// ============================================================================
class LoadingGradientRing : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingGradientRing(QWidget *parent = nullptr)
        : LoadingScreenBase(parent) {}

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawBackground(p);

        int cx = width() / 2;
        int cy = height() / 2 - 20;
        int outerR = 55;
        int innerR = 35;

        // Rotating gradient ring
        QConicalGradient cg(cx, cy, m_angle);
        cg.setColorAt(0.0,  QColor(255, 50, 100));
        cg.setColorAt(0.25, QColor(255, 200, 50));
        cg.setColorAt(0.5,  QColor(50, 200, 255));
        cg.setColorAt(0.75, QColor(150, 50, 255));
        cg.setColorAt(1.0,  QColor(255, 50, 100));

        QPainterPath outer;
        outer.addEllipse(QPointF(cx, cy), outerR, outerR);
        QPainterPath inner;
        inner.addEllipse(QPointF(cx, cy), innerR, innerR);
        QPainterPath ring = outer.subtracted(inner);

        p.setBrush(cg);
        p.setPen(Qt::NoPen);
        p.drawPath(ring);

        // Percentage text in center
        int pct = m_angle * 100 / 360;
        p.setPen(QColor(255, 255, 255, 220));
        p.setFont(QFont("Segoe UI", 16, QFont::Bold));
        p.drawText(QRect(cx - 30, cy - 15, 60, 30),
                   Qt::AlignCenter, QString::number(pct) + "%");

        drawStatusText(p);
    }
};

#endif // LOADINGSCREEN_H
