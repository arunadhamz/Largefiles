// ============================================================================
// ConnectionManager.h
// Shows how to use any of the 15 loading screens during network connections
// ============================================================================

#ifndef CONNECTIONMANAGER_H
#define CONNECTIONMANAGER_H

#include <QObject>
#include <QTcpSocket>
#include <QTimer>
#include <QDebug>
#include "LoadingScreen.h"

// ============================================================================
// CONNECTION CLASS - Integrates loading screen with actual network connection
// ============================================================================
class ConnectionManager : public QObject
{
    Q_OBJECT

public:
    // Enum to select which loading screen model to use
    enum LoadingModel {
        SpinningArc = 1,
        PulsatingDots,
        WaveBar,
        RotatingCubes,
        DNAHelix,
        RadarSweep,
        BouncingBalls,
        MatrixRain,
        OrbitRings,
        Heartbeat,
        Gears,
        ParticleVortex,
        FlipDots,
        WifiPulse,
        GradientRing
    };

    explicit ConnectionManager(QWidget *parentWidget, QObject *parent = nullptr)
        : QObject(parent), m_parentWidget(parentWidget), m_loadingScreen(nullptr)
    {
        m_socket = new QTcpSocket(this);
        m_timeoutTimer = new QTimer(this);
        m_timeoutTimer->setSingleShot(true);

        // Socket signals
        connect(m_socket, &QTcpSocket::connected,
                this, &ConnectionManager::onConnected);
        connect(m_socket, &QTcpSocket::disconnected,
                this, &ConnectionManager::onDisconnected);
        connect(m_socket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),
                this, &ConnectionManager::onError);

        // Timeout signal
        connect(m_timeoutTimer, &QTimer::timeout,
                this, &ConnectionManager::onTimeout);
    }

    ~ConnectionManager() {
        delete m_loadingScreen;
    }

    // -----------------------------------------------------------------------
    // Set which loading screen model to use (1-15)
    // -----------------------------------------------------------------------
    void setLoadingModel(LoadingModel model) {
        m_selectedModel = model;
    }

    // -----------------------------------------------------------------------
    // Start connection - shows loading screen automatically
    // -----------------------------------------------------------------------
    void connectToServer(const QString &host, quint16 port, int timeoutMs = 10000)
    {
        m_host = host;
        m_port = port;

        // Create and show loading screen
        createLoadingScreen();
        if (m_loadingScreen) {
            m_loadingScreen->setStatusText("Connecting to " + host + "...");
            m_loadingScreen->start();

            // Center on parent widget
            if (m_parentWidget) {
                QPoint center = m_parentWidget->geometry().center();
                m_loadingScreen->move(center.x() - m_loadingScreen->width() / 2,
                                      center.y() - m_loadingScreen->height() / 2);
            }
        }

        // Start connection
        m_socket->connectToHost(host, port);
        m_timeoutTimer->start(timeoutMs);

        qDebug() << "[ConnectionManager] Connecting to" << host << ":" << port;
    }

    // -----------------------------------------------------------------------
    // Disconnect
    // -----------------------------------------------------------------------
    void disconnect() {
        hideLoading();
        m_socket->disconnectFromHost();
    }

    bool isConnected() const {
        return m_socket->state() == QAbstractSocket::ConnectedState;
    }

signals:
    void connectionSuccess();
    void connectionFailed(const QString &errorMsg);
    void connectionLost();

private slots:
    void onConnected() {
        m_timeoutTimer->stop();
        if (m_loadingScreen) {
            m_loadingScreen->setStatusText("Connected!");
        }
        // Small delay so user sees "Connected!" message
        QTimer::singleShot(500, this, [this]() {
            hideLoading();
            emit connectionSuccess();
        });
        qDebug() << "[ConnectionManager] Connected successfully!";
    }

    void onDisconnected() {
        hideLoading();
        emit connectionLost();
        qDebug() << "[ConnectionManager] Disconnected.";
    }

    void onError(QAbstractSocket::SocketError socketError) {
        Q_UNUSED(socketError)
        m_timeoutTimer->stop();
        QString errMsg = m_socket->errorString();
        if (m_loadingScreen) {
            m_loadingScreen->setStatusText("Error: " + errMsg);
        }
        QTimer::singleShot(1500, this, [this, errMsg]() {
            hideLoading();
            emit connectionFailed(errMsg);
        });
        qDebug() << "[ConnectionManager] Error:" << errMsg;
    }

    void onTimeout() {
        m_socket->abort();
        if (m_loadingScreen) {
            m_loadingScreen->setStatusText("Connection timed out!");
        }
        QTimer::singleShot(1500, this, [this]() {
            hideLoading();
            emit connectionFailed("Connection timed out");
        });
        qDebug() << "[ConnectionManager] Connection timed out.";
    }

private:
    // -----------------------------------------------------------------------
    // Create the selected loading screen model
    // -----------------------------------------------------------------------
    void createLoadingScreen() {
        delete m_loadingScreen;
        m_loadingScreen = nullptr;

        switch (m_selectedModel) {
        case SpinningArc:    m_loadingScreen = new LoadingSpinningArc(m_parentWidget);    break;
        case PulsatingDots:  m_loadingScreen = new LoadingPulsatingDots(m_parentWidget);  break;
        case WaveBar:        m_loadingScreen = new LoadingWaveBar(m_parentWidget);        break;
        case RotatingCubes:  m_loadingScreen = new LoadingRotatingCubes(m_parentWidget);  break;
        case DNAHelix:       m_loadingScreen = new LoadingDNAHelix(m_parentWidget);       break;
        case RadarSweep:     m_loadingScreen = new LoadingRadarSweep(m_parentWidget);     break;
        case BouncingBalls:  m_loadingScreen = new LoadingBouncingBalls(m_parentWidget);  break;
        case MatrixRain:     m_loadingScreen = new LoadingMatrixRain(m_parentWidget);     break;
        case OrbitRings:     m_loadingScreen = new LoadingOrbitRings(m_parentWidget);     break;
        case Heartbeat:      m_loadingScreen = new LoadingHeartbeat(m_parentWidget);      break;
        case Gears:          m_loadingScreen = new LoadingGears(m_parentWidget);          break;
        case ParticleVortex: m_loadingScreen = new LoadingParticleVortex(m_parentWidget); break;
        case FlipDots:       m_loadingScreen = new LoadingFlipDots(m_parentWidget);       break;
        case WifiPulse:      m_loadingScreen = new LoadingWifiPulse(m_parentWidget);      break;
        case GradientRing:   m_loadingScreen = new LoadingGradientRing(m_parentWidget);   break;
        default:             m_loadingScreen = new LoadingSpinningArc(m_parentWidget);    break;
        }
    }

    void hideLoading() {
        if (m_loadingScreen) {
            m_loadingScreen->stop();
        }
    }

    QWidget        *m_parentWidget;
    QTcpSocket     *m_socket;
    QTimer         *m_timeoutTimer;
    LoadingScreenBase *m_loadingScreen;
    LoadingModel    m_selectedModel = SpinningArc;
    QString         m_host;
    quint16         m_port;
};

#endif // CONNECTIONMANAGER_H
