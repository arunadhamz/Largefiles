#ifndef LOADINGSCREEN_H
#define LOADINGSCREEN_H

#include <QWidget>
#include <QTimer>
#include <QPainter>
#include <QPainterPath>
#include <QElapsedTimer>
#include <QtMath>
#include <QFont>
#include <QColor>
#include <QConicalGradient>
#include <QRadialGradient>
#include <QEvent>
#include <QResizeEvent>

// ============================================================================
// BASE CLASS - Full overlay that covers parent widget
// Key features:
//   - Minimum display time (so fast connections still show the animation)
//   - start() / stop() / forceStop()
//   - Blocks mouse clicks to parent while visible
// ============================================================================
class LoadingScreenBase : public QWidget
{
    Q_OBJECT

public:
    explicit LoadingScreenBase(QWidget *parent = nullptr)
        : QWidget(parent), m_angle(0), m_statusText("Connecting..."),
          m_minDisplayMs(2000), m_wantClose(false)
    {
        if (parent) {
            setGeometry(parent->rect());
            parent->installEventFilter(this);
        }
        setAutoFillBackground(false);
        setFocusPolicy(Qt::StrongFocus);

        m_animTimer = new QTimer(this);
        connect(m_animTimer, &QTimer::timeout, this, &LoadingScreenBase::onTick);
    }

    virtual ~LoadingScreenBase() = default;

    void setMinimumDisplayTime(int ms) { m_minDisplayMs = ms; }

    // Show overlay, begin animation
    void start()
    {
        m_angle = 0;
        m_wantClose = false;
        m_elapsed.start();

        if (parentWidget())
            setGeometry(parentWidget()->rect());

        raise();
        show();
        setFocus();
        m_animTimer->start(16);
    }

    // Stop - waits for minimum display time before hiding
    void stop()
    {
        m_wantClose = true;
        int remaining = m_minDisplayMs - (int)m_elapsed.elapsed();
        if (remaining > 0) {
            QTimer::singleShot(remaining, this, &LoadingScreenBase::doClose);
        } else {
            doClose();
        }
    }

    // Force stop - hides immediately (for disconnect / user cancel)
    void forceStop()
    {
        m_wantClose = true;
        doClose();
    }

    void setStatusText(const QString &text) {
        m_statusText = text;
        update();
    }

    bool isActive() const { return m_animTimer->isActive(); }

signals:
    void closed();

protected:
    QTimer       *m_animTimer;
    QElapsedTimer m_elapsed;
    int           m_angle;
    QString       m_statusText;
    int           m_minDisplayMs;
    bool          m_wantClose;

    bool eventFilter(QObject *obj, QEvent *event) override {
        if (obj == parentWidget() && event->type() == QEvent::Resize) {
            setGeometry(parentWidget()->rect());
        }
        return QWidget::eventFilter(obj, event);
    }

    virtual void onTick() {
        m_angle = (m_angle + 3) % 360;
        update();
    }

    void doClose() {
        m_animTimer->stop();
        hide();
        emit closed();
    }

    // ---- Drawing helpers ----

    void drawOverlayBackground(QPainter &p) {
        p.setRenderHint(QPainter::Antialiasing);
        p.fillRect(rect(), QColor(0, 0, 0, 160));

        QRect card = cardRect();
        p.setBrush(QColor(25, 28, 38, 240));
        p.setPen(QPen(QColor(60, 65, 85), 1));
        p.drawRoundedRect(card, 16, 16);
    }

    QRect cardRect() const {
        int cw = 360, ch = 260;
        return QRect((width() - cw) / 2, (height() - ch) / 2, cw, ch);
    }

    QPoint cardCenter() const {
        QRect c = cardRect();
        return QPoint(c.center().x(), c.center().y() - 15);
    }

    void drawStatusText(QPainter &p) {
        QRect c = cardRect();
        p.setPen(QColor(180, 185, 200));
        p.setFont(QFont("Segoe UI", 11));
        p.drawText(QRect(c.left(), c.bottom() - 50, c.width(), 35),
                   Qt::AlignCenter, m_statusText);
    }

    void drawTitle(QPainter &p, const QString &title) {
        QRect c = cardRect();
        p.setPen(QColor(120, 130, 160));
        p.setFont(QFont("Segoe UI", 9));
        p.drawText(QRect(c.left(), c.top() + 8, c.width(), 25),
                   Qt::AlignCenter, title);
    }
};


// ============================================================================
// MODEL 1: Spinning Arc
// ============================================================================
class LoadingSpinningArc : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "SPINNER");
        QPoint cc = cardCenter();
        QRect arcRect(cc.x() - 35, cc.y() - 35, 70, 70);
        p.setPen(QPen(QColor(50, 55, 70), 5, Qt::SolidLine, Qt::RoundCap));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(arcRect);
        p.setPen(QPen(QColor(0, 150, 255), 5, Qt::SolidLine, Qt::RoundCap));
        p.drawArc(arcRect, m_angle * 16, 270 * 16);
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 2: Pulsating Dots
// ============================================================================
class LoadingPulsatingDots : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "PULSE DOTS");
        QPoint cc = cardCenter();
        for (int i = 0; i < 8; ++i) {
            qreal phase = qDegreesToRadians((qreal)(m_angle + i * 45));
            qreal scale = (qSin(phase) + 1.0) / 2.0;
            int radius = 4 + (int)(scale * 7);
            int alpha = 80 + (int)(scale * 175);
            qreal dx = qCos(qDegreesToRadians((qreal)(i * 45))) * 42;
            qreal dy = qSin(qDegreesToRadians((qreal)(i * 45))) * 42;
            p.setBrush(QColor(0, 200, 150, alpha));
            p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(cc.x() + dx, cc.y() + dy), radius, radius);
        }
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 3: Wave Progress Bar
// ============================================================================
class LoadingWaveBar : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "WAVE BAR");
        QRect card = cardRect();
        int barW = 260, barH = 10;
        int barX = card.center().x() - barW / 2;
        int barY = card.center().y() - barH / 2;
        p.setBrush(QColor(50, 55, 70));
        p.setPen(Qt::NoPen);
        p.drawRoundedRect(barX, barY, barW, barH, 5, 5);
        p.setClipRect(barX, barY, barW, barH);
        for (int x = 0; x < barW; ++x) {
            qreal wave = qSin(qDegreesToRadians((qreal)(m_angle * 3 + x * 4))) * 0.3 + 0.7;
            qreal pulse = qSin(qDegreesToRadians((qreal)(m_angle * 2))) * 0.5 + 0.5;
            if ((qreal)x / barW < pulse) {
                p.setPen(QColor(80, 160, 255, (int)(wave * 255)));
                p.drawLine(barX + x, barY, barX + x, barY + barH);
            }
        }
        p.setClipping(false);
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 4: Rotating Cubes
// ============================================================================
class LoadingRotatingCubes : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "CUBES");
        QPoint cc = cardCenter();
        QColor colors[] = { QColor(255,90,90,210), QColor(90,255,90,210), QColor(90,130,255,210) };
        for (int i = 0; i < 3; ++i) {
            qreal scale = (qSin(qDegreesToRadians((qreal)(m_angle + i*120))) + 1.0) / 2.0;
            int sz = 14 + (int)(scale * 18);
            p.save();
            p.translate(cc.x() + (i-1)*50, cc.y());
            p.rotate(m_angle + i * 45);
            p.setBrush(colors[i]);
            p.setPen(Qt::NoPen);
            p.drawRect(-sz/2, -sz/2, sz, sz);
            p.restore();
        }
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 5: DNA Helix
// ============================================================================
class LoadingDNAHelix : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "DNA HELIX");
        QPoint cc = cardCenter();
        for (int i = 0; i < 18; ++i) {
            qreal t = qDegreesToRadians((qreal)(m_angle * 2 + i * 20));
            qreal x1 = qCos(t) * 50, x2 = qCos(t + M_PI) * 50;
            qreal y = (i - 9) * 8;
            qreal z1 = (qSin(t) + 1.0) / 2.0, z2 = (qSin(t + M_PI) + 1.0) / 2.0;
            p.setPen(QPen(QColor(80,80,120,60), 1));
            p.drawLine(QPointF(cc.x()+x1, cc.y()+y), QPointF(cc.x()+x2, cc.y()+y));
            p.setPen(Qt::NoPen);
            p.setBrush(QColor(0,200,255, 80+(int)(z1*175)));
            p.drawEllipse(QPointF(cc.x()+x1, cc.y()+y), 3+(int)(z1*4), 3+(int)(z1*4));
            p.setBrush(QColor(255,100,200, 80+(int)(z2*175)));
            p.drawEllipse(QPointF(cc.x()+x2, cc.y()+y), 3+(int)(z2*4), 3+(int)(z2*4));
        }
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 6: Radar Sweep
// ============================================================================
class LoadingRadarSweep : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "RADAR");
        QPoint cc = cardCenter();
        int R = 55;
        p.setPen(QPen(QColor(0,255,100,40), 1));
        p.setBrush(Qt::NoBrush);
        for (int i = 1; i <= 3; ++i) p.drawEllipse(QPointF(cc), R*i/3, R*i/3);
        p.drawLine(cc.x()-R, cc.y(), cc.x()+R, cc.y());
        p.drawLine(cc.x(), cc.y()-R, cc.x(), cc.y()+R);
        QConicalGradient cg(cc, -m_angle);
        cg.setColorAt(0.0, QColor(0,255,100,150));
        cg.setColorAt(0.15, QColor(0,255,100,0));
        cg.setColorAt(1.0, QColor(0,255,100,0));
        p.setBrush(cg); p.setPen(Qt::NoPen);
        p.drawEllipse(QPointF(cc), R, R);
        qreal rad = qDegreesToRadians((qreal)m_angle);
        p.setPen(QPen(QColor(0,255,100,200), 2));
        p.drawLine(QPointF(cc), QPointF(cc.x()+qCos(rad)*R, cc.y()+qSin(rad)*R));
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 7: Bouncing Balls
// ============================================================================
class LoadingBouncingBalls : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "BOUNCE");
        QPoint cc = cardCenter();
        int baseY = cc.y() + 30;
        QColor colors[] = { {255,80,80},{80,200,255},{255,200,50},{80,255,150},{200,100,255} };
        for (int i = 0; i < 5; ++i) {
            qreal bounce = qAbs(qSin(qDegreesToRadians((qreal)(m_angle*3+i*40)))) * 65;
            int x = cc.x() + (i-2)*32, y = baseY - (int)bounce;
            p.setBrush(QColor(0,0,0,40)); p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(x, baseY+5), 9, 3);
            QRadialGradient rg(x-2, y-2, 12);
            rg.setColorAt(0, colors[i].lighter(140)); rg.setColorAt(1, colors[i]);
            p.setBrush(rg);
            p.drawEllipse(QPointF(x, y), 10, 10);
        }
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 8: Matrix Rain
// ============================================================================
class LoadingMatrixRain : public LoadingScreenBase
{
    Q_OBJECT
public:
    explicit LoadingMatrixRain(QWidget *parent = nullptr) : LoadingScreenBase(parent) {
        for (int i = 0; i < 18; ++i) m_drops.append(qrand() % 200);
    }
protected:
    QList<int> m_drops;
    void onTick() override {
        m_angle = (m_angle + 3) % 360;
        for (int i = 0; i < m_drops.size(); ++i) {
            m_drops[i] += 2 + (i % 4);
            if (m_drops[i] > 200) m_drops[i] = 0;
        }
        update();
    }
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "MATRIX");
        QRect card = cardRect();
        p.setClipRect(card.adjusted(5,25,-5,-45));
        p.setFont(QFont("Courier", 10, QFont::Bold));
        int startX = card.left() + 15, topY = card.top() + 30;
        for (int i = 0; i < m_drops.size(); ++i) {
            int x = startX + i * 18;
            for (int j = 0; j < 7; ++j) {
                int charY = topY + m_drops[i] - j * 14;
                if (charY < topY || charY > card.bottom()-50) continue;
                int alpha = qMax(0, 255 - j * 35);
                p.setPen(j==0 ? QColor(200,255,200,alpha) : QColor(0,180,0,alpha));
                p.drawText(x, charY, QString(QChar((ushort)(0x30A0+((i*7+j+m_angle)%96)))));
            }
        }
        p.setClipping(false);
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 9: Orbit Rings
// ============================================================================
class LoadingOrbitRings : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "ORBITS");
        QPoint cc = cardCenter();
        p.setBrush(QColor(255,210,80)); p.setPen(Qt::NoPen);
        p.drawEllipse(QPointF(cc), 7, 7);
        struct O { int rx; int ry; qreal s; QColor c; };
        O orb[] = { {30,18,1.0,{0,180,255}}, {48,28,0.7,{255,100,150}}, {66,38,0.4,{100,255,180}} };
        for (int i = 0; i < 3; ++i) {
            p.setPen(QPen(orb[i].c.darker(200),1,Qt::DashLine)); p.setBrush(Qt::NoBrush);
            p.drawEllipse(QPointF(cc), orb[i].rx, orb[i].ry);
            qreal rad = qDegreesToRadians(m_angle * orb[i].s);
            p.setBrush(orb[i].c); p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(cc.x()+qCos(rad)*orb[i].rx, cc.y()+qSin(rad)*orb[i].ry), 5, 5);
        }
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 10: Heartbeat / ECG
// ============================================================================
class LoadingHeartbeat : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "HEARTBEAT");
        QRect card = cardRect();
        int cy = card.center().y(), sx = card.left()+25, ex = card.right()-25;
        QPainterPath path; path.moveTo(sx, cy);
        for (int x = sx; x < ex; ++x) {
            qreal mod = fmod((qreal)(x-sx)/(ex-sx)*360 + m_angle*3, 360.0);
            qreal y = 0;
            if      (mod>160&&mod<170) y=-25;
            else if (mod>170&&mod<175) y=35;
            else if (mod>175&&mod<185) y=-45;
            else if (mod>185&&mod<195) y=20;
            else if (mod>195&&mod<200) y=-8;
            else y=qSin(qDegreesToRadians(mod*0.5))*2;
            path.lineTo(x, cy+y);
        }
        p.setPen(QPen(QColor(0,255,100,40), 6, Qt::SolidLine, Qt::RoundCap));
        p.drawPath(path);
        p.setPen(QPen(QColor(0,255,100,200), 2, Qt::SolidLine, Qt::RoundCap));
        p.drawPath(path);
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 11: Gears
// ============================================================================
class LoadingGears : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void drawGear(QPainter &p, int cx, int cy, int oR, int iR, int teeth, qreal ang, QColor col) {
        QPainterPath path;
        int steps = teeth * 2;
        for (int i = 0; i <= steps; ++i) {
            qreal a = qDegreesToRadians(ang + (qreal)i*360.0/steps);
            int r = (i%2==0) ? oR : iR;
            if (i==0) path.moveTo(cx+qCos(a)*r, cy+qSin(a)*r);
            else path.lineTo(cx+qCos(a)*r, cy+qSin(a)*r);
        }
        path.closeSubpath();
        QPainterPath hole; hole.addEllipse(QPointF(cx,cy), iR*0.35, iR*0.35);
        p.setBrush(col); p.setPen(QPen(col.darker(130),1));
        p.drawPath(path.subtracted(hole));
    }
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "GEARS");
        QPoint cc = cardCenter();
        drawGear(p, cc.x()-28, cc.y()-22, 32, 22, 10, m_angle, QColor(100,160,255,200));
        drawGear(p, cc.x()+22, cc.y()+8, 22, 16, 8, -m_angle*1.25, QColor(255,160,80,200));
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 12: Particle Vortex
// ============================================================================
class LoadingParticleVortex : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "VORTEX");
        QPoint cc = cardCenter();
        for (int i = 0; i < 50; ++i) {
            qreal t = (qreal)i/50;
            qreal sa = qDegreesToRadians(m_angle*2 + t*720);
            qreal r = 8 + t*48;
            QColor col; col.setHsvF(fmod(t*0.6+m_angle/360.0,1.0), 0.8, 1.0, (t*200+55)/255.0);
            p.setBrush(col); p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(cc.x()+qCos(sa)*r, cc.y()+qSin(sa)*r), 1.5+t*2.5, 1.5+t*2.5);
        }
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 13: Flip Dots
// ============================================================================
class LoadingFlipDots : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "FLIP DOTS");
        QPoint cc = cardCenter();
        int rows=5,cols=7,dot=9,sp=16;
        int sx=cc.x()-(cols*sp)/2, sy=cc.y()-(rows*sp)/2;
        for (int r=0;r<rows;++r) for (int c=0;c<cols;++c) {
            qreal dist = qSqrt((r-2.0)*(r-2.0)+(c-3.0)*(c-3.0));
            qreal flip = (qSin(qDegreesToRadians(m_angle*3-dist*40))+1.0)/2.0;
            QColor on(0,200,255), off(40,48,58);
            p.setBrush(QColor(off.red()+(int)(flip*(on.red()-off.red())),
                              off.green()+(int)(flip*(on.green()-off.green())),
                              off.blue()+(int)(flip*(on.blue()-off.blue()))));
            p.setPen(Qt::NoPen);
            p.drawRoundedRect(sx+c*sp, sy+r*sp, dot, dot, 2, 2);
        }
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 14: Wifi Pulse
// ============================================================================
class LoadingWifiPulse : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "WIFI PULSE");
        QPoint cc = cardCenter();
        for (int i=0;i<3;++i) {
            qreal pulse=(qSin(qDegreesToRadians((qreal)(m_angle*3-i*60)))+1.0)/2.0;
            int arcR=22+i*20;
            p.setPen(QPen(QColor(0,180,255,60+(int)(pulse*195)),4,Qt::SolidLine,Qt::RoundCap));
            p.setBrush(Qt::NoBrush);
            p.drawArc(QRect(cc.x()-arcR,cc.y()-arcR,arcR*2,arcR*2), 45*16, 90*16);
        }
        qreal dp=(qSin(qDegreesToRadians((qreal)(m_angle*4)))+1.0)/2.0;
        p.setBrush(QColor(0,220,255)); p.setPen(Qt::NoPen);
        p.drawEllipse(QPointF(cc), 5+(int)(dp*3), 5+(int)(dp*3));
        drawStatusText(p);
    }
};

// ============================================================================
// MODEL 15: Gradient Ring
// ============================================================================
class LoadingGradientRing : public LoadingScreenBase
{
    Q_OBJECT
public:
    using LoadingScreenBase::LoadingScreenBase;
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        drawOverlayBackground(p);
        drawTitle(p, "GRADIENT RING");
        QPoint cc = cardCenter();
        QConicalGradient cg(cc, m_angle);
        cg.setColorAt(0.0,{255,50,100}); cg.setColorAt(0.25,{255,200,50});
        cg.setColorAt(0.5,{50,200,255}); cg.setColorAt(0.75,{150,50,255});
        cg.setColorAt(1.0,{255,50,100});
        QPainterPath outer; outer.addEllipse(QPointF(cc),48,48);
        QPainterPath inner; inner.addEllipse(QPointF(cc),30,30);
        p.setBrush(cg); p.setPen(Qt::NoPen);
        p.drawPath(outer.subtracted(inner));
        int secs = (int)(m_elapsed.elapsed()/1000);
        p.setPen(QColor(255,255,255,220));
        p.setFont(QFont("Segoe UI",14,QFont::Bold));
        p.drawText(QRect(cc.x()-25,cc.y()-12,50,24), Qt::AlignCenter, QString::number(secs)+"s");
        drawStatusText(p);
    }
};

#endif // LOADINGSCREEN_H
