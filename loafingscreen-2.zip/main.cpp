// ============================================================================
// main.cpp - Demo with Connect, Disconnect, and Preview buttons
// ============================================================================

#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QLineEdit>
#include <QLabel>
#include <QSpinBox>
#include <QGroupBox>
#include "ConnectionManager.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr) : QMainWindow(parent)
    {
        setWindowTitle("Qt Loading Screen Demo");
        setMinimumSize(520, 500);
        resize(520, 500);

        QWidget *central = new QWidget(this);
        QVBoxLayout *layout = new QVBoxLayout(central);
        layout->setSpacing(10);
        layout->setContentsMargins(25, 15, 25, 15);

        // Title
        QLabel *title = new QLabel("Loading Screen Demo");
        title->setFont(QFont("Segoe UI", 16, QFont::Bold));
        title->setAlignment(Qt::AlignCenter);
        layout->addWidget(title);

        // Model selector
        layout->addWidget(new QLabel("Loading Model:"));
        m_modelCombo = new QComboBox();
        m_modelCombo->addItem("1  - Spinning Arc",     ConnectionManager::SpinningArc);
        m_modelCombo->addItem("2  - Pulsating Dots",   ConnectionManager::PulsatingDots);
        m_modelCombo->addItem("3  - Wave Bar",         ConnectionManager::WaveBar);
        m_modelCombo->addItem("4  - Rotating Cubes",   ConnectionManager::RotatingCubes);
        m_modelCombo->addItem("5  - DNA Helix",        ConnectionManager::DNAHelix);
        m_modelCombo->addItem("6  - Radar Sweep",      ConnectionManager::RadarSweep);
        m_modelCombo->addItem("7  - Bouncing Balls",   ConnectionManager::BouncingBalls);
        m_modelCombo->addItem("8  - Matrix Rain",      ConnectionManager::MatrixRain);
        m_modelCombo->addItem("9  - Orbit Rings",      ConnectionManager::OrbitRings);
        m_modelCombo->addItem("10 - Heartbeat / ECG",  ConnectionManager::Heartbeat);
        m_modelCombo->addItem("11 - Gears",            ConnectionManager::Gears);
        m_modelCombo->addItem("12 - Particle Vortex",  ConnectionManager::ParticleVortex);
        m_modelCombo->addItem("13 - Flip Dots",        ConnectionManager::FlipDots);
        m_modelCombo->addItem("14 - Wifi Pulse",       ConnectionManager::WifiPulse);
        m_modelCombo->addItem("15 - Gradient Ring",    ConnectionManager::GradientRing);
        layout->addWidget(m_modelCombo);

        // =============================================
        // PREVIEW BUTTON - see loading screen without connecting
        // =============================================
        m_previewBtn = new QPushButton("Preview Loading Screen (3 sec)");
        m_previewBtn->setFixedHeight(38);
        m_previewBtn->setStyleSheet(
            "QPushButton { background: #6C3FAA; color: white; border-radius: 6px; font-weight: bold; }"
            "QPushButton:hover { background: #7E52C0; }"
        );
        layout->addWidget(m_previewBtn);

        // Connection settings group
        QGroupBox *connGroup = new QGroupBox("Connection Settings");
        QVBoxLayout *connLayout = new QVBoxLayout(connGroup);

        connLayout->addWidget(new QLabel("Host:"));
        m_hostEdit = new QLineEdit("192.168.1.100");
        connLayout->addWidget(m_hostEdit);

        QHBoxLayout *portRow = new QHBoxLayout();
        portRow->addWidget(new QLabel("Port:"));
        m_portSpin = new QSpinBox();
        m_portSpin->setRange(1, 65535);
        m_portSpin->setValue(8080);
        portRow->addWidget(m_portSpin);
        portRow->addStretch();
        connLayout->addLayout(portRow);

        layout->addWidget(connGroup);

        // Connect + Disconnect buttons
        QHBoxLayout *btnRow = new QHBoxLayout();

        m_connectBtn = new QPushButton("Connect");
        m_connectBtn->setFixedHeight(42);
        m_connectBtn->setStyleSheet(
            "QPushButton { background: #0078D4; color: white; border-radius: 6px; font-size: 13px; font-weight: bold; }"
            "QPushButton:hover { background: #1A8AE8; }"
            "QPushButton:disabled { background: #555; }"
        );
        btnRow->addWidget(m_connectBtn);

        m_disconnectBtn = new QPushButton("Disconnect");
        m_disconnectBtn->setFixedHeight(42);
        m_disconnectBtn->setEnabled(false);
        m_disconnectBtn->setStyleSheet(
            "QPushButton { background: #D83B3B; color: white; border-radius: 6px; font-size: 13px; font-weight: bold; }"
            "QPushButton:hover { background: #E85555; }"
            "QPushButton:disabled { background: #555; }"
        );
        btnRow->addWidget(m_disconnectBtn);

        layout->addLayout(btnRow);

        // Status
        m_statusLabel = new QLabel("Status: Idle");
        m_statusLabel->setAlignment(Qt::AlignCenter);
        m_statusLabel->setFont(QFont("Segoe UI", 11));
        m_statusLabel->setStyleSheet("color: #888; padding: 8px;");
        layout->addWidget(m_statusLabel);

        layout->addStretch();
        setCentralWidget(central);

        // =============================================
        // CREATE ConnectionManager
        // =============================================
        m_connMgr = new ConnectionManager(this, this);

        // Wire buttons
        connect(m_connectBtn, &QPushButton::clicked, this, &MainWindow::onConnect);
        connect(m_disconnectBtn, &QPushButton::clicked, this, &MainWindow::onDisconnect);
        connect(m_previewBtn, &QPushButton::clicked, this, &MainWindow::onPreview);

        // Wire connection signals
        connect(m_connMgr, &ConnectionManager::connectionSuccess, this, [this]() {
            setStatus("Connected!", "green");
            m_connectBtn->setEnabled(false);
            m_disconnectBtn->setEnabled(true);
        });

        connect(m_connMgr, &ConnectionManager::connectionFailed, this, [this](const QString &err) {
            setStatus("Failed: " + err, "red");
            m_connectBtn->setEnabled(true);
            m_disconnectBtn->setEnabled(false);
        });

        connect(m_connMgr, &ConnectionManager::disconnected, this, [this]() {
            setStatus("Disconnected.", "#E8A030");
            m_connectBtn->setEnabled(true);
            m_disconnectBtn->setEnabled(false);
        });
    }

private slots:
    void onConnect()
    {
        auto model = static_cast<ConnectionManager::LoadingModel>(
            m_modelCombo->currentData().toInt());
        m_connMgr->setLoadingModel(model);
        m_connMgr->setMinimumLoadingTime(2000);  // Always show for at least 2 sec

        setStatus("Connecting...", "#0078D4");
        m_connectBtn->setEnabled(false);

        m_connMgr->connectToServer(m_hostEdit->text().trimmed(),
                                   (quint16)m_portSpin->value(),
                                   8000);
    }

    void onDisconnect()
    {
        m_connMgr->disconnectFromServer();
    }

    // =============================================
    // PREVIEW - Show loading screen standalone for 3 seconds
    // =============================================
    void onPreview()
    {
        // Create a temporary loading screen directly (no connection needed)
        auto model = static_cast<ConnectionManager::LoadingModel>(
            m_modelCombo->currentData().toInt());

        // Clean up previous preview
        if (m_previewLoader) {
            m_previewLoader->forceStop();
            delete m_previewLoader;
            m_previewLoader = nullptr;
        }

        // Create the selected model
        switch (model) {
        case ConnectionManager::SpinningArc:    m_previewLoader = new LoadingSpinningArc(this);    break;
        case ConnectionManager::PulsatingDots:  m_previewLoader = new LoadingPulsatingDots(this);  break;
        case ConnectionManager::WaveBar:        m_previewLoader = new LoadingWaveBar(this);        break;
        case ConnectionManager::RotatingCubes:  m_previewLoader = new LoadingRotatingCubes(this);  break;
        case ConnectionManager::DNAHelix:       m_previewLoader = new LoadingDNAHelix(this);       break;
        case ConnectionManager::RadarSweep:     m_previewLoader = new LoadingRadarSweep(this);     break;
        case ConnectionManager::BouncingBalls:  m_previewLoader = new LoadingBouncingBalls(this);  break;
        case ConnectionManager::MatrixRain:     m_previewLoader = new LoadingMatrixRain(this);     break;
        case ConnectionManager::OrbitRings:     m_previewLoader = new LoadingOrbitRings(this);     break;
        case ConnectionManager::Heartbeat:      m_previewLoader = new LoadingHeartbeat(this);      break;
        case ConnectionManager::Gears:          m_previewLoader = new LoadingGears(this);          break;
        case ConnectionManager::ParticleVortex: m_previewLoader = new LoadingParticleVortex(this); break;
        case ConnectionManager::FlipDots:       m_previewLoader = new LoadingFlipDots(this);       break;
        case ConnectionManager::WifiPulse:      m_previewLoader = new LoadingWifiPulse(this);      break;
        case ConnectionManager::GradientRing:   m_previewLoader = new LoadingGradientRing(this);   break;
        }

        if (m_previewLoader) {
            m_previewLoader->setMinimumDisplayTime(3000);
            m_previewLoader->setStatusText("Preview mode - " + m_modelCombo->currentText());
            m_previewLoader->start();

            // Auto-close after 3 seconds
            QTimer::singleShot(3000, this, [this]() {
                if (m_previewLoader) {
                    m_previewLoader->stop();
                }
            });
        }
    }

private:
    void setStatus(const QString &text, const QString &color) {
        m_statusLabel->setText("Status: " + text);
        m_statusLabel->setStyleSheet("color: " + color + "; padding: 8px; font-weight: bold;");
    }

    ConnectionManager  *m_connMgr;
    QComboBox          *m_modelCombo;
    QLineEdit          *m_hostEdit;
    QSpinBox           *m_portSpin;
    QPushButton        *m_connectBtn;
    QPushButton        *m_disconnectBtn;
    QPushButton        *m_previewBtn;
    QLabel             *m_statusLabel;
    LoadingScreenBase  *m_previewLoader = nullptr;
};


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    MainWindow window;
    window.show();
    return app.exec();
}

#include "main.moc"
