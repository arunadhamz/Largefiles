#ifndef CONNECTIONMANAGER_H
#define CONNECTIONMANAGER_H

#include <QObject>
#include <QTcpSocket>
#include <QTimer>
#include <QDebug>
#include "LoadingScreen.h"

// ============================================================================
// ConnectionManager - Handles connect + disconnect with loading screen overlay
//
// FIXES:
//   1. Minimum display time - loading screen stays visible even if connection
//      is instant (default 2 seconds)
//   2. Disconnect support - call disconnect() to close connection
//   3. forceStop on disconnect - loading screen hides immediately
//   4. Status text updates through lifecycle
// ============================================================================
class ConnectionManager : public QObject
{
    Q_OBJECT

public:
    enum LoadingModel {
        SpinningArc = 1,
        PulsatingDots,
        WaveBar,
        RotatingCubes,
        DNAHelix,
        RadarSweep,
        BouncingBalls,
        MatrixRain,
        OrbitRings,
        Heartbeat,
        Gears,
        ParticleVortex,
        FlipDots,
        WifiPulse,
        GradientRing
    };

    explicit ConnectionManager(QWidget *parentWidget, QObject *parent = nullptr)
        : QObject(parent), m_parentWidget(parentWidget), m_loadingScreen(nullptr),
          m_selectedModel(SpinningArc), m_minDisplayMs(2000)
    {
        m_socket = new QTcpSocket(this);
        m_timeoutTimer = new QTimer(this);
        m_timeoutTimer->setSingleShot(true);

        connect(m_socket, &QTcpSocket::connected,
                this, &ConnectionManager::onConnected);
        connect(m_socket, &QTcpSocket::disconnected,
                this, &ConnectionManager::onDisconnected);
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
        connect(m_socket, &QAbstractSocket::errorOccurred,
                this, &ConnectionManager::onError);
#else
        connect(m_socket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),
                this, &ConnectionManager::onError);
#endif
        connect(m_timeoutTimer, &QTimer::timeout,
                this, &ConnectionManager::onTimeout);
    }

    ~ConnectionManager() {
        delete m_loadingScreen;
    }

    // Set loading screen model (1-15)
    void setLoadingModel(LoadingModel model) { m_selectedModel = model; }

    // Set minimum time loading screen stays visible (ms), default 2000
    void setMinimumLoadingTime(int ms) { m_minDisplayMs = ms; }

    // -------------------------------------------------------------------
    // CONNECT - Shows loading screen, starts TCP connection
    // -------------------------------------------------------------------
    void connectToServer(const QString &host, quint16 port, int timeoutMs = 10000)
    {
        // If already connected, disconnect first
        if (m_socket->state() != QAbstractSocket::UnconnectedState) {
            m_socket->abort();
        }

        m_host = host;
        m_port = port;

        // Create and show loading screen
        createLoadingScreen();
        if (m_loadingScreen) {
            m_loadingScreen->setMinimumDisplayTime(m_minDisplayMs);
            m_loadingScreen->setStatusText("Connecting to " + host + ":" + QString::number(port) + " ...");
            m_loadingScreen->start();
        }

        // Begin TCP connection
        m_socket->connectToHost(host, port);
        m_timeoutTimer->start(timeoutMs);

        qDebug() << "[ConnMgr] Connecting to" << host << ":" << port
                 << "(min display:" << m_minDisplayMs << "ms)";
    }

    // -------------------------------------------------------------------
    // DISCONNECT - Closes socket, immediately hides loading screen
    // -------------------------------------------------------------------
    void disconnectFromServer()
    {
        m_timeoutTimer->stop();

        // Force-close loading screen immediately (no minimum wait)
        if (m_loadingScreen && m_loadingScreen->isActive()) {
            m_loadingScreen->forceStop();
        }

        if (m_socket->state() != QAbstractSocket::UnconnectedState) {
            m_socket->disconnectFromHost();
            if (m_socket->state() != QAbstractSocket::UnconnectedState) {
                m_socket->abort();  // force close if not yet done
            }
        }

        qDebug() << "[ConnMgr] Disconnect requested.";
    }

    // -------------------------------------------------------------------
    // ABORT - Hard abort (e.g. user clicked cancel during connecting)
    // -------------------------------------------------------------------
    void abort()
    {
        m_timeoutTimer->stop();
        m_socket->abort();

        if (m_loadingScreen && m_loadingScreen->isActive()) {
            m_loadingScreen->setStatusText("Cancelled.");
            m_loadingScreen->forceStop();
        }

        qDebug() << "[ConnMgr] Connection aborted.";
        emit connectionFailed("Aborted by user");
    }

    bool isConnected() const {
        return m_socket->state() == QAbstractSocket::ConnectedState;
    }

    QAbstractSocket::SocketState socketState() const {
        return m_socket->state();
    }

signals:
    void connectionSuccess();
    void connectionFailed(const QString &errorMsg);
    void disconnected();

private slots:
    void onConnected()
    {
        m_timeoutTimer->stop();
        qDebug() << "[ConnMgr] TCP connected! (loading screen will stay for min display time)";

        if (m_loadingScreen) {
            m_loadingScreen->setStatusText("Connected successfully!");
            // stop() respects minimum display time - won't hide until 2s elapsed
            m_loadingScreen->stop();
            // Emit success after loading screen actually closes
            connect(m_loadingScreen, &LoadingScreenBase::closed, this, [this]() {
                emit connectionSuccess();
            }, Qt::UniqueConnection);
        } else {
            emit connectionSuccess();
        }
    }

    void onDisconnected()
    {
        if (m_loadingScreen && m_loadingScreen->isActive()) {
            m_loadingScreen->forceStop();
        }
        qDebug() << "[ConnMgr] Socket disconnected.";
        emit disconnected();
    }

    void onError(QAbstractSocket::SocketError socketError)
    {
        Q_UNUSED(socketError)
        m_timeoutTimer->stop();
        QString errMsg = m_socket->errorString();
        qDebug() << "[ConnMgr] Error:" << errMsg;

        if (m_loadingScreen) {
            m_loadingScreen->setStatusText("Error: " + errMsg);
            // Show error for 1.5s then hide
            QTimer::singleShot(1500, this, [this, errMsg]() {
                if (m_loadingScreen) m_loadingScreen->forceStop();
                emit connectionFailed(errMsg);
            });
        } else {
            emit connectionFailed(errMsg);
        }
    }

    void onTimeout()
    {
        m_socket->abort();
        qDebug() << "[ConnMgr] Timeout!";

        if (m_loadingScreen) {
            m_loadingScreen->setStatusText("Connection timed out!");
            QTimer::singleShot(1500, this, [this]() {
                if (m_loadingScreen) m_loadingScreen->forceStop();
                emit connectionFailed("Connection timed out");
            });
        } else {
            emit connectionFailed("Connection timed out");
        }
    }

private:
    void createLoadingScreen()
    {
        delete m_loadingScreen;
        m_loadingScreen = nullptr;

        switch (m_selectedModel) {
        case SpinningArc:    m_loadingScreen = new LoadingSpinningArc(m_parentWidget);    break;
        case PulsatingDots:  m_loadingScreen = new LoadingPulsatingDots(m_parentWidget);  break;
        case WaveBar:        m_loadingScreen = new LoadingWaveBar(m_parentWidget);        break;
        case RotatingCubes:  m_loadingScreen = new LoadingRotatingCubes(m_parentWidget);  break;
        case DNAHelix:       m_loadingScreen = new LoadingDNAHelix(m_parentWidget);       break;
        case RadarSweep:     m_loadingScreen = new LoadingRadarSweep(m_parentWidget);     break;
        case BouncingBalls:  m_loadingScreen = new LoadingBouncingBalls(m_parentWidget);  break;
        case MatrixRain:     m_loadingScreen = new LoadingMatrixRain(m_parentWidget);     break;
        case OrbitRings:     m_loadingScreen = new LoadingOrbitRings(m_parentWidget);     break;
        case Heartbeat:      m_loadingScreen = new LoadingHeartbeat(m_parentWidget);      break;
        case Gears:          m_loadingScreen = new LoadingGears(m_parentWidget);          break;
        case ParticleVortex: m_loadingScreen = new LoadingParticleVortex(m_parentWidget); break;
        case FlipDots:       m_loadingScreen = new LoadingFlipDots(m_parentWidget);       break;
        case WifiPulse:      m_loadingScreen = new LoadingWifiPulse(m_parentWidget);      break;
        case GradientRing:   m_loadingScreen = new LoadingGradientRing(m_parentWidget);   break;
        default:             m_loadingScreen = new LoadingSpinningArc(m_parentWidget);    break;
        }
    }

    QWidget            *m_parentWidget;
    QTcpSocket         *m_socket;
    QTimer             *m_timeoutTimer;
    LoadingScreenBase  *m_loadingScreen;
    LoadingModel        m_selectedModel;
    int                 m_minDisplayMs;
    QString             m_host;
    quint16             m_port;
};

#endif // CONNECTIONMANAGER_H
