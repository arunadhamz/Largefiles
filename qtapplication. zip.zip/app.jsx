import { useState, useEffect, useCallback } from "react";

// ─── Theme definitions ───
const themes = {
  midnight: { bg: "#0a0e1a", surface: "#111827", surfaceAlt: "#1a2035", accent: "#3b82f6", accentAlt: "#60a5fa", text: "#e2e8f0", textDim: "#64748b", border: "#1e293b", success: "#22c55e", danger: "#ef4444", warning: "#f59e0b" },
  arctic: { bg: "#f0f4f8", surface: "#ffffff", surfaceAlt: "#e8eef4", accent: "#0369a1", accentAlt: "#0284c7", text: "#1e293b", textDim: "#64748b", border: "#cbd5e1", success: "#16a34a", danger: "#dc2626", warning: "#d97706" },
  ember: { bg: "#1a0a0a", surface: "#2a1010", surfaceAlt: "#3a1515", accent: "#ef4444", accentAlt: "#f87171", text: "#fce4e4", textDim: "#b07070", border: "#4a2020", success: "#22c55e", danger: "#ff6b6b", warning: "#fbbf24" },
  forest: { bg: "#0a1a0a", surface: "#0f2010", surfaceAlt: "#153018", accent: "#22c55e", accentAlt: "#4ade80", text: "#d4f4d4", textDim: "#6b9b6b", border: "#1a4a1a", success: "#4ade80", danger: "#f87171", warning: "#fbbf24" },
  cyber: { bg: "#0a000f", surface: "#150020", surfaceAlt: "#200030", accent: "#a855f7", accentAlt: "#c084fc", text: "#e8d5f5", textDim: "#9060b0", border: "#30104a", success: "#22d3ee", danger: "#f43f5e", warning: "#fbbf24" },
};

// ─── 15 Style Definitions ───
const styleDefinitions = [
  { id: 1, name: "Classic Sidebar", desc: "Traditional sidebar navigation with header bar. Enterprise standard layout.", layout: "sidebar-left", nav: "sidebar", header: true, features: ["Fixed sidebar", "Breadcrumb header", "Card-based content"] },
  { id: 2, name: "Ribbon Toolbar", desc: "Microsoft Office-style ribbon with tabbed toolbar groups.", layout: "ribbon", nav: "ribbon-tabs", header: false, features: ["Grouped ribbon tools", "Collapsible sections", "Status bar"] },
  { id: 3, name: "Dashboard Grid", desc: "Grid-based dashboard with floating widget panels.", layout: "grid", nav: "top-tabs", header: true, features: ["Draggable widgets", "Grid layout", "Floating panels"] },
  { id: 4, name: "Compact Sidebar", desc: "Icon-only collapsed sidebar that expands on hover.", layout: "compact-sidebar", nav: "icon-sidebar", header: true, features: ["Icon navigation", "Hover expand", "Compact design"] },
  { id: 5, name: "Top Navigation", desc: "Horizontal top navigation with dropdown menus.", layout: "top-nav", nav: "horizontal", header: false, features: ["Dropdown menus", "Horizontal tabs", "Full-width content"] },
  { id: 6, name: "Split Panel", desc: "Dual-panel layout with resizable splitter.", layout: "split", nav: "tree-view", header: true, features: ["Tree navigation", "Resizable panels", "Detail view"] },
  { id: 7, name: "Tab-Centric", desc: "Browser-style tabs as the primary navigation method.", layout: "tabs", nav: "document-tabs", header: true, features: ["Closable tabs", "Tab overflow", "New tab button"] },
  { id: 8, name: "Wizard Flow", desc: "Step-by-step wizard with progress indicator.", layout: "wizard", nav: "step-indicator", header: true, features: ["Step progress", "Next/Back flow", "Validation"] },
  { id: 9, name: "Terminal Style", desc: "Command-line inspired with dark monospace aesthetic.", layout: "terminal", nav: "command-bar", header: false, features: ["Command palette", "Monospace font", "Log output"] },
  { id: 10, name: "Material Drawer", desc: "Material Design with hamburger menu drawer.", layout: "material", nav: "drawer", header: true, features: ["Slide-out drawer", "FAB buttons", "Material cards"] },
  { id: 11, name: "Bottom Tab Bar", desc: "Mobile-inspired bottom navigation with tab bar.", layout: "bottom-tabs", nav: "bottom-bar", header: true, features: ["Bottom tabs", "Swipe navigation", "Compact header"] },
  { id: 12, name: "Floating Sidebar", desc: "Detached floating navigation panel over content.", layout: "floating", nav: "floating-panel", header: false, features: ["Floating nav", "Glass morphism", "Overlay menus"] },
  { id: 13, name: "Command Palette", desc: "VS Code-style with command palette as primary nav.", layout: "command", nav: "palette", header: true, features: ["Ctrl+P palette", "Activity bar", "Status line"] },
  { id: 14, name: "Dual Sidebar", desc: "Two sidebars: icon bar left, detail panel right.", layout: "dual-sidebar", nav: "dual-panel", header: true, features: ["Icon + detail bars", "Contextual panel", "Dense layout"] },
  { id: 15, name: "Carousel Nav", desc: "Full-screen pages with carousel/slide navigation.", layout: "carousel", nav: "dots", header: false, features: ["Full-screen pages", "Dot indicators", "Slide transitions"] },
];

const pages = ["Login", "Home", "Init", "PBIT", "Self Test", "Auto Mode", "Manual Mode", "Users", "About"];

// ─── Mini Preview Components ───
function MiniPreview({ style, theme, activePage }) {
  const t = themes[theme];
  const base = { width: "100%", height: "100%", background: t.bg, borderRadius: 6, overflow: "hidden", display: "flex", flexDirection: "column", fontSize: 5, color: t.text, position: "relative" };

  const sidebarStyle = { width: 28, background: t.surface, borderRight: `1px solid ${t.border}`, display: "flex", flexDirection: "column", gap: 2, padding: "4px 2px" };
  const headerStyle = { height: 12, background: t.surface, borderBottom: `1px solid ${t.border}`, display: "flex", alignItems: "center", padding: "0 4px" };
  const contentStyle = { flex: 1, padding: 4, display: "flex", flexDirection: "column", gap: 3 };
  const dot = (c, s = 3) => <div style={{ width: s, height: s, borderRadius: "50%", background: c, flexShrink: 0 }} />;
  const bar = (w, h = 2, c = t.accent) => <div style={{ width: w, height: h, borderRadius: 1, background: c, flexShrink: 0 }} />;
  const navItem = (active) => <div style={{ height: 5, borderRadius: 1, background: active ? t.accent : t.surfaceAlt, margin: "0 1px" }} />;

  const renderLogin = () => (
    <div style={{ ...base, justifyContent: "center", alignItems: "center" }}>
      <div style={{ width: "50%", background: t.surface, borderRadius: 4, padding: 8, display: "flex", flexDirection: "column", gap: 3, alignItems: "center", border: `1px solid ${t.border}` }}>
        {dot(t.accent, 8)}
        {bar("80%", 3, t.surfaceAlt)}
        {bar("80%", 3, t.surfaceAlt)}
        {bar("60%", 4, t.accent)}
      </div>
    </div>
  );

  if (activePage === "Login") return renderLogin();

  switch (style.id) {
    case 1: return (
      <div style={{ ...base, flexDirection: "row" }}>
        <div style={sidebarStyle}>{pages.slice(1).map((_, i) => <div key={i}>{navItem(i === pages.indexOf(activePage) - 1)}</div>)}</div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={headerStyle}>{bar(20, 2, t.textDim)}{bar(8, 2, t.accent)}</div>
          <div style={contentStyle}>{[1,2,3].map(i => <div key={i} style={{ height: 14, borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
        </div>
      </div>
    );
    case 2: return (
      <div style={base}>
        <div style={{ height: 8, background: t.accent, display: "flex", alignItems: "center", padding: "0 3px", gap: 2 }}>{bar(12, 2, "rgba(255,255,255,0.8)")}</div>
        <div style={{ height: 14, background: t.surface, borderBottom: `1px solid ${t.border}`, display: "flex", gap: 1, padding: "2px 3px", flexWrap: "wrap" }}>{[1,2,3,4,5].map(i => <div key={i} style={{ width: 10, height: 8, borderRadius: 1, background: t.surfaceAlt, border: `1px solid ${t.border}` }} />)}</div>
        <div style={contentStyle}>{[1,2].map(i => <div key={i} style={{ height: 18, borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
        <div style={{ height: 6, background: t.surface, borderTop: `1px solid ${t.border}` }} />
      </div>
    );
    case 3: return (
      <div style={base}>
        <div style={{ ...headerStyle, gap: 3 }}>{pages.slice(1, 5).map((_, i) => bar(10, 2, i === 0 ? t.accent : t.textDim))}</div>
        <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 3, padding: 4 }}>
          {[1,2,3,4].map(i => <div key={i} style={{ borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}
        </div>
      </div>
    );
    case 4: return (
      <div style={{ ...base, flexDirection: "row" }}>
        <div style={{ width: 12, background: t.surface, borderRight: `1px solid ${t.border}`, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "4px 0" }}>
          {[1,2,3,4,5].map(i => dot(i === 1 ? t.accent : t.textDim, 4))}
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={headerStyle}>{bar(30, 2, t.textDim)}</div>
          <div style={contentStyle}>{[1,2,3].map(i => <div key={i} style={{ height: 12, borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
        </div>
      </div>
    );
    case 5: return (
      <div style={base}>
        <div style={{ height: 14, background: t.surface, borderBottom: `1px solid ${t.border}`, display: "flex", alignItems: "center", gap: 2, padding: "0 4px" }}>
          {dot(t.accent, 5)}
          {pages.slice(1, 6).map((_, i) => bar(8, 2, i === 0 ? t.accent : t.textDim))}
        </div>
        <div style={contentStyle}>{[1,2,3].map(i => <div key={i} style={{ height: 14, borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
      </div>
    );
    case 6: return (
      <div style={{ ...base, flexDirection: "row" }}>
        <div style={{ width: 30, background: t.surface, borderRight: `1px solid ${t.border}`, padding: 3, display: "flex", flexDirection: "column", gap: 1 }}>
          {[1,2,3,4,5].map(i => <div key={i} style={{ display: "flex", gap: 1, alignItems: "center" }}><div style={{ width: 0, height: 0, borderLeft: "2px solid " + t.textDim, borderTop: "2px solid transparent", borderBottom: "2px solid transparent" }} />{bar(16, 2, i === 1 ? t.accent : t.textDim)}</div>)}
        </div>
        <div style={{ width: 2, background: t.accent, cursor: "col-resize" }} />
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={headerStyle}>{bar(20, 2, t.text)}</div>
          <div style={contentStyle}>{[1,2].map(i => <div key={i} style={{ height: 16, borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
        </div>
      </div>
    );
    case 7: return (
      <div style={base}>
        <div style={{ display: "flex", background: t.surfaceAlt, height: 10, alignItems: "flex-end", padding: "0 2px", gap: 1 }}>
          {["Tab 1", "Tab 2", "+"].map((_, i) => <div key={i} style={{ height: 8, width: i === 2 ? 8 : 18, background: i === 0 ? t.surface : "transparent", borderRadius: "2px 2px 0 0", border: i === 0 ? `1px solid ${t.border}` : "none", borderBottom: "none" }} />)}
        </div>
        <div style={{ flex: 1, background: t.surface, borderTop: `1px solid ${t.border}` }}>
          <div style={contentStyle}>{[1,2,3].map(i => <div key={i} style={{ height: 12, borderRadius: 2, background: t.surfaceAlt }} />)}</div>
        </div>
      </div>
    );
    case 8: return (
      <div style={base}>
        <div style={headerStyle}>{bar(20, 2, t.text)}</div>
        <div style={{ height: 10, display: "flex", alignItems: "center", justifyContent: "center", gap: 3, padding: "0 8px" }}>
          {[1,2,3,4,5].map(i => <React.Fragment key={i}>{dot(i <= 2 ? t.accent : t.textDim, 4)}{i < 5 && bar(8, 1, i < 2 ? t.accent : t.border)}</React.Fragment>)}
        </div>
        <div style={{ flex: 1, ...contentStyle, justifyContent: "center", alignItems: "center" }}>
          <div style={{ width: "70%", height: 30, borderRadius: 3, background: t.surface, border: `1px solid ${t.border}` }} />
          <div style={{ display: "flex", gap: 3 }}>{bar(14, 4, t.surfaceAlt)}{bar(14, 4, t.accent)}</div>
        </div>
      </div>
    );
    case 9: return (
      <div style={{ ...base, background: "#0c0c0c", fontFamily: "monospace" }}>
        <div style={{ height: 10, background: "#1a1a2e", display: "flex", alignItems: "center", gap: 2, padding: "0 3px" }}>{bar(4, 2, "#00ff41")}{bar(20, 2, "#333")}</div>
        <div style={{ flex: 1, padding: 3, display: "flex", flexDirection: "column", gap: 1 }}>
          {[1,2,3,4,5,6].map(i => <div key={i} style={{ display: "flex", gap: 2 }}>{bar(3, 2, "#00ff41")}{bar(Math.random() * 40 + 10, 2, i % 2 === 0 ? "#00ff41" : "#0088ff")}</div>)}
        </div>
      </div>
    );
    case 10: return (
      <div style={base}>
        <div style={{ height: 14, background: t.accent, display: "flex", alignItems: "center", gap: 3, padding: "0 4px" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>{[1,2,3].map(i => bar(6, 1, "rgba(255,255,255,0.9)"))}</div>
          {bar(20, 2, "rgba(255,255,255,0.8)")}
        </div>
        <div style={contentStyle}>
          {[1,2].map(i => <div key={i} style={{ height: 16, borderRadius: 3, background: t.surface, border: `1px solid ${t.border}`, boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />)}
        </div>
        <div style={{ position: "absolute", bottom: 6, right: 6, width: 10, height: 10, borderRadius: "50%", background: t.accent, boxShadow: `0 2px 6px ${t.accent}40` }} />
      </div>
    );
    case 11: return (
      <div style={base}>
        <div style={{ ...headerStyle, height: 10 }}>{bar(20, 2, t.text)}</div>
        <div style={contentStyle}>{[1,2,3].map(i => <div key={i} style={{ height: 14, borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
        <div style={{ height: 14, background: t.surface, borderTop: `1px solid ${t.border}`, display: "flex", justifyContent: "space-around", alignItems: "center", padding: "0 4px" }}>
          {[1,2,3,4,5].map(i => <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 1 }}>{dot(i === 1 ? t.accent : t.textDim, 4)}{bar(6, 1, i === 1 ? t.accent : t.textDim)}</div>)}
        </div>
      </div>
    );
    case 12: return (
      <div style={base}>
        <div style={{ flex: 1, ...contentStyle }}>{[1,2].map(i => <div key={i} style={{ height: 20, borderRadius: 3, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
        <div style={{ position: "absolute", top: 8, left: 6, width: 26, bottom: 8, background: t.surface + "dd", borderRadius: 4, border: `1px solid ${t.border}`, backdropFilter: "blur(4px)", padding: 3, display: "flex", flexDirection: "column", gap: 2 }}>
          {[1,2,3,4,5].map(i => navItem(i === 1))}
        </div>
      </div>
    );
    case 13: return (
      <div style={{ ...base, flexDirection: "row" }}>
        <div style={{ width: 10, background: t.surfaceAlt, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 0" }}>
          {[1,2,3,4].map(i => dot(i === 1 ? t.accent : t.textDim, 4))}
        </div>
        <div style={{ width: 26, background: t.surface, borderRight: `1px solid ${t.border}`, padding: 3, display: "flex", flexDirection: "column", gap: 1 }}>
          {[1,2,3,4,5].map(i => navItem(i === 1))}
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ height: 8, borderBottom: `1px solid ${t.border}`, display: "flex", alignItems: "center", padding: "0 3px" }}>{bar("80%", 3, t.surfaceAlt)}</div>
          <div style={contentStyle}>{[1,2].map(i => <div key={i} style={{ height: 16, borderRadius: 2, background: t.surfaceAlt }} />)}</div>
          <div style={{ height: 6, background: t.surfaceAlt, borderTop: `1px solid ${t.border}` }} />
        </div>
      </div>
    );
    case 14: return (
      <div style={{ ...base, flexDirection: "row" }}>
        <div style={{ width: 10, background: t.surfaceAlt, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 0" }}>
          {[1,2,3,4,5].map(i => dot(i === 1 ? t.accent : t.textDim, 3))}
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={headerStyle}>{bar(20, 2, t.text)}</div>
          <div style={contentStyle}>{[1,2].map(i => <div key={i} style={{ height: 16, borderRadius: 2, background: t.surface, border: `1px solid ${t.border}` }} />)}</div>
        </div>
        <div style={{ width: 30, background: t.surface, borderLeft: `1px solid ${t.border}`, padding: 3, display: "flex", flexDirection: "column", gap: 2 }}>
          {[1,2,3].map(i => <div key={i} style={{ height: 10, borderRadius: 2, background: t.surfaceAlt }} />)}
        </div>
      </div>
    );
    case 15: return (
      <div style={{ ...base, justifyContent: "center", alignItems: "center" }}>
        <div style={{ width: "75%", height: "70%", borderRadius: 4, background: t.surface, border: `1px solid ${t.border}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4 }}>
          {bar("60%", 3, t.text)}
          {bar("40%", 2, t.textDim)}
        </div>
        <div style={{ position: "absolute", bottom: 6, display: "flex", gap: 2 }}>
          {[1,2,3,4,5].map(i => dot(i === 1 ? t.accent : t.textDim, 3))}
        </div>
        <div style={{ position: "absolute", left: 4, top: "50%", transform: "translateY(-50%)", width: 6, height: 10, background: t.accent + "40", borderRadius: 1 }} />
        <div style={{ position: "absolute", right: 4, top: "50%", transform: "translateY(-50%)", width: 6, height: 10, background: t.accent + "40", borderRadius: 1 }} />
      </div>
    );
    default: return <div style={base} />;
  }
}

// ─── Page Preview (detailed) ───
function PagePreview({ style, theme, page }) {
  const t = themes[theme];
  const s = { box: { background: t.surface, border: `1px solid ${t.border}`, borderRadius: 6, padding: 12 }, label: { fontSize: 9, color: t.textDim, textTransform: "uppercase", letterSpacing: 1, marginBottom: 4 }, led: (on, color) => ({ width: 8, height: 8, borderRadius: "50%", background: on ? color : t.surfaceAlt, border: `1px solid ${on ? color : t.border}`, boxShadow: on ? `0 0 6px ${color}` : "none" }), btn: { background: t.accent, color: "#fff", border: "none", borderRadius: 4, padding: "4px 10px", fontSize: 9, cursor: "pointer" }, input: { background: t.surfaceAlt, border: `1px solid ${t.border}`, borderRadius: 3, padding: "3px 6px", fontSize: 9, color: t.text, width: "100%" }, table: { width: "100%", borderCollapse: "collapse", fontSize: 8 }, th: { background: t.surfaceAlt, padding: "4px 6px", textAlign: "left", borderBottom: `1px solid ${t.border}`, color: t.textDim, fontSize: 8 }, td: { padding: "4px 6px", borderBottom: `1px solid ${t.border}`, fontSize: 8 } };

  switch (page) {
    case "Login": return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100%", padding: 16 }}>
        <div style={{ ...s.box, width: 200, display: "flex", flexDirection: "column", gap: 8, alignItems: "center" }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: `linear-gradient(135deg, ${t.accent}, ${t.accentAlt})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, color: "#fff" }}>⬡</div>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.text }}>System Login</div>
          <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 4 }}>
            <div style={s.label}>Username</div><input style={s.input} value="admin" readOnly />
            <div style={s.label}>Password</div><input style={s.input} type="password" value="••••••" readOnly />
            <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
              <button style={{ ...s.btn, flex: 1 }}>Login</button>
              <button style={{ ...s.btn, flex: 1, background: t.surfaceAlt, color: t.text }}>Cancel</button>
            </div>
          </div>
        </div>
      </div>
    );
    case "Home": return (
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, padding: 8 }}>
        {[{ l: "System Status", v: "ONLINE", c: t.success }, { l: "Active Tests", v: "3/12", c: t.accent }, { l: "Pass Rate", v: "98.5%", c: t.success }, { l: "Uptime", v: "72h 14m", c: t.accent }].map((card, i) => (
          <div key={i} style={{ ...s.box, display: "flex", flexDirection: "column", gap: 2 }}>
            <div style={s.label}>{card.l}</div>
            <div style={{ fontSize: 16, fontWeight: 800, color: card.c }}>{card.v}</div>
          </div>
        ))}
      </div>
    );
    case "Init": return (
      <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 8 }}>
        <div style={s.box}>
          <div style={{ ...s.label, marginBottom: 6 }}>Ethernet Configuration</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
            <div><div style={s.label}>IP Address</div><input style={s.input} value="192.168.1.100" readOnly /></div>
            <div><div style={s.label}>Port</div><input style={s.input} value="5000" readOnly /></div>
            <div><div style={s.label}>Subnet</div><input style={s.input} value="255.255.255.0" readOnly /></div>
            <div><div style={s.label}>Gateway</div><input style={s.input} value="192.168.1.1" readOnly /></div>
          </div>
          <button style={{ ...s.btn, marginTop: 6 }}>Connect Ethernet</button>
        </div>
        <div style={s.box}>
          <div style={{ ...s.label, marginBottom: 6 }}>UART Configuration</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 4 }}>
            <div><div style={s.label}>COM Port</div><select style={s.input}><option>COM1</option><option>COM3</option></select></div>
            <div><div style={s.label}>Baud Rate</div><select style={s.input}><option>115200</option><option>9600</option></select></div>
            <div><div style={s.label}>Channel</div><select style={s.input}><option>CH0</option><option>CH1</option></select></div>
          </div>
          <button style={{ ...s.btn, marginTop: 6 }}>Connect UART</button>
        </div>
      </div>
    );
    case "PBIT": return (
      <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 8 }}>
        <div style={s.box}>
          <div style={{ ...s.label, marginBottom: 6 }}>Power-on Built-In Test</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: "6px 12px", alignItems: "center" }}>
            {["Processor", "DDR Memory", "Flash", "FPGA", "Ethernet PHY", "UART Controller"].map((test, i) => (
              <React.Fragment key={i}>
                <div style={{ fontSize: 9, color: t.text }}>{test}</div>
                <div style={s.led(i < 3, i < 3 ? t.success : t.textDim)} />
              </React.Fragment>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <button style={s.btn}>Send PBIT Request</button>
          <button style={{ ...s.btn, background: t.surfaceAlt, color: t.text }}>Refresh Status</button>
        </div>
      </div>
    );
    case "Self Test": return (
      <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 8 }}>
        <div style={s.box}>
          <div style={{ ...s.label, marginBottom: 6 }}>Self Test Suite</div>
          {["CPU Core", "Cache L1/L2", "Memory Bus", "IO Ports", "Watchdog"].map((test, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "3px 0", borderBottom: i < 4 ? `1px solid ${t.border}` : "none" }}>
              <div style={s.led(i < 3, i < 2 ? t.success : (i === 2 ? t.warning : t.textDim))} />
              <div style={{ fontSize: 9, flex: 1, color: t.text }}>{test}</div>
              <div style={{ fontSize: 8, color: i < 2 ? t.success : (i === 2 ? t.warning : t.textDim) }}>{i < 2 ? "PASS" : i === 2 ? "WARN" : "PENDING"}</div>
            </div>
          ))}
        </div>
        <button style={s.btn}>Run Self Test</button>
      </div>
    );
    case "Auto Mode": return (
      <div style={{ display: "flex", flexDirection: "column", gap: 6, padding: 8 }}>
        <div style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 9 }}>
          <span style={{ color: t.textDim }}>Delay (ms):</span>
          <input style={{ ...s.input, width: 50 }} value="500" readOnly />
          <button style={s.btn}>Start</button>
          <button style={{ ...s.btn, background: t.danger }}>Stop</button>
          <button style={{ ...s.btn, background: t.surfaceAlt, color: t.text }}>Report</button>
        </div>
        <div style={{ ...s.box, padding: 0, overflow: "hidden" }}>
          <table style={s.table}>
            <thead><tr>{["Sel", "Test Name", "Status", "Major", "Minor"].map(h => <th key={h} style={s.th}>{h}</th>)}</tr></thead>
            <tbody>
              {[["ALU Test", "PASS", "12", "144"], ["FPU Test", "PASS", "8", "96"], ["DMA Test", "FAIL", "5", "58"], ["IRQ Test", "—", "0", "0"]].map(([name, st, maj, min], i) => (
                <tr key={i}><td style={s.td}><input type="checkbox" checked={i < 3} readOnly /></td><td style={s.td}>{name}</td><td style={{ ...s.td, color: st === "PASS" ? t.success : st === "FAIL" ? t.danger : t.textDim }}>{st}</td><td style={s.td}>{maj}</td><td style={s.td}>{min}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
    case "Manual Mode": return (
      <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 8 }}>
        <div style={s.box}>
          <div style={s.label}>Select Processor Unit</div>
          <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
            <button style={{ ...s.btn, background: t.accent }}>ALU</button>
            <button style={{ ...s.btn, background: t.surfaceAlt, color: t.text }}>FPU</button>
          </div>
        </div>
        <div style={s.box}>
          <div style={s.label}>ALU Operations</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4, marginTop: 4 }}>
            {["ADD", "SUB", "MUL", "DIV", "AND", "OR", "XOR", "SHIFT"].map(op => (
              <button key={op} style={{ ...s.btn, background: t.surfaceAlt, color: t.text, fontSize: 8 }}>{op}</button>
            ))}
          </div>
        </div>
        <div style={s.box}>
          <div style={s.label}>Result</div>
          <div style={{ fontSize: 11, fontWeight: 700, color: t.success, marginTop: 2 }}>0xDEADBEEF — PASS</div>
        </div>
      </div>
    );
    case "Users": return (
      <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 8 }}>
        <div style={{ display: "flex", gap: 6 }}>
          <button style={s.btn}>Add User</button>
          <button style={{ ...s.btn, background: t.danger }}>Remove</button>
          <button style={{ ...s.btn, background: t.surfaceAlt, color: t.text }}>Rename</button>
        </div>
        <div style={{ ...s.box, padding: 0, overflow: "hidden" }}>
          <table style={s.table}>
            <thead><tr>{["Username", "Role", "Last Login"].map(h => <th key={h} style={s.th}>{h}</th>)}</tr></thead>
            <tbody>
              {[["admin", "Administrator", "2025-03-14"], ["operator", "Operator", "2025-03-13"], ["viewer", "Read-Only", "2025-03-10"]].map(([u, r, d], i) => (
                <tr key={i} style={{ background: i === 0 ? t.accent + "15" : "transparent" }}><td style={s.td}>{u}</td><td style={s.td}>{r}</td><td style={s.td}>{d}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
    case "About": return (
      <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 8, alignItems: "center" }}>
        <div style={{ width: 40, height: 40, borderRadius: "50%", background: `linear-gradient(135deg, ${t.accent}, ${t.accentAlt})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>⬡</div>
        <div style={{ fontSize: 12, fontWeight: 800, color: t.text }}>Test System v2.0</div>
        <div style={{ ...s.box, width: "100%", maxWidth: 220 }}>
          {[["Version", "2.0.1"], ["Build", "20250314"], ["Checksum", "A3F8..C71D"], ["Qt Version", "5.15.2"], ["Compiler", "GCC 11.2"]].map(([k, v], i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "3px 0", borderBottom: i < 4 ? `1px solid ${t.border}` : "none", fontSize: 9 }}>
              <span style={{ color: t.textDim }}>{k}</span><span style={{ color: t.text, fontFamily: "monospace" }}>{v}</span>
            </div>
          ))}
        </div>
        <button style={s.btn}>Verify Checksum</button>
      </div>
    );
    default: return null;
  }
}

// ─── Detailed Style Viewer ───
function StyleViewer({ style, theme, onBack }) {
  const t = themes[theme];
  const [activePage, setActivePage] = useState("Home");
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <button onClick={onBack} style={{ background: t.surfaceAlt, border: `1px solid ${t.border}`, borderRadius: 6, padding: "6px 14px", color: t.text, cursor: "pointer", fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}>← Back</button>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, color: t.text }}>{style.name}</div>
          <div style={{ fontSize: 12, color: t.textDim }}>{style.desc}</div>
        </div>
      </div>
      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
        {pages.map(p => (
          <button key={p} onClick={() => setActivePage(p)} style={{ padding: "5px 12px", borderRadius: 5, border: `1px solid ${activePage === p ? t.accent : t.border}`, background: activePage === p ? t.accent + "20" : t.surface, color: activePage === p ? t.accent : t.textDim, cursor: "pointer", fontSize: 11, fontWeight: activePage === p ? 700 : 400 }}>{p}</button>
        ))}
      </div>
      <div style={{ flex: 1, display: "flex", gap: 12, minHeight: 0 }}>
        <div style={{ flex: 1, background: t.bg, border: `1px solid ${t.border}`, borderRadius: 8, overflow: "hidden", position: "relative" }}>
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 16, background: t.surfaceAlt, borderBottom: `1px solid ${t.border}`, display: "flex", alignItems: "center", padding: "0 6px", gap: 3, zIndex: 2 }}>
            {["#ff5f57", "#ffbd2e", "#28c840"].map(c => <div key={c} style={{ width: 6, height: 6, borderRadius: "50%", background: c }} />)}
            <div style={{ flex: 1, textAlign: "center", fontSize: 8, color: t.textDim }}>{style.name} — {activePage}</div>
          </div>
          <div style={{ position: "absolute", top: 16, left: 0, right: 0, bottom: 0, overflow: "auto" }}>
            {activePage === "Login" ? (
              <div style={{ height: "100%" }}><PagePreview style={style} theme={theme} page="Login" /></div>
            ) : (
              <div style={{ display: "flex", height: "100%" }}>
                {(style.id === 1 || style.id === 4 || style.id === 6 || style.id === 13 || style.id === 14) && (
                  <div style={{ width: style.id === 4 ? 28 : 80, background: t.surface, borderRight: `1px solid ${t.border}`, padding: "8px 4px", display: "flex", flexDirection: "column", gap: 2, flexShrink: 0 }}>
                    {pages.slice(1).map(p => (
                      <div key={p} onClick={() => setActivePage(p)} style={{ padding: style.id === 4 ? "4px 2px" : "4px 8px", borderRadius: 3, background: p === activePage ? t.accent + "20" : "transparent", color: p === activePage ? t.accent : t.textDim, fontSize: style.id === 4 ? 7 : 9, cursor: "pointer", textAlign: style.id === 4 ? "center" : "left", whiteSpace: "nowrap", overflow: "hidden" }}>{style.id === 4 ? p.charAt(0) : p}</div>
                    ))}
                  </div>
                )}
                <div style={{ flex: 1, overflow: "auto" }}>
                  {(style.id === 2 || style.id === 5 || style.id === 3 || style.id === 7 || style.id === 10) && (
                    <div style={{ height: style.id === 2 ? 20 : 18, background: style.id === 2 || style.id === 10 ? t.accent : t.surface, borderBottom: `1px solid ${t.border}`, display: "flex", alignItems: "center", padding: "0 6px", gap: 6 }}>
                      {pages.slice(1).map(p => (
                        <div key={p} onClick={() => setActivePage(p)} style={{ fontSize: 8, color: p === activePage ? (style.id === 2 || style.id === 10 ? "#fff" : t.accent) : (style.id === 2 || style.id === 10 ? "rgba(255,255,255,0.6)" : t.textDim), cursor: "pointer", borderBottom: p === activePage && style.id !== 2 && style.id !== 10 ? `2px solid ${t.accent}` : "2px solid transparent", padding: "2px 0", fontWeight: p === activePage ? 700 : 400 }}>{p}</div>
                      ))}
                    </div>
                  )}
                  <PagePreview style={style} theme={theme} page={activePage} />
                </div>
                {style.id === 14 && (
                  <div style={{ width: 70, background: t.surface, borderLeft: `1px solid ${t.border}`, padding: 6, display: "flex", flexDirection: "column", gap: 4, flexShrink: 0 }}>
                    <div style={{ fontSize: 8, color: t.textDim, fontWeight: 700 }}>Details</div>
                    <div style={{ fontSize: 7, color: t.textDim }}>Context panel for {activePage}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      {style.id === 11 && activePage !== "Login" && (
        <div style={{ height: 24, background: t.surface, border: `1px solid ${t.border}`, borderRadius: 8, display: "flex", justifyContent: "space-around", alignItems: "center" }}>
          {pages.slice(1, 6).map(p => (
            <div key={p} onClick={() => setActivePage(p)} style={{ fontSize: 8, color: p === activePage ? t.accent : t.textDim, cursor: "pointer", fontWeight: p === activePage ? 700 : 400 }}>{p}</div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Main Application ───
export default function App() {
  const [theme, setTheme] = useState("midnight");
  const [selectedStyle, setSelectedStyle] = useState(null);
  const [searchFilter, setSearchFilter] = useState("");
  const [hoveredStyle, setHoveredStyle] = useState(null);
  const t = themes[theme];

  const filteredStyles = styleDefinitions.filter(s =>
    s.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
    s.desc.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div style={{ minHeight: "100vh", background: t.bg, color: t.text, fontFamily: "'Segoe UI', -apple-system, sans-serif", transition: "all 0.3s ease" }}>
      {/* Header */}
      <div style={{ background: t.surface, borderBottom: `1px solid ${t.border}`, padding: "12px 24px", display: "flex", alignItems: "center", gap: 16, position: "sticky", top: 0, zIndex: 100, backdropFilter: "blur(12px)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg, ${t.accent}, ${t.accentAlt})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, color: "#fff", fontWeight: 900 }}>Q</div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: -0.5 }}>Qt C++ App Styles</div>
            <div style={{ fontSize: 10, color: t.textDim }}>15 Production-Ready UI Layouts</div>
          </div>
        </div>
        <div style={{ flex: 1 }} />
        {!selectedStyle && (
          <input
            value={searchFilter}
            onChange={e => setSearchFilter(e.target.value)}
            placeholder="Search styles..."
            style={{ background: t.surfaceAlt, border: `1px solid ${t.border}`, borderRadius: 6, padding: "6px 12px", fontSize: 12, color: t.text, width: 180, outline: "none" }}
          />
        )}
        <div style={{ display: "flex", gap: 4 }}>
          {Object.entries(themes).map(([key, val]) => (
            <button key={key} onClick={() => setTheme(key)} style={{ width: 22, height: 22, borderRadius: 6, background: val.accent, border: theme === key ? `2px solid ${t.text}` : `2px solid transparent`, cursor: "pointer", transition: "all 0.2s", transform: theme === key ? "scale(1.15)" : "scale(1)" }} title={key} />
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: selectedStyle ? "16px 24px" : "24px", maxWidth: 1200, margin: "0 auto" }}>
        {selectedStyle ? (
          <div style={{ height: "calc(100vh - 100px)" }}>
            <StyleViewer style={selectedStyle} theme={theme} onBack={() => setSelectedStyle(null)} />
          </div>
        ) : (
          <>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <h2 style={{ fontSize: 24, fontWeight: 800, margin: 0, background: `linear-gradient(135deg, ${t.accent}, ${t.accentAlt})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Choose Your Application Style</h2>
              <p style={{ color: t.textDim, fontSize: 13, marginTop: 6 }}>Each layout includes Login, Home, Init, PBIT, Self Test, Auto/Manual Mode, User Mgmt & About pages</p>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240, 1fr))", gap: 16 }}>
              {filteredStyles.map(style => (
                <div
                  key={style.id}
                  onClick={() => setSelectedStyle(style)}
                  onMouseEnter={() => setHoveredStyle(style.id)}
                  onMouseLeave={() => setHoveredStyle(null)}
                  style={{ background: t.surface, border: `1px solid ${hoveredStyle === style.id ? t.accent : t.border}`, borderRadius: 10, overflow: "hidden", cursor: "pointer", transition: "all 0.25s ease", transform: hoveredStyle === style.id ? "translateY(-4px)" : "translateY(0)", boxShadow: hoveredStyle === style.id ? `0 8px 24px ${t.accent}20` : "0 2px 8px rgba(0,0,0,0.1)" }}
                >
                  <div style={{ height: 130, background: t.bg, padding: 8, position: "relative" }}>
                    <MiniPreview style={style} theme={theme} activePage="Home" />
                    <div style={{ position: "absolute", top: 4, right: 4, background: t.accent, color: "#fff", borderRadius: 4, padding: "1px 6px", fontSize: 9, fontWeight: 700 }}>#{style.id}</div>
                  </div>
                  <div style={{ padding: "10px 14px 14px" }}>
                    <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 3 }}>{style.name}</div>
                    <div style={{ fontSize: 10, color: t.textDim, lineHeight: 1.4, marginBottom: 8 }}>{style.desc}</div>
                    <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                      {style.features.map(f => (
                        <span key={f} style={{ fontSize: 8, padding: "2px 6px", borderRadius: 3, background: t.accent + "15", color: t.accent, border: `1px solid ${t.accent}30` }}>{f}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
