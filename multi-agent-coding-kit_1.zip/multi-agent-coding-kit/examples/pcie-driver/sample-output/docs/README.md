# pcie_sgdma

Linux kernel driver for a PCIe Gen3 endpoint device, demonstrating a
scatter-gather DMA transfer path triggered from userspace via ioctl.

This is a **sample/reference driver** produced by the 4-agent pipeline
(code-writer -> code-validator -> flow-checker -> doc-writer). It targets
a fictitious device (vendor 0x1234 / device 0xABCD) — swap in your real
IDs and register map before use.

## Supported hardware
- PCIe Gen3 endpoint, BAR0 = 64KB memory-mapped control/status registers
- Single MSI interrupt vector
- Device-side DMA descriptor ring read from host memory

## Build
```
make
```

## Load / unload
```
sudo insmod pcie_sgdma.ko
sudo rmmod pcie_sgdma
```

On successful probe, `/dev/pcie_sgdmaN` is created (N = 0..7).

## Userspace interface
`ioctl(fd, PCIE_SGDMA_XFER, &xfer)` where:
```c
struct pcie_sgdma_xfer {
    __u64 user_addr;  /* userspace buffer, DMA target */
    __u32 length;     /* bytes, <= MAX_SG_ENTRIES * PAGE_SIZE */
    __u32 reserved;
};
```
The call blocks until the device signals completion via MSI, or returns
`-ETIMEDOUT` after 2 seconds.

## Known limitations
- One transfer in flight at a time (serialized via `xfer_lock`)
- 32-bit DMA mask; extend to 64-bit if your platform requires
- Descriptor ring format (`struct sgdma_desc`) is illustrative — match
  it to your actual device's register/ring layout
