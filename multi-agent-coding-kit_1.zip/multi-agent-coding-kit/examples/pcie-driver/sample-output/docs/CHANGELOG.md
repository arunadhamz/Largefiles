# Changelog

- [2026-08-16] Initial version generated via code-writer -> code-validator
  -> flow-checker -> doc-writer pipeline. Implements probe/remove, MSI
  interrupt handling, and a scatter-gather DMA transfer path exposed
  through a single ioctl (PCIE_SGDMA_XFER).
