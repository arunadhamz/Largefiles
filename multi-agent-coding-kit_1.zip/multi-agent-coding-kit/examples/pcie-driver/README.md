# Example: PCIe SG-DMA driver (domain-specialized agents)

This folder shows how to specialize the generic pipeline for a
high-rigor domain — Linux kernel driver work in a DO-178C-adjacent
context.

- `agents-pcie-specific/` — the same 6 agent names, but with kernel/
  PCIe/DMA-specific checklists baked into each prompt (e.g.
  code-validator runs checkpatch.pl, security-auditor checks
  scatterlist/DMA bounds specifically). To use these instead of the
  generic ones, copy them over `.claude/agents/` in a kernel-driver
  project.
- `sample-output/` — a full working reference driver
  (`pcie_sgdma.c` + Makefile + README + CHANGELOG) showing what the
  pipeline produces end to end.
- `SAMPLE_PROMPT.md` — the exact prompt used to generate it.

Use this as a template: duplicate the pattern (generic agent + a
domain-specific version with the same name) for whatever specialized
area you work in most — e.g. a `web-api/` variant with SQL-injection-
specific security-auditor checks, or a `data-pipeline/` variant with
schema-validation-specific flow-checker checks.
