# Sample prompt — PCIe SG-DMA driver via the 6-agent pipeline

Run `claude` inside this repo (or open it in VS Code with the Claude Code
extension). Fastest path — one line:

```
/pipeline implement a PCIe SG-DMA driver named pcie_sgdma, vendor 0x1234
device 0xABCD, BAR0 64KB, MSI, ioctl-triggered scatter-gather DMA via
dma_map_sg, full error-path cleanup
```

Or paste the longer form below for more control over exactly what each
stage should check:

---

Following the agent pipeline defined in CLAUDE.md, implement a Linux
kernel PCIe endpoint driver named `pcie_sgdma`:

- PCI vendor ID 0x1234, device ID 0xABCD (single BAR0, memory-mapped,
  size 64KB)
- probe() maps BAR0 via pci_iomap, enables the device, enables bus
  mastering, sets a 32-bit DMA mask, and allocates a single MSI vector
- Implements a char device `/dev/pcie_sgdma0` with a custom ioctl
  `PCIE_SGDMA_XFER` that accepts a userspace buffer pointer + length,
  pins it with get_user_pages, builds a scatterlist, and maps it with
  dma_map_sg for a device-to-host transfer
- Builds a simple DMA descriptor ring in BAR0 from the mapped
  scatterlist entries and kicks off the transfer via a control register
  write
- MSI handler acknowledges the interrupt, unmaps the scatterlist
  (dma_unmap_sg), unpins the pages, and completes the pending ioctl via
  a completion variable
- remove() and every probe() error path release all resources in
  correct reverse order

1. code-writer: implement the driver as described above.
2. security-auditor: audit user-pointer handling, DMA size/bounds math,
   and device-status trust boundaries.
3. code-validator: review for resource leaks, missing dma_map_sg
   return-value checks, and error-handling gaps. (Gated automatically —
   the pipeline cannot proceed past this until it reports PASS.)
4. flow-checker: trace probe/remove and interrupt-handler flow, confirm
   no path leaves a resource leaked or double-freed. (Also gated.)
5. test-writer: add KUnit/unit tests for every failure branch and
   bounds check found above.
6. doc-writer: add kernel-doc comments to every function, write
   README.md (build/load/ioctl/test usage), and a CHANGELOG entry.

Output the final driver as `pcie_sgdma.c`, `Makefile`, `README.md`,
`CHANGELOG.md`, and a `tests/` directory.

---

The `sample-output/` folder in this kit shows what the earlier 4-stage
pipeline's deliverable looked like — a good reference for the target
shape. The v2 pipeline adds a security pass and tests on top of it.
