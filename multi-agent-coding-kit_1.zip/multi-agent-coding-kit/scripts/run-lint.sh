#!/usr/bin/env bash
# run-lint.sh — auto-detects and runs the project's own linter/formatter/
# type-checker so code-validator has one command regardless of stack.
# Add an entry here for any tool your team uses that isn't covered.

set -uo pipefail
cd "$(git rev-parse --show-toplevel 2>/dev/null || pwd)"

ran_something=0

run() { echo "--- running: $* ---"; "$@"; ran_something=1; }

[ -f pyproject.toml ] && command -v ruff  >/dev/null && run ruff check .
[ -f pyproject.toml ] && command -v mypy  >/dev/null && run mypy .
[ -f package.json ]   && command -v npx   >/dev/null && [ -f .eslintrc* ] && run npx eslint .
[ -f package.json ]   && command -v npx   >/dev/null && [ -f tsconfig.json ] && run npx tsc --noEmit
[ -f go.mod ]         && command -v go    >/dev/null && run go vet ./...
[ -f go.mod ]         && command -v staticcheck >/dev/null && run staticcheck ./...
[ -f Cargo.toml ]     && command -v cargo >/dev/null && run cargo clippy --all-targets -- -D warnings
find . -name '*.c' -o -name '*.h' 2>/dev/null | grep -q . && \
  [ -x "${KDIR:-/lib/modules/$(uname -r)/build}/scripts/checkpatch.pl" ] && \
  run bash -c 'find . -name "*.c" -newer .git -exec "${KDIR:-/lib/modules/$(uname -r)/build}/scripts/checkpatch.pl" --no-tree -f {} \;'

if [ "$ran_something" -eq 0 ]; then
  echo "no known linter config found (pyproject.toml / package.json / go.mod / Cargo.toml) — skipping"
fi
