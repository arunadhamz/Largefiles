# Sample prompts — generic pipeline

Run `claude` inside any repo (or open it in VS Code with the Claude
Code extension). One line runs the whole pipeline:

```
/pipeline <describe the feature/fix>
```

## Examples across languages

**Python API endpoint**
```
/pipeline add a POST /users/:id/reset-password endpoint that validates
the requesting user owns the account, rate-limits to 3/hour, and sends
a reset email via the existing EmailService
```

**TypeScript/React**
```
/pipeline add a debounced search input to the ProductList component
that calls the existing searchProducts() API and shows a loading state
```

**Go service**
```
/pipeline add a background worker that polls the OrdersQueue every 5s,
processes each order with ProcessOrder(), and retries failed orders up
to 3 times with exponential backoff
```

**C / embedded (see examples/pcie-driver/ for the fully specialized
version of this pipeline)**
```
/pipeline implement a PCIe SG-DMA driver named pcie_sgdma, vendor 0x1234
device 0xABCD, BAR0 64KB, MSI, ioctl-triggered scatter-gather DMA via
dma_map_sg, full error-path cleanup
```

## Longer form
If you want more control over what each stage specifically checks,
skip `/pipeline` and address the agents directly, e.g.:

```
Following the pipeline in CLAUDE.md: use code-writer to implement X,
then security-auditor to check for Y specifically, then the usual
validate/flow-check/test/document stages.
```
