#!/usr/bin/env bash
# gate-on-verdict.sh — used as a SubagentStop hook.
# Reads the hook JSON on stdin, checks the subagent's last message for a
# PASS/FAIL verdict line, and blocks (exit 2) if it reports FAIL or is
# missing a verdict entirely — forcing the agent to resolve blockers
# before the pipeline can move to the next stage.
#
# Only gates agents that are expected to emit a verdict line
# (code-validator -> "VALIDATION:", flow-checker -> "FLOW:"). Other
# agents pass through untouched. Works for any language/project since
# it only inspects the agent_type and message text, not code.

input="$(cat)"
agent_type="$(echo "$input" | grep -o '"agent_type"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"agent_type"[[:space:]]*:[[:space:]]*"\([^"]*\)"/\1/')"
message="$(echo "$input" | grep -o '"last_assistant_message"[[:space:]]*:[[:space:]]*"[^"]*"' )"

case "$agent_type" in
  code-validator)
    tag="VALIDATION"
    ;;
  flow-checker)
    tag="FLOW"
    ;;
  *)
    exit 0
    ;;
esac

if echo "$message" | grep -q "${tag}: PASS"; then
  exit 0
fi

echo "${tag} did not report PASS — resolve the reported blockers before continuing to the next pipeline stage." >&2
exit 2
