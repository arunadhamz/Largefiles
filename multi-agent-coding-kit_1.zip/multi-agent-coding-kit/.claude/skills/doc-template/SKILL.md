---
name: doc-template
description: Use when writing documentation for finished code - doc-comment format per language, README structure, changelog format.
---
Doc-comment format — match the language's own convention:
- Python: docstring (`"""One-line summary. Args/Returns/Raises."""`)
- JS/TS: JSDoc (`/** One-line summary. @param @returns */`)
- C: kernel-doc or Doxygen style, matching what's already in the repo
- Go: comment directly above the declaration, starting with the name
- Java: Javadoc (`/** One-line summary. @param @return @throws */`)

README structure: Overview, Requirements/Install, Usage, API/interface
description (if applicable), Testing, Known limitations.

CHANGELOG entry format: `- [YYYY-MM-DD] short summary of what changed
and why`.
