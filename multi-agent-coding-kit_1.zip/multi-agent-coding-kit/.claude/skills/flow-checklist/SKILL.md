---
name: flow-checklist
description: Use when checking function/control flow in any codebase - covers setup/teardown ordering, error-path unwinding, and concurrent/async consistency.
---
When tracing flow, verify:
- setup and teardown (init/cleanup, open/close, connect/disconnect,
  probe/remove, mount/unmount) acquire and release resources in
  correctly mirrored (reverse) order
- every failure branch unwinds exactly what was acquired before that
  point — check for both leaks (too little unwound) and double-frees/
  double-closes (too much unwound)
- callbacks, interrupt handlers, event listeners, or async completions
  cannot fire against state that a concurrent teardown has already
  freed or invalidated
- every error return is surfaced with information consistent with what
  the caller expects (correct type/shape, not a generic swallow)
- shared/global state is left consistent on both the success path and
  every error path — no partial writes visible to other callers
