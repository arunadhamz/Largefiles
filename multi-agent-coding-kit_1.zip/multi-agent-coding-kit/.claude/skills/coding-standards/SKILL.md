---
name: coding-standards
description: Use when writing or reviewing code in this repo - covers general style, error-handling, and resource-management conventions that apply regardless of language.
---
- Match the style already present in the repo (formatter/linter config
  if one exists — prettier, black, gofmt, clang-format, checkstyle...).
- Every function that can fail should surface that failure explicitly
  (return value, exception, error type) — never silently swallow it.
- Resource acquisition/release must be symmetric: whatever opens,
  connects, allocates, or locks in the happy path must also be
  released on every error path, in reverse order of acquisition.
- Prefer explicit over implicit: named constants over magic numbers,
  explicit types where the language supports them, no unchecked
  external input reaching a size/index/query/shell command.
- Log at the appropriate level (error/warn/info/debug) scoped to the
  component — avoid bare print/console.log left in production code.

Customize this file per-project: add your team's specific linter
command, naming conventions, or architectural rules here.
