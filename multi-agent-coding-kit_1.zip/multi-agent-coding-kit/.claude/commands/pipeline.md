---
description: Run the full 6-agent pipeline (write, audit, validate, flow-check, test, document) for the change described in $ARGUMENTS. Works for any language/repo.
---
Following CLAUDE.md's pipeline order exactly, and without skipping a
stage:

1. code-writer: implement — $ARGUMENTS
2. security-auditor: audit the new code
3. code-validator: validate correctness/style (SubagentStop hook will
   block progress automatically until this reports VALIDATION: PASS)
4. flow-checker: trace call/resource flow (SubagentStop hook will
   block progress automatically until this reports FLOW: PASS)
5. test-writer: add tests for the paths above, using the repo's
   existing test framework
6. doc-writer: document the final result

After each stage, print a one-line status before moving to the next.
