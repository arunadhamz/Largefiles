# Multi-Agent Coding Pipeline

A 6-agent, hook-enforced pipeline for any codebase/language: write ->
audit -> validate -> flow-check -> test -> document.

## Agent Pipeline
For any code change request in this repo, follow this sequence strictly.
You can also just run `/pipeline <description>` to trigger it in one go.

1. **code-writer** — implements the change (model: sonnet). Requests a
   git worktree for anything beyond a trivial one-line fix.
2. **security-auditor** — audits for input-validation, injection,
   secrets, and (where applicable) memory/bounds issues before
   functional review (model: opus — reserve the strongest model for
   the pass where a miss is most costly).
3. **code-validator** — correctness/style/resource-leak review, runs
   `scripts/run-lint.sh` which auto-detects your project's linter
   (model: sonnet). Must end its report with `VALIDATION: PASS` or
   `VALIDATION: FAIL`.
4. **flow-checker** — traces setup/teardown and error-path flow
   (model: sonnet). Must end its report with `FLOW: PASS` or
   `FLOW: FAIL`.
5. **test-writer** — adds tests, using the repo's existing test
   framework, for every failure branch and bounds check the previous
   stages identified (model: sonnet).
6. **doc-writer** — doc comments, README, CHANGELOG (model: haiku —
   cheapest model, since this stage is low-risk formatting work).

## Enforcement (not just instructions)
`.claude/settings.json` registers a **SubagentStop hook**
(`.claude/hooks/gate-on-verdict.sh`) that inspects code-validator's and
flow-checker's final message. If either does not report a `PASS`
verdict, the hook exits 2 and blocks the pipeline from proceeding —
this is a real gate, not just a prompt instruction the model could
skip under context pressure.

A PostToolUse hook also logs every file touched to
`.claude/pipeline.log` for a lightweight audit trail.

## Customizing per project
- Edit `.claude/skills/coding-standards/SKILL.md` with your team's
  actual lint command / naming rules / architecture constraints.
- `scripts/run-lint.sh` auto-detects Python/JS-TS/Go/Rust/C projects —
  add a branch for anything else your stack uses.
- Narrow or widen each agent's `tools:` frontmatter if you want tighter
  permissions (e.g. security-auditor should probably never get Write).
- See `examples/pcie-driver/` for a fully worked example of this same
  pipeline applied to a Linux kernel PCIe driver with scatter-gather
  DMA — useful as a template for adapting the agents to a specific,
  high-rigor domain.
