# multi-agent-coding-kit

A language-agnostic, hook-enforced 6-agent pipeline for Claude Code:
**write → audit → validate → flow-check → test → document**.

## What's in here
```
CLAUDE.md                    # pipeline order + how the enforcement works
.claude/agents/               # the 6 subagents (generic, any language)
.claude/skills/                # coding-standards, flow-checklist, doc-template
.claude/hooks/gate-on-verdict.sh  # SubagentStop hook — blocks pipeline on FAIL
.claude/settings.json          # wires the hooks up
.claude/commands/pipeline.md   # /pipeline slash command
scripts/run-lint.sh            # auto-detects your project's linter
SAMPLE_PROMPT.md               # example prompts across Python/TS/Go/C
examples/pcie-driver/          # fully worked, domain-specialized example
```

## Quick start
1. Copy `.claude/`, `CLAUDE.md`, and `scripts/` into the root of any
   project.
2. `cd` into that project and run `claude` (or open it in VS Code with
   the Claude Code extension installed).
3. Run:
   ```
   /pipeline <describe what you want built or changed>
   ```
   The six agents run in order; `code-validator` and `flow-checker`
   are hard-gated by a hook — the pipeline literally cannot advance
   past them without an explicit PASS verdict.

## Why 6 agents instead of 4
- **code-writer** — implements the change
- **security-auditor** — catches input-validation/injection/secrets/
  bounds issues *before* functional review, since that's the class of
  bug most likely to actually hurt you
- **code-validator** — correctness, style, resource leaks, runs your
  project's real linter
- **flow-checker** — traces setup/teardown and error-path consistency
- **test-writer** — writes tests targeting exactly the failure
  branches and bounds checks the previous two stages found
- **doc-writer** — doc comments, README, changelog

## Making it yours
- `scripts/run-lint.sh` auto-detects Python/TS-JS/Go/Rust/C — add a
  branch for your stack if it's not covered.
- `.claude/skills/coding-standards/SKILL.md` is a stub — fill in your
  team's actual conventions.
- `examples/pcie-driver/` shows how to fork the generic agents into a
  domain-specialized set (kernel/PCIe-specific checks baked into each
  prompt) — use it as a template for your own specialization (web API,
  data pipeline, mobile, etc.).

## A note on cost
Subagent pipelines multiply token usage — running all six stages for
every change costs meaningfully more than a single-thread session.
Reserve the full pipeline for real features/fixes, and feel free to
skip straight to code-writer for trivial edits.
