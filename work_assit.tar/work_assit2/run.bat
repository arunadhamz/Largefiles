@echo off
REM ==============================================================================
REM WorkAssist Pro - Windows Launcher Script
REM ==============================================================================

cd /d "%~dp0"

echo ==================================================
echo  Starting WorkAssist Pro (Windows)
echo ==================================================

where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Error: Python is not found in your PATH.
    echo Please install Python 3.10+ from python.org or Microsoft Store.
    pause
    exit /b 1
)

python main.py %*
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Application exited with error. If dependencies are missing, run:
    echo pip install -r requirements.txt
    pause
)
