#!/usr/bin/env python3
"""Main Entry Point for WorkAssist Pro.
Cross-Platform Qt Desktop Application for Office Task, Project & Meeting Tracking.
Compatible with Linux and Windows.
"""

import sys
import os
from pathlib import Path

# Ensure application root is in python path
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Also ensure user site-packages are reachable if available
user_site = Path.home() / ".local/lib/python3.10/site-packages"
if user_site.exists() and str(user_site) not in sys.path:
    sys.path.insert(0, str(user_site))

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt

from app.database import DatabaseManager
from app.sample_data import seed_sample_data
from app.ai_service import AIService
from app.ui.main_window import MainWindow


def main():
    # High DPI Scaling attributes
    os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"

    app = QApplication(sys.argv)
    app.setApplicationName("WorkAssist Pro")
    app.setOrganizationName("WorkAssist")

    # Initialize Database & Data
    db = DatabaseManager()
    seed_sample_data(db)

    # Initialize AI Intelligence Engine
    ai = AIService()

    # Launch GUI
    window = MainWindow(db, ai)
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
