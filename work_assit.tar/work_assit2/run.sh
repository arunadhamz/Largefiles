#!/usr/bin/env bash
# ==============================================================================
# WorkAssist Pro - Linux Launcher Script
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=================================================="
echo " Starting WorkAssist Pro (Linux)"
echo "=================================================="

# Check if python3 is available
if ! command -v python3 &>/dev/null; then
    echo "Error: python3 is not installed. Please install Python 3.10+."
    exit 1
fi

# Run application using system python or active virtualenv
python3 main.py "$@"
