# ⚡ WorkAssist Pro — Executive Office Task & Meeting Assistant

A high-standard, cross-platform **Qt desktop application (Linux & Windows)** built for multi-project task tracking, daily standup workflows, executive weekly reporting, meeting management, PowerPoint presentation generation, and local Claude AI office assistance.

---

## 🌟 Key Highlights & Features

### 1. 🎨 Ultra-Advanced Modern GUI
- **Linear / Notion Inspired Slate Dark Palette**: Deep navy background (`#0f172a`), slate cards (`#1e293b`), vibrant status accents (Indigo, Emerald, Amber, Rose).
- **Responsive Sidebar Navigation**: 10 purpose-built modules with instant tab switching.
- **Cross-Platform**: Runs natively on **Linux (Ubuntu, Debian, Fedora, Arch)** and **Windows (10 / 11)**.

### 2. 📁 Multi-Project Portfolio Management
- Track 2–3 active enterprise streams with live health badges:
  - 🔹 **On Track** (Emerald)
  - ⏳ **At Risk** (Amber)
  - ⛔ **Delayed** (Rose)
- Pre-loaded with realistic enterprise projects:
  - `[CIM]` **Cloud Infrastructure Modernization**: AWS Kubernetes, Transit Gateway, Terraform.
  - `[CP2]` **Customer Portal 2.0**: OAuth2 OIDC, Stripe payment webhooks, self-service dashboard.
  - `[AIO]` **AI Office Copilot & Automation**: Local Claude orchestration, reporting, and calendar sync.

### 3. 📋 Task-Level Daily Workflow & Kanban Sprint Board
- **Kanban Board**: Drag/Move cards across **To Do**, **In Progress**, **Blocked**, and **Done**.
- **Task Attributes**: Priority pills (*Urgent, High, Medium, Low*), due dates, hours logged, and blocker reason tracking.
- **Full Task Register**: Filterable table view by Project and Priority.

### 4. 📝 Daily Standup Journal
- Log daily accomplishments (*What was completed today*), tomorrow's targets, and blocker impediments.
- **AI Standup Polish**: One-click refinement that transforms rough notes into executive standup updates.

### 5. 👥 Executive Meeting Assistant & MoM Recorder
- **Full Meeting Data**: Track meeting type, date/time, duration, involved projects, attendees, and agenda.
- **Live Minutes of Meeting (MoM)**: Record real-time discussion notes and agreed key decisions.
- **Action Items to Tasks**: One-click convert any meeting action item directly into a tracked project task.
- **AI Meeting Prep**: Auto-generates meeting docket, talking points, and escalation questions based on current project blockers.

### 6. 🤖 Local Claude & AI Intelligence Engine
- **Local Ollama Integration**: Connects to `http://localhost:11434` running local Claude models or open-weights models (`llama3.2`, `mistral`, `deepseek-r1`).
- **Anthropic Claude API Support**: Cloud Claude 3.5 Sonnet support with custom API key.
- **OpenAI-Compatible Local Endpoints**: LM Studio, LocalAI, vLLM (`http://localhost:1234/v1`).
- **Resilient Offline Reasoning Engine**: Works 100% reliably out of the box even when offline.

### 7. 📤 Document & Calendar Extraction (ODT, CAL, and PPT)
- 📊 **PowerPoint Presentation (.pptx)**: Generates executive slide decks ready for PowerPoint / LibreOffice Impress. Includes Executive Health KPIs, per-project status slides, blockers & risk escalations, and next week's deliverables.
- 📄 **OpenDocument Text (.odt)**: Generates formatted executive reports for LibreOffice Writer, Microsoft Word, and Google Docs.
- 📅 **iCalendar (.ics / CAL)**: Generates RFC 5545 calendar files with all meetings and deadlines ready to import into **Google Calendar, Microsoft Outlook, Apple Calendar, or Thunderbird**.

---

## 🚀 Quick Start Guide

### 🐧 On Linux (Ubuntu / Debian / Fedora)
```bash
# 1. Navigate to the project directory
cd /mnt/work_assit

# 2. Run the application
./run.sh
# Or directly:
python3 main.py
```

### 🪟 On Windows
Double-click `run.bat` or open PowerShell / Command Prompt:
```cmd
cd /d C:\path\to\work_assit
run.bat
:: Or directly:
python main.py
```

---

## 📦 Dependencies

The application uses standard modern Python libraries:
```txt
PySide6>=6.5.0
python-pptx>=1.0.0
requests>=2.28.0
```

To install on any fresh system:
```bash
pip install -r requirements.txt
```

---

## 🤖 Configuring Local Claude (Ollama)

If you have [Ollama](https://ollama.ai) installed:

1. Start your local Ollama server:
   ```bash
   ollama serve
   ```
2. Pull your desired model (e.g., `llama3.2`, `mistral`, or `claude-3-5-sonnet` if using a custom Modelfile):
   ```bash
   ollama run llama3.2
   ```
3. Open **WorkAssist Pro ➔ Settings**:
   - Provider: **Local Ollama**
   - URL: `http://localhost:11434`
   - Model: Enter your model tag (e.g. `llama3.2`)
   - Click **⚡ Test AI Connection**.

---

## 📂 Project Architecture

```
/mnt/work_assit/
├── main.py                     # Application entry point
├── run.sh                      # One-click Linux launcher
├── run.bat                     # One-click Windows launcher
├── requirements.txt            # Python dependencies
├── README.md                   # Documentation & User Guide
├── test_suite.py               # Comprehensive verification suite
├── data/
│   ├── workassist.db           # SQLite database
│   └── config.json             # User preferences & AI settings
├── exports/                    # Extracted PPT, ODT, and CAL files
│   ├── *.pptx                  # PowerPoint presentations
│   ├── *.odt                   # OpenDocument text reports
│   └── *.ics                   # iCalendar schedules
└── app/
    ├── config.py               # Settings loader/saver
    ├── database.py             # SQLite CRUD (Projects, Tasks, Meetings, Logs)
    ├── sample_data.py          # Realistic initial multi-project data
    ├── ai_service.py           # Local Claude / Ollama / API engine
    ├── ppt_generator.py        # Executive PowerPoint deck engine
    ├── odt_generator.py        # Native OpenDocument Text generator
    ├── calendar_generator.py   # RFC 5545 iCalendar (.ics) generator
    ├── styles.py               # Ultra-modern dark slate stylesheet (QSS)
    └── ui/
        ├── main_window.py      # Core window with sidebar navigation
        ├── dashboard_view.py   # KPI metrics & quick focus
        ├── projects_view.py    # 3-Project portfolio management
        ├── tasks_view.py       # Kanban board & task register
        ├── daily_workflow_view.py # Daily standup journal
        ├── meetings_view.py    # Meeting Assistant, MoM & action items
        ├── reports_view.py     # Weekly report synthesizer
        ├── ppt_view.py         # Slide deck preparation & download
        ├── calendar_view.py    # CAL schedule & export
        ├── assistant_view.py   # Interactive Claude AI chat
        └── settings_view.py    # AI provider configuration
```

---

## 🧪 Verification & Testing

To run the complete automated verification suite:
```bash
python3 test_suite.py
```
This tests database initialization, sample data seeding, AI offline completions, PPTX slide deck creation, ODT generation, iCalendar generation, and all 10 Qt GUI views in offscreen mode.
