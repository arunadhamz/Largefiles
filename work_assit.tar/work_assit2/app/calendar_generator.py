"""iCalendar (.ics / CAL) Generator.
Generates RFC 5545 standard .ics files for importing meetings and task deadlines
into Google Calendar, Microsoft Outlook, Apple Calendar, or Thunderbird.
"""

from __future__ import annotations
import uuid
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional


class CalendarGenerator:
    """Generates standard .ics calendar files for meetings and task milestones."""

    def __init__(self, output_dir: Optional[Path] = None):
        self.output_dir = output_dir or (Path(__file__).resolve().parent.parent / "exports")
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_calendar(
        self,
        meetings: List[Dict[str, Any]],
        tasks: Optional[List[Dict[str, Any]]] = None,
        filename: Optional[str] = None
    ) -> Path:
        """Export all meetings and task deadlines as a standard .ics calendar file."""
        if not filename:
            today_str = date.today().strftime("%Y%m%d")
            filename = f"WorkAssist_Office_Calendar_{today_str}.ics"

        output_path = self.output_dir / filename

        ics_lines = [
            "BEGIN:VCALENDAR",
            "VERSION:2.0",
            "PRODID:-//WorkAssist Pro//Office Productivity Suite//EN",
            "CALSCALE:GREGORIAN",
            "METHOD:PUBLISH",
            "X-WR-CALNAME:WorkAssist Office Schedule",
            "X-WR-TIMEZONE:UTC",
        ]

        # 1. Add Meetings
        for m in meetings:
            event_lines = self._meeting_to_vevent(m)
            ics_lines.extend(event_lines)

        # 2. Add Urgent & High-Priority Tasks as Calendar Milestones
        if tasks:
            for t in tasks:
                if t.get("due_date") and t.get("status") != "Done":
                    task_lines = self._task_to_vevent(t)
                    ics_lines.extend(task_lines)

        ics_lines.append("END:VCALENDAR")
        ics_content = "\r\n".join(ics_lines) + "\r\n"

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(ics_content)

        return output_path

    def _meeting_to_vevent(self, m: Dict[str, Any]) -> List[str]:
        lines = ["BEGIN:VEVENT"]
        uid = f"meeting-{m.get('id', uuid.uuid4())}@workassist.pro"
        lines.append(f"UID:{uid}")

        # Timestamps
        dt_str = m.get("meeting_date", "")
        duration = m.get("duration_minutes", 45)

        try:
            # Parse 'YYYY-MM-DD HH:MM' or 'YYYY-MM-DD'
            if len(dt_str) == 10:
                start_dt = datetime.strptime(dt_str, "%Y-%m-%d").replace(hour=10, minute=0)
            else:
                start_dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
        except Exception:
            start_dt = datetime.now() + timedelta(days=1)

        end_dt = start_dt + timedelta(minutes=duration)

        dtstamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        dtstart = start_dt.strftime("%Y%m%dT%H%M%S")
        dtend = end_dt.strftime("%Y%m%dT%H%M%S")

        lines.append(f"DTSTAMP:{dtstamp}")
        lines.append(f"DTSTART:{dtstart}")
        lines.append(f"DTEND:{dtend}")
        lines.append(f"SUMMARY:{self._sanitize(m.get('title', 'Office Meeting'))}")

        desc_parts = [
            f"Type: {m.get('meeting_type', 'Sync')}",
            f"Attendees: {m.get('attendees', '')}",
            f"Agenda:\n{m.get('agenda', '')}",
            f"Key Decisions:\n{m.get('key_decisions', '')}",
        ]
        desc = "\\n".join([self._sanitize(p) for p in desc_parts if p.strip()])
        lines.append(f"DESCRIPTION:{desc}")
        lines.append("STATUS:CONFIRMED")
        lines.append("TRANSP:OPAQUE")
        lines.append("END:VEVENT")
        return lines

    def _task_to_vevent(self, t: Dict[str, Any]) -> List[str]:
        lines = ["BEGIN:VEVENT"]
        uid = f"task-{t.get('id', uuid.uuid4())}@workassist.pro"
        lines.append(f"UID:{uid}")

        due_date_str = t.get("due_date", "")
        try:
            due_dt = datetime.strptime(due_date_str, "%Y-%m-%d").replace(hour=17, minute=0)
        except Exception:
            due_dt = datetime.now()

        dtstamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        dtstart = due_dt.strftime("%Y%m%dT%H%M%S")
        dtend = (due_dt + timedelta(minutes=30)).strftime("%Y%m%dT%H%M%S")

        lines.append(f"DTSTAMP:{dtstamp}")
        lines.append(f"DTSTART:{dtstart}")
        lines.append(f"DTEND:{dtend}")
        summary = f"DEADLINE: {t.get('title')} [{t.get('priority')}]"
        lines.append(f"SUMMARY:{self._sanitize(summary)}")

        desc = f"Project: {t.get('project_code', '')}\\nStatus: {t.get('status')}\\nAssigned: {t.get('assigned_to', '')}"
        if t.get("blocker_reason"):
            desc += f"\\nBlocker: {t.get('blocker_reason')}"
        lines.append(f"DESCRIPTION:{self._sanitize(desc)}")
        lines.append("STATUS:CONFIRMED")
        lines.append("TRANSP:TRANSPARENT")
        lines.append("END:VEVENT")
        return lines

    def _sanitize(self, text: str) -> str:
        """Escape text for iCalendar standards."""
        if not text:
            return ""
        return (
            text.replace("\\", "\\\\")
            .replace(";", "\\;")
            .replace(",", "\\,")
            .replace("\r\n", "\\n")
            .replace("\n", "\\n")
        )
