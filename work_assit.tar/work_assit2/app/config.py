"""Application Configuration and Settings Management.
Works seamlessly across Windows, Linux, and macOS.
"""

from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any, Dict

# Base paths
ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
EXPORTS_DIR = ROOT_DIR / "exports"
CONFIG_PATH = DATA_DIR / "config.json"
DB_PATH = DATA_DIR / "workassist.db"

# Ensure runtime directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

# Default Settings
DEFAULT_CONFIG: Dict[str, Any] = {
    "app_name": "WorkAssist Pro",
    "user_name": "Lead Engineer",
    "user_title": "Project Lead",
    "theme": "dark_modern",
    "ai_provider": "ollama",  # "ollama", "anthropic", "openai_compatible", "offline"
    "ollama_url": "http://localhost:11434",
    "ollama_model": "claude-3-5-sonnet",
    "anthropic_api_key": "",
    "anthropic_model": "claude-3-5-sonnet-20241022",
    "openai_base_url": "http://localhost:1234/v1",
    "openai_model": "local-model",
    "meeting_reminders": True,
    "default_pptx_theme": "Modern Executive Navy",
    "weekly_report_day": "Friday",
}


def load_config() -> Dict[str, Any]:
    """Load configuration from disk, falling back to defaults."""
    if not CONFIG_PATH.exists():
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            saved = json.load(f)
            config = DEFAULT_CONFIG.copy()
            config.update(saved)
            return config
    except Exception:
        return DEFAULT_CONFIG.copy()


def save_config(config: Dict[str, Any]) -> bool:
    """Save configuration to disk."""
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False
