"""Office Assistant Desktop Application
A cross-platform (Linux & Windows) Qt productivity suite for tracking office tasks,
projects, daily workflows, meetings, presentations (PPTX), ODT reports, and CAL exports,
powered by Local Claude and intelligent LLM assistance.
"""

__version__ = "2.0.0"
__app_name__ = "WorkAssist Pro"
