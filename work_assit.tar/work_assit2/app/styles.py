"""Ultra-Modern Dark Slate UI Styling for WorkAssist Pro.
Gives the application an ultra-advanced, executive Linear / Notion feel.
"""

MODERN_DARK_QSS = """
/* Global Application Styles */
QWidget {
    background-color: #0f172a;
    color: #f8fafc;
    font-family: -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Ubuntu, sans-serif;
    font-size: 13px;
    outline: none;
}

/* ScrollBars */
QScrollBar:vertical {
    border: none;
    background: #0f172a;
    width: 8px;
    margin: 0px 0px 0px 0px;
}
QScrollBar::handle:vertical {
    background: #334155;
    min-height: 24px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #475569;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QScrollBar:horizontal {
    border: none;
    background: #0f172a;
    height: 8px;
}
QScrollBar::handle:horizontal {
    background: #334155;
    min-width: 24px;
    border-radius: 4px;
}

/* Sidebar Navigation */
QFrame#Sidebar {
    background-color: #1e293b;
    border-right: 1px solid #334155;
    min-width: 220px;
    max-width: 220px;
}

QPushButton.NavButton {
    background-color: transparent;
    color: #94a3b8;
    text-align: left;
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    border: none;
}
QPushButton.NavButton:hover {
    background-color: #334155;
    color: #f8fafc;
}
QPushButton.NavButton:checked {
    background-color: #4f46e5;
    color: #ffffff;
    font-weight: 600;
}

/* Cards and Panels */
QFrame.Card {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 10px;
    padding: 14px;
}
QFrame.Card:hover {
    border-color: #475569;
}

/* KPI Stat Cards */
QFrame.KpiCard {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 16px;
}

/* Buttons */
QPushButton.PrimaryBtn {
    background-color: #4f46e5;
    color: #ffffff;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
}
QPushButton.PrimaryBtn:hover {
    background-color: #6366f1;
}
QPushButton.PrimaryBtn:pressed {
    background-color: #4338ca;
}

QPushButton.SuccessBtn {
    background-color: #059669;
    color: #ffffff;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
}
QPushButton.SuccessBtn:hover {
    background-color: #10b981;
}

QPushButton.SecondaryBtn {
    background-color: #334155;
    color: #f8fafc;
    border: 1px solid #475569;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 500;
}
QPushButton.SecondaryBtn:hover {
    background-color: #475569;
}

QPushButton.DangerBtn {
    background-color: #dc2626;
    color: #ffffff;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
}
QPushButton.DangerBtn:hover {
    background-color: #ef4444;
}

/* Inputs and Forms */
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QDateEdit, QSpinBox {
    background-color: #0f172a;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 8px 12px;
    color: #f8fafc;
    selection-background-color: #4f46e5;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus {
    border: 1px solid #6366f1;
}

QComboBox::drop-down {
    border: none;
    width: 24px;
}
QComboBox QAbstractItemView {
    background-color: #1e293b;
    border: 1px solid #334155;
    selection-background-color: #4f46e5;
    color: #f8fafc;
    padding: 4px;
}

/* Tables */
QTableWidget {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 8px;
    gridline-color: transparent;
    selection-background-color: #334155;
    selection-color: #f8fafc;
}
QTableWidget::item {
    padding: 10px;
    border-bottom: 1px solid #283548;
}
QTableWidget::item:selected {
    background-color: #2b394f;
}
QHeaderView::section {
    background-color: #162032;
    color: #94a3b8;
    font-weight: 600;
    padding: 10px;
    border: none;
    border-bottom: 2px solid #334155;
}

/* Badges / Pills */
QLabel.Badge {
    padding: 3px 8px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 600;
}

/* Headers */
QLabel.PageTitle {
    font-size: 22px;
    font-weight: 700;
    color: #f8fafc;
}
QLabel.SectionTitle {
    font-size: 16px;
    font-weight: 600;
    color: #e2e8f0;
}
QLabel.Subtitle {
    font-size: 13px;
    color: #94a3b8;
}

/* Dialogs */
QDialog {
    background-color: #1e293b;
    border-radius: 12px;
}
"""
