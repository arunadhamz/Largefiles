"""Database Manager for WorkAssist Pro.
Handles SQLite operations, schema creation, migrations, and CRUD operations.
"""

from __future__ import annotations
import sqlite3
from datetime import datetime, date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from app.config import DB_PATH


class DatabaseManager:
    """Manages SQLite database connections and operations."""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or DB_PATH
        self.init_db()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def init_db(self) -> None:
        """Create all tables with appropriate indices if they don't exist."""
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Projects Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                description TEXT,
                color TEXT DEFAULT '#3b82f6',
                status TEXT DEFAULT 'Active',
                priority TEXT DEFAULT 'High',
                health TEXT DEFAULT 'On Track',
                start_date TEXT,
                target_date TEXT,
                lead_name TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # Tasks Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'To Do',
                priority TEXT DEFAULT 'Medium',
                category TEXT DEFAULT 'Development',
                due_date TEXT,
                estimated_hours REAL DEFAULT 0.0,
                actual_hours REAL DEFAULT 0.0,
                blocker_reason TEXT,
                assigned_to TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                completed_at TEXT,
                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
            )
            """)

            # Daily Logs Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                log_date TEXT NOT NULL,
                project_id INTEGER,
                completed_today TEXT,
                planned_tomorrow TEXT,
                blockers TEXT,
                hours_spent REAL DEFAULT 0.0,
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
            )
            """)

            # Meetings Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS meetings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                meeting_type TEXT DEFAULT 'Weekly Sync',
                meeting_date TEXT NOT NULL,
                duration_minutes INTEGER DEFAULT 45,
                projects_involved TEXT,
                attendees TEXT,
                agenda TEXT,
                notes TEXT,
                key_decisions TEXT,
                status TEXT DEFAULT 'Scheduled',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # Action Items Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS action_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                meeting_id INTEGER,
                project_id INTEGER,
                task_id INTEGER,
                description TEXT NOT NULL,
                assignee TEXT,
                due_date TEXT,
                status TEXT DEFAULT 'Open',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (meeting_id) REFERENCES meetings(id) ON DELETE CASCADE,
                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL
            )
            """)

            # Reports Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                report_type TEXT DEFAULT 'Weekly',
                period_start TEXT,
                period_end TEXT,
                content_markdown TEXT,
                summary TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # AI Chat History Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS ai_chat (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                context_type TEXT DEFAULT 'general',
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # Indices for rapid querying
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(due_date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_meetings_date ON meetings(meeting_date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_daily_logs_date ON daily_logs(log_date)")
            conn.commit()

    # ==========================================
    # Project CRUD
    # ==========================================
    def get_projects(self) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT p.*, 
                       COUNT(t.id) as total_tasks,
                       SUM(CASE WHEN t.status = 'Done' THEN 1 ELSE 0 END) as done_tasks,
                       SUM(CASE WHEN t.status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                       SUM(CASE WHEN t.status = 'Blocked' THEN 1 ELSE 0 END) as blocked_tasks
                FROM projects p
                LEFT JOIN tasks t ON p.id = t.project_id
                GROUP BY p.id
                ORDER BY p.name ASC
            """)
            return [dict(row) for row in cursor.fetchall()]

    def get_project_by_id(self, project_id: int) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def add_project(self, data: Dict[str, Any]) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO projects (name, code, description, color, status, priority, health, start_date, target_date, lead_name)
                VALUES (:name, :code, :description, :color, :status, :priority, :health, :start_date, :target_date, :lead_name)
            """, data)
            conn.commit()
            return cursor.lastrowid

    def update_project(self, project_id: int, data: Dict[str, Any]) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            fields = ", ".join([f"{k} = :{k}" for k in data.keys()])
            data_with_id = data.copy()
            data_with_id["id"] = project_id
            cursor.execute(f"UPDATE projects SET {fields} WHERE id = :id", data_with_id)
            conn.commit()
            return cursor.rowcount > 0

    def delete_project(self, project_id: int) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM projects WHERE id = ?", (project_id,))
            conn.commit()
            return cursor.rowcount > 0

    # ==========================================
    # Task CRUD
    # ==========================================
    def get_tasks(self, project_id: Optional[int] = None, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            query = """
                SELECT t.*, p.name as project_name, p.code as project_code, p.color as project_color
                FROM tasks t
                LEFT JOIN projects p ON t.project_id = p.id
                WHERE 1=1
            """
            params: List[Any] = []
            if project_id:
                query += " AND t.project_id = ?"
                params.append(project_id)
            if status:
                query += " AND t.status = ?"
                params.append(status)

            query += """
                ORDER BY 
                CASE t.priority 
                    WHEN 'Urgent' THEN 1 
                    WHEN 'High' THEN 2 
                    WHEN 'Medium' THEN 3 
                    WHEN 'Low' THEN 4 
                    ELSE 5 
                END, 
                t.due_date ASC, t.id DESC
            """
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_task_by_id(self, task_id: int) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT t.*, p.name as project_name, p.code as project_code, p.color as project_color
                FROM tasks t
                LEFT JOIN projects p ON t.project_id = p.id
                WHERE t.id = ?
            """, (task_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def add_task(self, data: Dict[str, Any]) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO tasks (project_id, title, description, status, priority, category, due_date, estimated_hours, actual_hours, blocker_reason, assigned_to)
                VALUES (:project_id, :title, :description, :status, :priority, :category, :due_date, :estimated_hours, :actual_hours, :blocker_reason, :assigned_to)
            """, data)
            conn.commit()
            return cursor.lastrowid

    def update_task(self, task_id: int, data: Dict[str, Any]) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            data_with_id = data.copy()
            data_with_id["id"] = task_id
            data_with_id["updated_at"] = datetime.now().isoformat()
            
            if data.get("status") == "Done" and "completed_at" not in data:
                data_with_id["completed_at"] = datetime.now().isoformat()
            elif data.get("status") and data.get("status") != "Done":
                data_with_id["completed_at"] = None

            fields = ", ".join([f"{k} = :{k}" for k in data_with_id.keys() if k != "id"])
            cursor.execute(f"UPDATE tasks SET {fields} WHERE id = :id", data_with_id)
            conn.commit()
            return cursor.rowcount > 0

    def update_task_status(self, task_id: int, new_status: str) -> bool:
        completed_at = datetime.now().isoformat() if new_status == "Done" else None
        return self.update_task(task_id, {"status": new_status, "completed_at": completed_at})

    def delete_task(self, task_id: int) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
            conn.commit()
            return cursor.rowcount > 0

    # ==========================================
    # Daily Workflow Logs CRUD
    # ==========================================
    def get_daily_logs(self, limit: int = 30) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT dl.*, p.name as project_name, p.code as project_code, p.color as project_color
                FROM daily_logs dl
                LEFT JOIN projects p ON dl.project_id = p.id
                ORDER BY dl.log_date DESC, dl.id DESC
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_log_by_date(self, log_date: str) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM daily_logs WHERE log_date = ?", (log_date,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def add_or_update_daily_log(self, data: Dict[str, Any]) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            log_date = data["log_date"]
            cursor.execute("SELECT id FROM daily_logs WHERE log_date = ?", (log_date,))
            existing = cursor.fetchone()
            if existing:
                log_id = existing["id"]
                data_copy = data.copy()
                data_copy["id"] = log_id
                fields = ", ".join([f"{k} = :{k}" for k in data_copy.keys() if k != "id"])
                cursor.execute(f"UPDATE daily_logs SET {fields} WHERE id = :id", data_copy)
                conn.commit()
                return log_id
            else:
                cursor.execute("""
                    INSERT INTO daily_logs (log_date, project_id, completed_today, planned_tomorrow, blockers, hours_spent, notes)
                    VALUES (:log_date, :project_id, :completed_today, :planned_tomorrow, :blockers, :hours_spent, :notes)
                """, data)
                conn.commit()
                return cursor.lastrowid

    # ==========================================
    # Meetings & Action Items CRUD
    # ==========================================
    def get_meetings(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            query = """
                SELECT m.*,
                       COUNT(a.id) as total_actions,
                       SUM(CASE WHEN a.status = 'Completed' THEN 1 ELSE 0 END) as completed_actions
                FROM meetings m
                LEFT JOIN action_items a ON m.id = a.meeting_id
                WHERE 1=1
            """
            params: List[Any] = []
            if status:
                query += " AND m.status = ?"
                params.append(status)
            query += " GROUP BY m.id ORDER BY m.meeting_date DESC"
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_meeting_by_id(self, meeting_id: int) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM meetings WHERE id = ?", (meeting_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def add_meeting(self, data: Dict[str, Any]) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO meetings (title, meeting_type, meeting_date, duration_minutes, projects_involved, attendees, agenda, notes, key_decisions, status)
                VALUES (:title, :meeting_type, :meeting_date, :duration_minutes, :projects_involved, :attendees, :agenda, :notes, :key_decisions, :status)
            """, data)
            conn.commit()
            return cursor.lastrowid

    def update_meeting(self, meeting_id: int, data: Dict[str, Any]) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            data_with_id = data.copy()
            data_with_id["id"] = meeting_id
            fields = ", ".join([f"{k} = :{k}" for k in data_with_id.keys() if k != "id"])
            cursor.execute(f"UPDATE meetings SET {fields} WHERE id = :id", data_with_id)
            conn.commit()
            return cursor.rowcount > 0

    def delete_meeting(self, meeting_id: int) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM meetings WHERE id = ?", (meeting_id,))
            conn.commit()
            return cursor.rowcount > 0

    def get_action_items(self, meeting_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            query = """
                SELECT a.*, m.title as meeting_title, p.name as project_name, p.color as project_color
                FROM action_items a
                LEFT JOIN meetings m ON a.meeting_id = m.id
                LEFT JOIN projects p ON a.project_id = p.id
                WHERE 1=1
            """
            params: List[Any] = []
            if meeting_id:
                query += " AND a.meeting_id = ?"
                params.append(meeting_id)
            query += " ORDER BY a.status ASC, a.due_date ASC"
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def add_action_item(self, data: Dict[str, Any]) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO action_items (meeting_id, project_id, task_id, description, assignee, due_date, status)
                VALUES (:meeting_id, :project_id, :task_id, :description, :assignee, :due_date, :status)
            """, data)
            conn.commit()
            return cursor.lastrowid

    def update_action_item_status(self, item_id: int, status: str) -> bool:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE action_items SET status = ? WHERE id = ?", (status, item_id))
            conn.commit()
            return cursor.rowcount > 0

    def convert_action_item_to_task(self, action_item_id: int, project_id: int) -> int:
        """Convert a meeting action item into a tracked project task."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM action_items WHERE id = ?", (action_item_id,))
            item = cursor.fetchone()
            if not item:
                return 0
            
            # Create task
            task_data = {
                "project_id": project_id,
                "title": f"[Meeting Action] {item['description']}",
                "description": f"Created from Meeting Action Item ID #{action_item_id}",
                "status": "To Do",
                "priority": "High",
                "category": "Management",
                "due_date": item["due_date"] or date.today().isoformat(),
                "estimated_hours": 2.0,
                "actual_hours": 0.0,
                "blocker_reason": "",
                "assigned_to": item["assignee"] or "Self"
            }
            cursor.execute("""
                INSERT INTO tasks (project_id, title, description, status, priority, category, due_date, estimated_hours, actual_hours, blocker_reason, assigned_to)
                VALUES (:project_id, :title, :description, :status, :priority, :category, :due_date, :estimated_hours, :actual_hours, :blocker_reason, :assigned_to)
            """, task_data)
            task_id = cursor.lastrowid

            # Link back to action item
            cursor.execute("UPDATE action_items SET task_id = ?, project_id = ? WHERE id = ?", (task_id, project_id, action_item_id))
            conn.commit()
            return task_id

    # ==========================================
    # Reports CRUD
    # ==========================================
    def get_reports(self) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM reports ORDER BY created_at DESC")
            return [dict(row) for row in cursor.fetchall()]

    def add_report(self, data: Dict[str, Any]) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO reports (title, report_type, period_start, period_end, content_markdown, summary)
                VALUES (:title, :report_type, :period_start, :period_end, :content_markdown, :summary)
            """, data)
            conn.commit()
            return cursor.lastrowid

    # ==========================================
    # AI Chat CRUD
    # ==========================================
    def get_chat_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM ai_chat ORDER BY id ASC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def add_chat_message(self, role: str, content: str, context_type: str = "general") -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO ai_chat (role, content, context_type)
                VALUES (?, ?, ?)
            """, (role, content, context_type))
            conn.commit()
            return cursor.lastrowid

    def clear_chat_history(self) -> None:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM ai_chat")
            conn.commit()

    # ==========================================
    # Dashboard KPI Metrics
    # ==========================================
    def get_dashboard_metrics(self) -> Dict[str, Any]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM projects WHERE status = 'Active'")
            active_projects = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM tasks WHERE status = 'Done'")
            completed_tasks = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM tasks WHERE status = 'In Progress'")
            in_progress_tasks = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM tasks WHERE status = 'Blocked'")
            blocked_tasks = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM tasks WHERE status = 'To Do'")
            todo_tasks = cursor.fetchone()[0]

            today_str = date.today().isoformat()
            cursor.execute("""
                SELECT * FROM meetings 
                WHERE meeting_date >= ? AND status != 'Cancelled'
                ORDER BY meeting_date ASC LIMIT 1
            """, (today_str,))
            next_meeting = cursor.fetchone()

            cursor.execute("SELECT SUM(hours_spent) FROM daily_logs")
            total_hours = cursor.fetchone()[0] or 0.0

            return {
                "active_projects": active_projects,
                "completed_tasks": completed_tasks,
                "in_progress_tasks": in_progress_tasks,
                "blocked_tasks": blocked_tasks,
                "todo_tasks": todo_tasks,
                "total_tasks": completed_tasks + in_progress_tasks + blocked_tasks + todo_tasks,
                "next_meeting": dict(next_meeting) if next_meeting else None,
                "total_hours": total_hours,
            }
