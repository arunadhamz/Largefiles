"""Interactive Kanban Board and Task Management View."""

from __future__ import annotations
from datetime import date
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QScrollArea, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QDialog, QLineEdit, QTextEdit, QComboBox, QFormLayout, QMessageBox,
    QDoubleSpinBox
)

from app.database import DatabaseManager


class TasksView(QWidget):
    """Task level daily workflow view with Kanban columns and list mode."""

    def __init__(self, db: DatabaseManager, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.init_ui()

    def init_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 24, 24, 24)
        main_layout.setSpacing(16)

        # 1. Header Toolbar
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Task Level Daily Workflow")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        sub = QLabel("Kanban sprint board, daily work-to-do checklists, and blocker tracking")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        # Filters
        self.project_filter = QComboBox()
        self.project_filter.setMinimumWidth(150)
        self.project_filter.currentIndexChanged.connect(self.refresh)

        self.priority_filter = QComboBox()
        self.priority_filter.addItems(["All Priorities", "Urgent", "High", "Medium", "Low"])
        self.priority_filter.currentIndexChanged.connect(self.refresh)

        btn_add = QPushButton("+ Add Task")
        btn_add.setProperty("class", "PrimaryBtn")
        btn_add.clicked.connect(self.show_add_task_dialog)

        hdr.addWidget(QLabel("Project:"))
        hdr.addWidget(self.project_filter)
        hdr.addWidget(QLabel("Priority:"))
        hdr.addWidget(self.priority_filter)
        hdr.addWidget(btn_add)
        main_layout.addLayout(hdr)

        # 2. Tabs: Kanban Board & Table List
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabBar::tab {
                background: #1e293b;
                color: #94a3b8;
                padding: 8px 20px;
                margin-right: 4px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                font-weight: 600;
            }
            QTabBar::tab:selected {
                background: #4f46e5;
                color: #ffffff;
            }
        """)

        # Tab 1: Kanban Board
        self.kanban_widget = QWidget()
        self.kanban_layout = QHBoxLayout(self.kanban_widget)
        self.kanban_layout.setContentsMargins(0, 10, 0, 0)
        self.kanban_layout.setSpacing(14)
        self.tabs.addTab(self.kanban_widget, "📋 Kanban Sprint Board")

        # Tab 2: Table List
        self.table_widget = QWidget()
        tbl_layout = QVBoxLayout(self.table_widget)
        tbl_layout.setContentsMargins(0, 10, 0, 0)
        self.task_table = QTableWidget()
        self.task_table.setColumnCount(8)
        self.task_table.setHorizontalHeaderLabels([
            "Status", "Task Title", "Project", "Priority", "Due Date", "Hours", "Blocker / Notes", "Actions"
        ])
        self.task_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.task_table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        tbl_layout.addWidget(self.task_table)
        self.tabs.addTab(self.table_widget, "📄 Full Task Register")

        main_layout.addWidget(self.tabs)

        self.update_project_filter_items()
        self.refresh()

    def update_project_filter_items(self) -> None:
        self.project_filter.blockSignals(True)
        self.project_filter.clear()
        self.project_filter.addItem("All Projects", None)
        for p in self.db.get_projects():
            self.project_filter.addItem(f"[{p.get('code')}] {p.get('name')}", p.get("id"))
        self.project_filter.blockSignals(False)

    def refresh(self) -> None:
        # Load filtered tasks
        p_id = self.project_filter.currentData()
        pri_filter = self.priority_filter.currentText()

        all_tasks = self.db.get_tasks(project_id=p_id)
        if pri_filter != "All Priorities":
            tasks = [t for t in all_tasks if t.get("priority") == pri_filter]
        else:
            tasks = all_tasks

        self._render_kanban(tasks)
        self._render_table(tasks)

    def _render_kanban(self, tasks: List[Dict[str, Any]]) -> None:
        # Clear existing columns
        while self.kanban_layout.count():
            item = self.kanban_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        columns = [
            ("To Do", "#3b82f6", "To Do"),
            ("In Progress", "#f59e0b", "In Progress"),
            ("Blocked", "#ef4444", "Blocked"),
            ("Done", "#10b981", "Done")
        ]

        for col_name, color, status_key in columns:
            col_tasks = [t for t in tasks if t.get("status") == status_key]

            col_frame = QFrame()
            col_frame.setStyleSheet(f"""
                QFrame {{
                    background-color: #1e293b;
                    border: 1px solid #334155;
                    border-top: 3px solid {color};
                    border-radius: 8px;
                }}
            """)
            col_layout = QVBoxLayout(col_frame)
            col_layout.setContentsMargins(10, 10, 10, 10)
            col_layout.setSpacing(10)

            # Column Header
            ch_layout = QHBoxLayout()
            c_title = QLabel(col_name)
            c_title.setStyleSheet(f"font-size: 14px; font-weight: 700; color: #f8fafc;")
            c_count = QLabel(f" {len(col_tasks)} ")
            c_count.setStyleSheet(f"background: #0f172a; color: {color}; border-radius: 10px; font-weight: 700; font-size: 11px; padding: 2px 6px;")
            ch_layout.addWidget(c_title)
            ch_layout.addStretch()
            ch_layout.addWidget(c_count)
            col_layout.addLayout(ch_layout)

            # Scroll area for cards in this column
            col_scroll = QScrollArea()
            col_scroll.setWidgetResizable(True)
            col_scroll.setFrameShape(QFrame.NoFrame)
            col_scroll.setStyleSheet("background: transparent;")

            scroll_content = QWidget()
            cards_vbox = QVBoxLayout(scroll_content)
            cards_vbox.setContentsMargins(0, 0, 0, 0)
            cards_vbox.setSpacing(10)

            for t in col_tasks:
                card = self._create_kanban_card(t)
                cards_vbox.addWidget(card)

            cards_vbox.addStretch()
            col_scroll.setWidget(scroll_content)
            col_layout.addWidget(col_scroll)

            self.kanban_layout.addWidget(col_frame, 1)

    def _create_kanban_card(self, t: Dict[str, Any]) -> QFrame:
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background-color: #0f172a;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 10px;
            }
            QFrame:hover {
                border-color: #6366f1;
            }
        """)
        c_layout = QVBoxLayout(card)
        c_layout.setContentsMargins(10, 10, 10, 10)
        c_layout.setSpacing(6)

        # Top row: Project Badge + Priority
        top_row = QHBoxLayout()
        p_badge = QLabel(t.get("project_code", "General"))
        p_badge.setStyleSheet(f"background: #1e293b; color: {t.get('project_color', '#3b82f6')}; font-size: 11px; font-weight: 700; padding: 2px 6px; border-radius: 4px;")

        pri = t.get("priority", "Medium")
        pri_col = "#ef4444" if pri == "Urgent" else ("#f59e0b" if pri == "High" else "#3b82f6")
        pri_badge = QLabel(pri)
        pri_badge.setStyleSheet(f"color: {pri_col}; font-size: 11px; font-weight: 600;")

        top_row.addWidget(p_badge)
        top_row.addStretch()
        top_row.addWidget(pri_badge)
        c_layout.addLayout(top_row)

        # Title
        t_lbl = QLabel(t.get("title"))
        t_lbl.setStyleSheet("font-size: 13px; font-weight: 600; color: #f8fafc;")
        t_lbl.setWordWrap(True)
        c_layout.addWidget(t_lbl)

        # Blocker notice if any
        if t.get("status") == "Blocked" and t.get("blocker_reason"):
            b_box = QLabel(f"⛔ {t.get('blocker_reason')}")
            b_box.setStyleSheet("color: #fca5a5; font-size: 11px; background: #450a0a; padding: 4px 6px; border-radius: 4px;")
            b_box.setWordWrap(True)
            c_layout.addWidget(b_box)

        # Footer row: Due date + Status Transitions
        bot_row = QHBoxLayout()
        due_lbl = QLabel(f"📅 {t.get('due_date', '')}")
        due_lbl.setStyleSheet("color: #94a3b8; font-size: 11px;")
        bot_row.addWidget(due_lbl)
        bot_row.addStretch()

        task_id = t.get("id")
        current_status = t.get("status")

        if current_status == "To Do":
            btn_next = QPushButton("Start →")
            btn_next.clicked.connect(lambda checked=False, tid=task_id: self._change_status(tid, "In Progress"))
        elif current_status == "In Progress":
            btn_next = QPushButton("Finish ✓")
            btn_next.clicked.connect(lambda checked=False, tid=task_id: self._change_status(tid, "Done"))
        elif current_status == "Blocked":
            btn_next = QPushButton("Unblock ↻")
            btn_next.clicked.connect(lambda checked=False, tid=task_id: self._change_status(tid, "In Progress"))
        else:
            btn_next = QPushButton("Reopen")
            btn_next.clicked.connect(lambda checked=False, tid=task_id: self._change_status(tid, "In Progress"))

        btn_next.setStyleSheet("""
            QPushButton {
                background: #334155;
                color: #f8fafc;
                font-size: 10px;
                font-weight: 600;
                padding: 3px 6px;
                border-radius: 4px;
                border: none;
            }
            QPushButton:hover { background: #475569; }
        """)
        bot_row.addWidget(btn_next)
        c_layout.addLayout(bot_row)

        return card

    def _render_table(self, tasks: List[Dict[str, Any]]) -> None:
        self.task_table.setRowCount(len(tasks))
        for row, t in enumerate(tasks):
            # Status
            status_item = QTableWidgetItem(t.get("status"))
            self.task_table.setItem(row, 0, status_item)

            # Title
            title_item = QTableWidgetItem(t.get("title"))
            self.task_table.setItem(row, 1, title_item)

            # Project
            p_item = QTableWidgetItem(t.get("project_code", ""))
            self.task_table.setItem(row, 2, p_item)

            # Priority
            pri_item = QTableWidgetItem(t.get("priority", ""))
            self.task_table.setItem(row, 3, pri_item)

            # Due Date
            due_item = QTableWidgetItem(t.get("due_date", ""))
            self.task_table.setItem(row, 4, due_item)

            # Hours
            hours_str = f"{t.get('actual_hours', 0.0):.1f} / {t.get('estimated_hours', 0.0):.1f}h"
            hours_item = QTableWidgetItem(hours_str)
            self.task_table.setItem(row, 5, hours_item)

            # Blocker Reason
            blocker_item = QTableWidgetItem(t.get("blocker_reason") or "None")
            self.task_table.setItem(row, 6, blocker_item)

            # Action button
            task_id = t.get("id")
            btn_edit = QPushButton("Edit")
            btn_edit.setStyleSheet("background: #334155; color: #ffffff; padding: 2px 6px; border-radius: 4px;")
            btn_edit.clicked.connect(lambda checked=False, tid=task_id: self.show_edit_task_dialog(tid))
            self.task_table.setCellWidget(row, 7, btn_edit)

    def _change_status(self, task_id: int, new_status: str) -> None:
        self.db.update_task_status(task_id, new_status)
        self.refresh()

    def show_add_task_dialog(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("Create Office Task")
        dlg.resize(460, 460)
        form = QFormLayout(dlg)

        proj_combo = QComboBox()
        for p in self.db.get_projects():
            proj_combo.addItem(f"[{p.get('code')}] {p.get('name')}", p.get("id"))

        title_in = QLineEdit()
        desc_in = QTextEdit()
        desc_in.setMaximumHeight(70)

        status_combo = QComboBox()
        status_combo.addItems(["To Do", "In Progress", "Blocked", "Done"])

        pri_combo = QComboBox()
        pri_combo.addItems(["Medium", "High", "Urgent", "Low"])

        due_in = QLineEdit(date.today().isoformat())
        est_hours = QDoubleSpinBox()
        est_hours.setValue(4.0)
        est_hours.setSuffix(" hours")

        blocker_in = QLineEdit()
        blocker_in.setPlaceholderText("Optional: Note why this task is blocked")

        form.addRow("Project *:", proj_combo)
        form.addRow("Task Title *:", title_in)
        form.addRow("Description:", desc_in)
        form.addRow("Status:", status_combo)
        form.addRow("Priority:", pri_combo)
        form.addRow("Due Date (YYYY-MM-DD):", due_in)
        form.addRow("Estimated Hours:", est_hours)
        form.addRow("Blocker Reason (if any):", blocker_in)

        btn_save = QPushButton("Save Task")
        btn_save.setProperty("class", "PrimaryBtn")

        def save():
            t_title = title_in.text().strip()
            if not t_title:
                QMessageBox.warning(dlg, "Error", "Task Title is required!")
                return
            self.db.add_task({
                "project_id": proj_combo.currentData(),
                "title": t_title,
                "description": desc_in.toPlainText().strip(),
                "status": status_combo.currentText(),
                "priority": pri_combo.currentText(),
                "category": "Development",
                "due_date": due_in.text().strip(),
                "estimated_hours": est_hours.value(),
                "actual_hours": 0.0,
                "blocker_reason": blocker_in.text().strip(),
                "assigned_to": "Arun K."
            })
            dlg.accept()
            self.refresh()

        btn_save.clicked.connect(save)
        form.addRow(btn_save)
        dlg.exec()

    def show_edit_task_dialog(self, task_id: int) -> None:
        t = self.db.get_task_by_id(task_id)
        if not t:
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Edit Task")
        dlg.resize(460, 460)
        form = QFormLayout(dlg)

        title_in = QLineEdit(t.get("title"))
        desc_in = QTextEdit()
        desc_in.setPlainText(t.get("description", ""))
        desc_in.setMaximumHeight(70)

        status_combo = QComboBox()
        status_combo.addItems(["To Do", "In Progress", "Blocked", "Done"])
        status_combo.setCurrentText(t.get("status", "To Do"))

        pri_combo = QComboBox()
        pri_combo.addItems(["Medium", "High", "Urgent", "Low"])
        pri_combo.setCurrentText(t.get("priority", "Medium"))

        due_in = QLineEdit(t.get("due_date", ""))
        actual_hours = QDoubleSpinBox()
        actual_hours.setValue(float(t.get("actual_hours", 0.0)))
        actual_hours.setSuffix(" hours")

        blocker_in = QLineEdit(t.get("blocker_reason", ""))

        form.addRow("Title:", title_in)
        form.addRow("Description:", desc_in)
        form.addRow("Status:", status_combo)
        form.addRow("Priority:", pri_combo)
        form.addRow("Due Date:", due_in)
        form.addRow("Actual Hours Logged:", actual_hours)
        form.addRow("Blocker Reason:", blocker_in)

        btn_save = QPushButton("Update Task")
        btn_save.setProperty("class", "PrimaryBtn")

        def save():
            self.db.update_task(task_id, {
                "title": title_in.text().strip(),
                "description": desc_in.toPlainText().strip(),
                "status": status_combo.currentText(),
                "priority": pri_combo.currentText(),
                "due_date": due_in.text().strip(),
                "actual_hours": actual_hours.value(),
                "blocker_reason": blocker_in.text().strip()
            })
            dlg.accept()
            self.refresh()

        btn_save.clicked.connect(save)
        form.addRow(btn_save)
        dlg.exec()
