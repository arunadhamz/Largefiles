"""Dashboard View with modern KPIs, active projects overview, and daily priority checklist."""

from __future__ import annotations
from datetime import date
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QScrollArea, QGridLayout, QProgressBar
)

from app.database import DatabaseManager


class DashboardView(QWidget):
    """Executive Dashboard with KPI metrics, urgent tasks, and quick actions."""

    # Navigation signals to main window
    navigate_requested = Signal(str)  # "projects", "tasks", "daily", "meetings", "reports", "ppt"
    task_status_changed = Signal(int, str)

    def __init__(self, db: DatabaseManager, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.init_ui()

    def init_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 24, 24, 24)
        main_layout.setSpacing(20)

        # 1. Header & Title
        header_layout = QHBoxLayout()
        title_box = QVBoxLayout()
        page_title = QLabel("Executive Dashboard")
        page_title.setProperty("class", "PageTitle")
        page_title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")

        today_str = date.today().strftime("%A, %B %d, %Y")
        subtitle = QLabel(f"Daily Workflow & Multi-Project Command Center  •  {today_str}")
        subtitle.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(page_title)
        title_box.addWidget(subtitle)
        header_layout.addLayout(title_box)
        header_layout.addStretch()

        # Quick Action Buttons in Header
        btn_deck = QPushButton("📊 Generate Weekly PPT")
        btn_deck.setProperty("class", "PrimaryBtn")
        btn_deck.clicked.connect(lambda: self.navigate_requested.emit("ppt"))

        btn_report = QPushButton("📑 Weekly Report")
        btn_report.setProperty("class", "SecondaryBtn")
        btn_report.clicked.connect(lambda: self.navigate_requested.emit("reports"))

        btn_new_task = QPushButton("+ Add Task")
        btn_new_task.setProperty("class", "SuccessBtn")
        btn_new_task.clicked.connect(lambda: self.navigate_requested.emit("tasks"))

        header_layout.addWidget(btn_report)
        header_layout.addWidget(btn_deck)
        header_layout.addWidget(btn_new_task)
        main_layout.addLayout(header_layout)

        # 2. Scrollable Body
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background: transparent;")

        content_widget = QWidget()
        self.content_layout = QVBoxLayout(content_widget)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(20)

        # KPI Container
        self.kpi_layout = QHBoxLayout()
        self.content_layout.addLayout(self.kpi_layout)

        # Next Meeting Banner
        self.meeting_banner = QFrame()
        self.meeting_banner.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1e1b4b, stop:1 #312e81);
                border: 1px solid #4338ca;
                border-radius: 10px;
                padding: 16px;
            }
        """)
        self.meeting_banner_layout = QHBoxLayout(self.meeting_banner)
        self.content_layout.addWidget(self.meeting_banner)

        # Lower Split: Projects Grid (Left) + Today's Focus Tasks (Right)
        split_layout = QHBoxLayout()
        split_layout.setSpacing(20)

        # Left: Projects Health
        projects_container = QFrame()
        projects_container.setProperty("class", "Card")
        self.projects_layout = QVBoxLayout(projects_container)
        p_hdr = QLabel("Active Projects Health & Velocity")
        p_hdr.setStyleSheet("font-size: 16px; font-weight: 600; color: #f8fafc; margin-bottom: 8px;")
        self.projects_layout.addWidget(p_hdr)
        self.projects_cards_layout = QVBoxLayout()
        self.projects_layout.addLayout(self.projects_cards_layout)
        split_layout.addWidget(projects_container, 3)

        # Right: Urgent Focus & Daily Checklist
        tasks_container = QFrame()
        tasks_container.setProperty("class", "Card")
        self.tasks_layout = QVBoxLayout(tasks_container)
        t_hdr = QLabel("Today's Priority Focus Tasks")
        t_hdr.setStyleSheet("font-size: 16px; font-weight: 600; color: #f8fafc; margin-bottom: 8px;")
        self.tasks_layout.addWidget(t_hdr)
        self.tasks_list_layout = QVBoxLayout()
        self.tasks_layout.addLayout(self.tasks_list_layout)
        split_layout.addWidget(tasks_container, 2)

        self.content_layout.addLayout(split_layout)
        scroll.setWidget(content_widget)
        main_layout.addWidget(scroll)

        self.refresh()

    def refresh(self) -> None:
        """Reload all metrics and dynamic cards from the database."""
        metrics = self.db.get_dashboard_metrics()
        projects = self.db.get_projects()
        tasks = self.db.get_tasks()

        # 1. Populate KPI Cards
        self._clear_layout(self.kpi_layout)
        kpi_data = [
            ("Active Projects", str(metrics.get("active_projects", 0)), "#3b82f6", "📁"),
            ("Completed Tasks", str(metrics.get("completed_tasks", 0)), "#10b981", "✓"),
            ("In-Progress Work", str(metrics.get("in_progress_tasks", 0)), "#f59e0b", "⏳"),
            ("Active Blockers", str(metrics.get("blocked_tasks", 0)), "#ef4444", "⛔"),
            ("Hours Logged", f"{metrics.get('total_hours', 0.0):.1f}h", "#8b5cf6", "⏱"),
        ]

        for title, value, color, icon in kpi_data:
            card = QFrame()
            card.setStyleSheet(f"""
                QFrame {{
                    background-color: #1e293b;
                    border: 1px solid #334155;
                    border-radius: 10px;
                    padding: 16px;
                }}
                QFrame:hover {{
                    border-color: {color};
                }}
            """)
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(12, 12, 12, 12)
            card_layout.setSpacing(4)

            top_row = QHBoxLayout()
            icon_lbl = QLabel(icon)
            icon_lbl.setStyleSheet(f"font-size: 16px; color: {color};")
            title_lbl = QLabel(title)
            title_lbl.setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 500;")
            top_row.addWidget(icon_lbl)
            top_row.addWidget(title_lbl)
            top_row.addStretch()

            val_lbl = QLabel(value)
            val_lbl.setStyleSheet(f"font-size: 28px; font-weight: 700; color: {color};")

            card_layout.addLayout(top_row)
            card_layout.addWidget(val_lbl)
            self.kpi_layout.addWidget(card)

        # 2. Next Meeting Banner
        next_m = metrics.get("next_meeting")
        self._clear_layout(self.meeting_banner_layout)
        if next_m:
            m_icon = QLabel("📅")
            m_icon.setStyleSheet("font-size: 24px;")
            self.meeting_banner_layout.addWidget(m_icon)

            m_info = QVBoxLayout()
            m_title = QLabel(f"Next Meeting: {next_m.get('title')} ({next_m.get('meeting_type')})")
            m_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #ffffff;")
            m_meta = QLabel(f"Time: {next_m.get('meeting_date')}  |  Attendees: {next_m.get('attendees')}  |  Projects: {next_m.get('projects_involved', 'All')}")
            m_meta.setStyleSheet("color: #c7d2fe; font-size: 12px;")
            m_info.addWidget(m_title)
            m_info.addWidget(m_meta)
            self.meeting_banner_layout.addLayout(m_info)
            self.meeting_banner_layout.addStretch()

            btn_prep = QPushButton("🤖 AI Prep Docket")
            btn_prep.setProperty("class", "PrimaryBtn")
            btn_prep.clicked.connect(lambda: self.navigate_requested.emit("meetings"))
            self.meeting_banner_layout.addWidget(btn_prep)
            self.meeting_banner.setVisible(True)
        else:
            self.meeting_banner.setVisible(False)

        # 3. Populate Projects Cards
        self._clear_layout(self.projects_cards_layout)
        for p in projects[:3]:
            total = p.get("total_tasks", 0)
            done = p.get("done_tasks", 0)
            pct = int((done / total * 100)) if total > 0 else 0

            p_card = QFrame()
            p_card.setStyleSheet("""
                QFrame {
                    background-color: #0f172a;
                    border: 1px solid #334155;
                    border-radius: 8px;
                    padding: 12px;
                }
            """)
            pc_layout = QVBoxLayout(p_card)
            pc_layout.setContentsMargins(10, 10, 10, 10)

            # Top row: Code + Name + Health
            row1 = QHBoxLayout()
            code_lbl = QLabel(f"[{p.get('code')}] {p.get('name')}")
            code_lbl.setStyleSheet("font-weight: 600; font-size: 14px; color: #f8fafc;")

            health = p.get("health", "On Track")
            health_color = "#10b981" if health == "On Track" else ("#ef4444" if health == "Delayed" else "#f59e0b")
            health_lbl = QLabel(f"● {health}")
            health_lbl.setStyleSheet(f"color: {health_color}; font-weight: 600; font-size: 12px;")

            row1.addWidget(code_lbl)
            row1.addStretch()
            row1.addWidget(health_lbl)
            pc_layout.addLayout(row1)

            # Description
            desc_lbl = QLabel(p.get("description", ""))
            desc_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")
            desc_lbl.setWordWrap(True)
            pc_layout.addWidget(desc_lbl)

            # Progress Bar
            pbar_row = QHBoxLayout()
            pbar = QProgressBar()
            pbar.setValue(pct)
            pbar.setFixedHeight(8)
            pbar.setTextVisible(False)
            pbar.setStyleSheet(f"""
                QProgressBar {{
                    background: #1e293b;
                    border-radius: 4px;
                }}
                QProgressBar::chunk {{
                    background: {p.get('color', '#3b82f6')};
                    border-radius: 4px;
                }}
            """)
            pct_lbl = QLabel(f"{pct}% ({done}/{total} done)")
            pct_lbl.setStyleSheet("color: #94a3b8; font-size: 11px;")
            pbar_row.addWidget(pbar)
            pbar_row.addWidget(pct_lbl)
            pc_layout.addLayout(pbar_row)

            self.projects_cards_layout.addWidget(p_card)

        # 4. Populate Priority Tasks
        self._clear_layout(self.tasks_list_layout)
        priority_tasks = [t for t in tasks if t.get("status") in ("In Progress", "Blocked", "To Do")][:5]
        if not priority_tasks:
            empty_lbl = QLabel("No pending tasks! All caught up.")
            empty_lbl.setStyleSheet("color: #10b981; font-style: italic; padding: 20px;")
            self.tasks_list_layout.addWidget(empty_lbl)
        else:
            for t in priority_tasks:
                t_row = QFrame()
                t_row.setStyleSheet("""
                    QFrame {
                        background-color: #0f172a;
                        border: 1px solid #334155;
                        border-radius: 6px;
                        padding: 8px;
                    }
                """)
                tr_layout = QHBoxLayout(t_row)
                tr_layout.setContentsMargins(8, 6, 8, 6)

                status = t.get("status")
                stat_icon = "⛔" if status == "Blocked" else ("⏳" if status == "In Progress" else "•")
                stat_lbl = QLabel(stat_icon)
                tr_layout.addWidget(stat_lbl)

                t_title = QLabel(t.get("title"))
                t_title.setStyleSheet("font-weight: 500; font-size: 13px; color: #f8fafc;")
                t_title.setWordWrap(True)
                tr_layout.addWidget(t_title, 1)

                p_tag = QLabel(t.get("project_code", "General"))
                p_tag.setStyleSheet(f"background: #1e293b; color: {t.get('project_color', '#3b82f6')}; padding: 2px 6px; border-radius: 4px; font-size: 11px; font-weight: 600;")
                tr_layout.addWidget(p_tag)

                btn_done = QPushButton("Done")
                btn_done.setStyleSheet("""
                    QPushButton {
                        background: #059669;
                        color: #ffffff;
                        font-size: 11px;
                        font-weight: 600;
                        padding: 4px 8px;
                        border-radius: 4px;
                        border: none;
                    }
                    QPushButton:hover { background: #10b981; }
                """)
                task_id = t.get("id")
                btn_done.clicked.connect(lambda checked=False, tid=task_id: self._mark_task_done(tid))
                tr_layout.addWidget(btn_done)

                self.tasks_list_layout.addWidget(t_row)

        self.tasks_list_layout.addStretch()

    def _mark_task_done(self, task_id: int) -> None:
        self.db.update_task_status(task_id, "Done")
        self.refresh()

    def _clear_layout(self, layout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
            elif item.layout():
                self._clear_layout(item.layout())
