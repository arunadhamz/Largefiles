"""Main Application Window for WorkAssist Pro.
Coordinates the sidebar navigation and view stack.
"""

from __future__ import annotations
from typing import Optional
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QFrame,
    QPushButton, QStackedWidget, QButtonGroup
)
from PySide6.QtGui import QIcon

from app.database import DatabaseManager
from app.ai_service import AIService
from app.styles import MODERN_DARK_QSS
from app.ui.dashboard_view import DashboardView
from app.ui.projects_view import ProjectsView
from app.ui.tasks_view import TasksView
from app.ui.daily_workflow_view import DailyWorkflowView
from app.ui.meetings_view import MeetingsView
from app.ui.reports_view import ReportsView
from app.ui.ppt_view import PPTView
from app.ui.calendar_view import CalendarView
from app.ui.assistant_view import AssistantView
from app.ui.settings_view import SettingsView


class MainWindow(QMainWindow):
    """Main application window featuring modern sidebar navigation and stacked views."""

    def __init__(self, db: DatabaseManager, ai_service: AIService, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.ai = ai_service

        self.setWindowTitle("WorkAssist Pro — Multi-Project Task & Executive Meeting Suite")
        self.resize(1280, 820)
        self.setMinimumSize(1024, 680)

        self.init_ui()
        self.setStyleSheet(MODERN_DARK_QSS)

    def init_ui(self) -> None:
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        root_layout = QHBoxLayout(central_widget)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # 1. Modern Sidebar
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(14, 20, 14, 20)
        sidebar_layout.setSpacing(6)

        # App Brand Header
        brand_row = QHBoxLayout()
        logo_lbl = QLabel("⚡")
        logo_lbl.setStyleSheet("font-size: 22px;")
        brand_lbl = QLabel("WorkAssist Pro")
        brand_lbl.setStyleSheet("font-size: 16px; font-weight: 700; color: #f8fafc;")
        brand_row.addWidget(logo_lbl)
        brand_row.addWidget(brand_lbl)
        brand_row.addStretch()
        sidebar_layout.addLayout(brand_row)

        brand_sub = QLabel("Executive Office Copilot")
        brand_sub.setStyleSheet("font-size: 11px; color: #818cf8; margin-left: 28px; margin-bottom: 16px;")
        sidebar_layout.addWidget(brand_sub)

        # Navigation Buttons
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        nav_items = [
            ("📊  Dashboard", 0, "dashboard"),
            ("📁  Projects Portfolio", 1, "projects"),
            ("📋  Tasks & Kanban", 2, "tasks"),
            ("📝  Daily Workflow", 3, "daily"),
            ("👥  Meeting Assistant", 4, "meetings"),
            ("📑  Weekly Reports", 5, "reports"),
            ("📊  Presentation (PPT)", 6, "ppt"),
            ("📅  Calendar (CAL)", 7, "calendar"),
            ("🤖  Claude AI Chat", 8, "assistant"),
            ("⚙️  Settings", 9, "settings"),
        ]

        self.nav_buttons = {}
        for text, index, key in nav_items:
            btn = QPushButton(text)
            btn.setProperty("class", "NavButton")
            btn.setCheckable(True)
            self.nav_group.addButton(btn, index)
            sidebar_layout.addWidget(btn)
            self.nav_buttons[key] = btn

        self.nav_group.idClicked.connect(self.on_nav_clicked)

        sidebar_layout.addStretch()

        # Sidebar Footer: User Profile Pill
        profile_frame = QFrame()
        profile_frame.setStyleSheet("""
            QFrame {
                background: #0f172a;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        pf_layout = QHBoxLayout(profile_frame)
        pf_layout.setContentsMargins(6, 4, 6, 4)
        avatar = QLabel("👤")
        avatar.setStyleSheet("font-size: 18px;")
        user_info = QVBoxLayout()
        u_name = QLabel("Arun K.")
        u_name.setStyleSheet("font-weight: 700; font-size: 12px; color: #f8fafc;")
        u_role = QLabel("Lead Engineer")
        u_role.setStyleSheet("color: #94a3b8; font-size: 10px;")
        user_info.addWidget(u_name)
        user_info.addWidget(u_role)
        pf_layout.addWidget(avatar)
        pf_layout.addLayout(user_info)
        sidebar_layout.addWidget(profile_frame)

        root_layout.addWidget(sidebar)

        # 2. Main Stacked Views
        self.stack = QStackedWidget()

        # Instantiate Views
        self.dashboard_view = DashboardView(self.db)
        self.dashboard_view.navigate_requested.connect(self.navigate_to_key)

        self.projects_view = ProjectsView(self.db)
        self.tasks_view = TasksView(self.db)
        self.daily_view = DailyWorkflowView(self.db, self.ai)
        self.meetings_view = MeetingsView(self.db, self.ai)
        self.reports_view = ReportsView(self.db, self.ai)
        self.ppt_view = PPTView(self.db)
        self.calendar_view = CalendarView(self.db)
        self.assistant_view = AssistantView(self.db, self.ai)
        self.settings_view = SettingsView(self.db, self.ai)

        self.stack.addWidget(self.dashboard_view)    # 0
        self.stack.addWidget(self.projects_view)     # 1
        self.stack.addWidget(self.tasks_view)        # 2
        self.stack.addWidget(self.daily_view)        # 3
        self.stack.addWidget(self.meetings_view)     # 4
        self.stack.addWidget(self.reports_view)      # 5
        self.stack.addWidget(self.ppt_view)          # 6
        self.stack.addWidget(self.calendar_view)     # 7
        self.stack.addWidget(self.assistant_view)    # 8
        self.stack.addWidget(self.settings_view)     # 9

        root_layout.addWidget(self.stack, 1)

        # Default select Dashboard
        if "dashboard" in self.nav_buttons:
            self.nav_buttons["dashboard"].setChecked(True)

    def on_nav_clicked(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        current_widget = self.stack.currentWidget()
        if hasattr(current_widget, "refresh"):
            current_widget.refresh()

    def navigate_to_key(self, key: str) -> None:
        if key in self.nav_buttons:
            self.nav_buttons[key].setChecked(True)
            btn = self.nav_buttons[key]
            idx = self.nav_group.id(btn)
            self.on_nav_clicked(idx)
