"""Calendar (.ics / CAL) Schedule and Export View."""

from __future__ import annotations
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QScrollArea, QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView
)

from app.database import DatabaseManager
from app.calendar_generator import CalendarGenerator


class CalendarView(QWidget):
    """Calendar agenda view with RFC 5545 iCalendar (.ics) export capability."""

    def __init__(self, db: DatabaseManager, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(18)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Office Schedule & Calendar (CAL) Hub")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        sub = QLabel("Synchronize meetings, sprint deadlines, and action items with external calendar suites")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        btn_export = QPushButton("📅 Extract & Download Calendar (.ics)")
        btn_export.setProperty("class", "PrimaryBtn")
        btn_export.setStyleSheet("""
            QPushButton {
                background: #059669;
                font-size: 14px;
                padding: 10px 20px;
                font-weight: 700;
                border-radius: 8px;
            }
            QPushButton:hover { background: #10b981; }
        """)
        btn_export.clicked.connect(self.export_calendar)
        hdr.addWidget(btn_export)
        layout.addLayout(hdr)

        # Info Banner
        info_frame = QFrame()
        info_frame.setStyleSheet("""
            QFrame {
                background: #1e293b;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 12px;
            }
        """)
        if_layout = QHBoxLayout(info_frame)
        info_lbl = QLabel(
            "💡 <b>Tip:</b> Downloading the <b>.ics (CAL) file</b> allows you to double-click and instantly add all "
            "office meetings and task deadlines into <b>Google Calendar, Microsoft Outlook, Apple Calendar, or Thunderbird</b>."
        )
        info_lbl.setStyleSheet("color: #cbd5e1; font-size: 13px;")
        if_layout.addWidget(info_lbl)
        layout.addWidget(info_frame)

        # Events Table
        table_hdr = QLabel("Upcoming Scheduled Events & Task Milestones:")
        table_hdr.setStyleSheet("font-size: 15px; font-weight: 600; color: #f8fafc;")
        layout.addWidget(table_hdr)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Type", "Date / Time", "Event / Task Summary", "Project", "Status"])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.refresh()

    def refresh(self) -> None:
        meetings = self.db.get_meetings()
        tasks = [t for t in self.db.get_tasks() if t.get("due_date") and t.get("status") != "Done"]

        total_rows = len(meetings) + len(tasks)
        self.table.setRowCount(total_rows)

        row = 0
        # Add Meetings
        for m in meetings:
            type_item = QTableWidgetItem("📅 Meeting")
            self.table.setItem(row, 0, type_item)

            date_item = QTableWidgetItem(m.get("meeting_date", ""))
            self.table.setItem(row, 1, date_item)

            title_item = QTableWidgetItem(f"{m.get('title')} ({m.get('meeting_type')})")
            self.table.setItem(row, 2, title_item)

            proj_item = QTableWidgetItem(m.get("projects_involved", "General"))
            self.table.setItem(row, 3, proj_item)

            stat_item = QTableWidgetItem(m.get("status", "Scheduled"))
            self.table.setItem(row, 4, stat_item)
            row += 1

        # Add Task Deadlines
        for t in tasks:
            type_item = QTableWidgetItem("⏳ Task Due")
            self.table.setItem(row, 0, type_item)

            date_item = QTableWidgetItem(t.get("due_date", ""))
            self.table.setItem(row, 1, date_item)

            title_item = QTableWidgetItem(f"[DEADLINE] {t.get('title')}")
            self.table.setItem(row, 2, title_item)

            proj_item = QTableWidgetItem(t.get("project_code", "General"))
            self.table.setItem(row, 3, proj_item)

            stat_item = QTableWidgetItem(t.get("status", "To Do"))
            self.table.setItem(row, 4, stat_item)
            row += 1

    def export_calendar(self) -> None:
        meetings = self.db.get_meetings()
        tasks = self.db.get_tasks()

        gen = CalendarGenerator()
        path = gen.export_calendar(meetings, tasks)

        QMessageBox.information(
            self,
            "Calendar (.ics) Exported",
            f"Calendar file successfully generated:\n\n{path}\n\n"
            "You can now import this .ics file into Google Calendar, Outlook, or Thunderbird!"
        )
