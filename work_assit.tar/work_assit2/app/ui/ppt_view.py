"""PowerPoint (.pptx) Presentation Preparation and Extraction View."""

from __future__ import annotations
import os
import subprocess
import sys
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QLineEdit, QComboBox, QCheckBox, QScrollArea, QMessageBox
)

from app.database import DatabaseManager
from app.ppt_generator import PPTGenerator


class PPTView(QWidget):
    """Weekly meeting presentation preparation, slide configuration, and .pptx download."""

    def __init__(self, db: DatabaseManager, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.generated_path: Optional[Path] = None
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(18)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Executive Presentation (PPT) Preparation")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        sub = QLabel("One-click PowerPoint slide deck generator for weekly stakeholder syncs and project reviews")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        btn_gen = QPushButton("📊 Extract & Download PPT (.pptx)")
        btn_gen.setProperty("class", "PrimaryBtn")
        btn_gen.setStyleSheet("""
            QPushButton {
                background: #4f46e5;
                font-size: 14px;
                padding: 10px 20px;
                font-weight: 700;
                border-radius: 8px;
            }
            QPushButton:hover { background: #6366f1; }
        """)
        btn_gen.clicked.connect(self.generate_pptx)
        hdr.addWidget(btn_gen)
        layout.addLayout(hdr)

        # Settings Card
        settings_frame = QFrame()
        settings_frame.setProperty("class", "Card")
        sf_layout = QVBoxLayout(settings_frame)
        sf_layout.setContentsMargins(16, 16, 16, 16)
        sf_layout.setSpacing(12)

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Presentation Title:"))
        self.title_in = QLineEdit("Weekly Executive Delivery & Multi-Project Review")
        row1.addWidget(self.title_in, 1)

        row1.addWidget(QLabel("Slide Theme:"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Modern Executive Navy", "Dark Slate Gradient", "Corporate Blue"])
        row1.addWidget(self.theme_combo)
        sf_layout.addLayout(row1)

        # Checkboxes
        chk_row = QHBoxLayout()
        self.chk_metrics = QCheckBox("Executive KPI Metrics Slide")
        self.chk_metrics.setChecked(True)
        self.chk_projects = QCheckBox("Dedicated Per-Project Slides")
        self.chk_projects.setChecked(True)
        self.chk_blockers = QCheckBox("Blockers & Risk Escalation Slide")
        self.chk_blockers.setChecked(True)
        self.chk_actions = QCheckBox("Meeting Action Items Slide")
        self.chk_actions.setChecked(True)

        chk_row.addWidget(self.chk_metrics)
        chk_row.addWidget(self.chk_projects)
        chk_row.addWidget(self.chk_blockers)
        chk_row.addWidget(self.chk_actions)
        chk_row.addStretch()
        sf_layout.addLayout(chk_row)

        layout.addWidget(settings_frame)

        # Slide Outline / Deck Preview
        preview_hdr = QLabel("Slide Deck Structure Preview (Automatic Data Mapping):")
        preview_hdr.setStyleSheet("font-size: 15px; font-weight: 600; color: #f8fafc;")
        layout.addWidget(preview_hdr)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background: transparent;")

        self.slides_content = QWidget()
        self.slides_layout = QVBoxLayout(self.slides_content)
        self.slides_layout.setContentsMargins(0, 0, 0, 0)
        self.slides_layout.setSpacing(12)

        scroll.setWidget(self.slides_content)
        layout.addWidget(scroll)

        self.refresh_preview()

    def refresh_preview(self) -> None:
        while self.slides_layout.count():
            item = self.slides_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        projects = self.db.get_projects()
        tasks = self.db.get_tasks()
        today_formatted = date.today().strftime("%B %d, %Y")

        slides_data = [
            ("Slide 1: Title & Meeting Header", "Weekly Executive Review", f"Lead Engineer  |  {today_formatted}  |  Platform: WorkAssist Pro", "#3b82f6"),
            ("Slide 2: Executive Health & Metrics Dashboard", "High-level Delivery Velocity", f"Active Projects: {len(projects)}  |  Completed Tasks: {len([t for t in tasks if t.get('status')=='Done'])}  |  Blockers: {len([t for t in tasks if t.get('status')=='Blocked'])}", "#10b981"),
        ]

        for p in projects[:3]:
            done_cnt = len([t for t in tasks if t.get("project_id") == p.get("id") and t.get("status") == "Done"])
            slides_data.append((
                f"Slide: Project Spotlight — [{p.get('code')}] {p.get('name')}",
                f"Health: {p.get('health')}  |  Priority: {p.get('priority')}  |  Lead: {p.get('lead_name')}",
                f"Accomplishments Completed ({done_cnt})  •  Active Tasks in Pipeline  •  Milestones",
                p.get("color", "#8b5cf6")
            ))

        slides_data.append(("Slide: Technical Blockers & Risk Escalation", "Dependencies & Impediments", "Highlights pending IAM credentials and external dependency roadblocks with mitigation strategy", "#ef4444"))
        slides_data.append(("Slide: Next Week Strategic Priorities", "Upcoming Sprint Deliverables", "Outlines immediate focus areas, deliverables, and team responsibilities for the upcoming week", "#f59e0b"))

        for slide_title, subtitle, desc, col in slides_data:
            frame = QFrame()
            frame.setStyleSheet(f"""
                QFrame {{
                    background: #1e293b;
                    border: 1px solid #334155;
                    border-left: 5px solid {col};
                    border-radius: 8px;
                    padding: 14px;
                }}
            """)
            f_layout = QVBoxLayout(frame)
            f_layout.setContentsMargins(12, 10, 12, 10)
            f_layout.setSpacing(4)

            t_lbl = QLabel(slide_title)
            t_lbl.setStyleSheet("font-size: 14px; font-weight: 700; color: #f8fafc;")

            s_lbl = QLabel(subtitle)
            s_lbl.setStyleSheet(f"color: {col}; font-weight: 600; font-size: 12px;")

            d_lbl = QLabel(desc)
            d_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")

            f_layout.addWidget(t_lbl)
            f_layout.addWidget(s_lbl)
            f_layout.addWidget(d_lbl)
            self.slides_layout.addWidget(frame)

        self.slides_layout.addStretch()

    def generate_pptx(self) -> None:
        projects = self.db.get_projects()
        tasks = self.db.get_tasks()
        meetings = self.db.get_meetings()

        gen = PPTGenerator()
        path = gen.generate_presentation(projects, tasks, meetings, theme=self.theme_combo.currentText())
        self.generated_path = path

        msg = QMessageBox(self)
        msg.setWindowTitle("Presentation Ready!")
        msg.setText(f"PowerPoint Presentation (.pptx) successfully generated!\n\nFile saved to:\n{path}")
        btn_open = msg.addButton("Open Presentation Folder", QMessageBox.ActionRole)
        msg.addButton(QMessageBox.Ok)
        msg.exec()

        if msg.clickedButton() == btn_open:
            self._open_folder(path.parent)

    def _open_folder(self, folder_path: Path) -> None:
        try:
            if sys.platform == "win32":
                os.startfile(folder_path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder_path)])
            else:
                subprocess.Popen(["xdg-open", str(folder_path)])
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open folder: {e}")
