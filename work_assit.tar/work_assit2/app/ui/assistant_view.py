"""Interactive Local Claude & AI Office Copilot Chat Interface."""

from __future__ import annotations
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QTextEdit, QScrollArea, QLineEdit
)

from app.database import DatabaseManager
from app.ai_service import AIService


class AIWorker(QThread):
    finished = Signal(str)

    def __init__(self, ai_service: AIService, prompt: str, db: DatabaseManager):
        super().__init__()
        self.ai = ai_service
        self.prompt = prompt
        self.db = db

    def run(self) -> None:
        projects = self.db.get_projects()
        tasks = self.db.get_tasks()
        meetings = self.db.get_meetings()
        logs = self.db.get_daily_logs(limit=5)
        response = self.ai.chat(self.prompt, projects, tasks, meetings, logs)
        self.finished.emit(response)


class AssistantView(QWidget):
    """Local Claude conversational office assistant loaded with real project context."""

    def __init__(self, db: DatabaseManager, ai_service: AIService, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.ai = ai_service
        self.worker: Optional[AIWorker] = None
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Local Claude Office Assistant")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        self.model_status_lbl = QLabel("Provider: Local Claude / Ollama  •  Full Multi-Project Context Aware")
        self.model_status_lbl.setStyleSheet("color: #818cf8; font-size: 13px; font-weight: 600;")
        title_box.addWidget(title)
        title_box.addWidget(self.model_status_lbl)
        hdr.addLayout(title_box)
        hdr.addStretch()

        btn_clear = QPushButton("Clear History")
        btn_clear.setProperty("class", "SecondaryBtn")
        btn_clear.clicked.connect(self.clear_chat)
        hdr.addWidget(btn_clear)
        layout.addLayout(hdr)

        # Quick Prompt Chips
        chips_frame = QFrame()
        chips_frame.setStyleSheet("""
            QFrame {
                background: #1e293b;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 6px;
            }
        """)
        chips_layout = QHBoxLayout(chips_frame)
        chips_layout.setContentsMargins(6, 4, 6, 4)
        chips_layout.setSpacing(8)

        quick_prompts = [
            ("🎯 Today's Priorities", "What are my highest priority tasks today across my projects?"),
            ("⛔ Summarize Blockers", "List all current project blockers and suggest immediate escalations."),
            ("✉️ Management Email", "Draft a concise weekly status email for leadership on our 3 projects."),
            ("📋 Meeting Talking Points", "Prepare my talking points for our upcoming executive sync.")
        ]

        for label, q_text in quick_prompts:
            btn = QPushButton(label)
            btn.setStyleSheet("""
                QPushButton {
                    background: #0f172a;
                    color: #cbd5e1;
                    border: 1px solid #334155;
                    border-radius: 14px;
                    padding: 4px 10px;
                    font-size: 11px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: #334155;
                    color: #ffffff;
                    border-color: #6366f1;
                }
            """)
            btn.clicked.connect(lambda checked=False, txt=q_text: self.send_message(txt))
            chips_layout.addWidget(btn)

        chips_layout.addStretch()
        layout.addWidget(chips_frame)

        # Chat Messages Scroll Area
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet("background: transparent;")

        self.chat_container = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_container)
        self.chat_layout.setContentsMargins(0, 0, 0, 0)
        self.chat_layout.setSpacing(12)

        self.scroll.setWidget(self.chat_container)
        layout.addWidget(self.scroll, 1)

        # Message Input Row
        input_row = QHBoxLayout()
        self.msg_input = QLineEdit()
        self.msg_input.setPlaceholderText("Ask Claude anything about your tasks, projects, meeting prep, or reports...")
        self.msg_input.setStyleSheet("""
            QLineEdit {
                background: #1e293b;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 12px 14px;
                color: #f8fafc;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #6366f1;
            }
        """)
        self.msg_input.returnPressed.connect(self.on_send_clicked)

        self.btn_send = QPushButton("Send →")
        self.btn_send.setProperty("class", "PrimaryBtn")
        self.btn_send.setStyleSheet("""
            QPushButton {
                background: #4f46e5;
                color: #ffffff;
                font-size: 13px;
                font-weight: 700;
                padding: 12px 20px;
                border-radius: 8px;
            }
            QPushButton:hover { background: #6366f1; }
        """)
        self.btn_send.clicked.connect(self.on_send_clicked)

        input_row.addWidget(self.msg_input, 1)
        input_row.addWidget(self.btn_send)
        layout.addLayout(input_row)

        self.load_history()

    def load_history(self) -> None:
        while self.chat_layout.count():
            item = self.chat_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        history = self.db.get_chat_history()
        if not history:
            # Add initial welcome bubble
            welcome = (
                "👋 Hello Arun! I am your **WorkAssist Pro Claude Assistant**.\n\n"
                "I have real-time visibility into your 3 active projects (**Cloud Modernization**, **Customer Portal 2.0**, and **AI Copilot**), "
                "daily standup logs, upcoming executive meetings, and task blockers.\n\n"
                "How can I assist you with your projects, reports, or meeting prep today?"
            )
            self._add_bubble("assistant", welcome)
        else:
            for msg in history:
                self._add_bubble(msg.get("role", "user"), msg.get("content", ""))

        self.chat_layout.addStretch()

    def on_send_clicked(self) -> None:
        text = self.msg_input.text().strip()
        if not text:
            return
        self.msg_input.clear()
        self.send_message(text)

    def send_message(self, text: str) -> None:
        self.db.add_chat_message("user", text)
        self._add_bubble("user", text)

        # Show typing indicator
        self.btn_send.setEnabled(False)
        self.btn_send.setText("Thinking...")

        self.worker = AIWorker(self.ai, text, self.db)
        self.worker.finished.connect(self.on_ai_response)
        self.worker.start()

    def on_ai_response(self, response: str) -> None:
        self.db.add_chat_message("assistant", response)
        self._add_bubble("assistant", response)
        self.btn_send.setEnabled(True)
        self.btn_send.setText("Send →")
        self._scroll_to_bottom()

    def _add_bubble(self, role: str, text: str) -> None:
        bubble = QFrame()
        is_user = role == "user"
        bg_col = "#312e81" if is_user else "#1e293b"
        border_col = "#4338ca" if is_user else "#334155"

        bubble.setStyleSheet(f"""
            QFrame {{
                background-color: {bg_col};
                border: 1px solid {border_col};
                border-radius: 10px;
                padding: 12px 16px;
            }}
        """)
        b_layout = QVBoxLayout(bubble)
        b_layout.setContentsMargins(10, 8, 10, 8)
        b_layout.setSpacing(4)

        header = QLabel("You" if is_user else "🤖 Claude Assistant")
        header.setStyleSheet("font-size: 11px; font-weight: 700; color: #a5b4fc;" if is_user else "font-size: 11px; font-weight: 700; color: #818cf8;")
        b_layout.addWidget(header)

        content = QLabel(text)
        content.setStyleSheet("color: #f8fafc; font-size: 13px; line-height: 1.5;")
        content.setWordWrap(True)
        content.setTextInteractionFlags(Qt.TextSelectableByMouse)
        b_layout.addWidget(content)

        # Wrap in row layout for left/right alignment
        row = QHBoxLayout()
        if is_user:
            row.addStretch()
            row.addWidget(bubble, 4)
        else:
            row.addWidget(bubble, 4)
            row.addStretch()

        self.chat_layout.insertLayout(self.chat_layout.count() - 1, row)
        self._scroll_to_bottom()

    def _scroll_to_bottom(self) -> None:
        self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum())

    def clear_chat(self) -> None:
        self.db.clear_chat_history()
        self.load_history()
