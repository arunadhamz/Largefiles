"""Projects Management View with detailed cards, health metrics, and task rosters."""

from __future__ import annotations
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QScrollArea, QDialog, QLineEdit, QTextEdit, QComboBox, QFormLayout,
    QMessageBox, QProgressBar
)

from app.database import DatabaseManager


class ProjectsView(QWidget):
    """Multi-project portfolio management and configuration."""

    project_selected = Signal(int)

    def __init__(self, db: DatabaseManager, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.selected_project_id: Optional[int] = None
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(20)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Enterprise Project Portfolio")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        sub = QLabel("Track multi-project execution health, strategic delivery dates, and ownership")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        btn_add = QPushButton("+ New Project")
        btn_add.setProperty("class", "PrimaryBtn")
        btn_add.clicked.connect(self.show_add_project_dialog)
        hdr.addWidget(btn_add)
        layout.addLayout(hdr)

        # Main Scrollable Area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background: transparent;")

        self.cards_container = QWidget()
        self.cards_layout = QVBoxLayout(self.cards_container)
        self.cards_layout.setContentsMargins(0, 0, 0, 0)
        self.cards_layout.setSpacing(16)

        scroll.setWidget(self.cards_container)
        layout.addWidget(scroll)

        self.refresh()

    def refresh(self) -> None:
        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        projects = self.db.get_projects()
        if not projects:
            empty = QLabel("No active projects. Click '+ New Project' above to create one.")
            empty.setStyleSheet("color: #94a3b8; font-style: italic; padding: 40px;")
            self.cards_layout.addWidget(empty)
            return

        for p in projects:
            card = self._build_project_card(p)
            self.cards_layout.addWidget(card)

        self.cards_layout.addStretch()

    def _build_project_card(self, p: Dict[str, Any]) -> QFrame:
        card = QFrame()
        card.setProperty("class", "Card")
        c_layout = QVBoxLayout(card)
        c_layout.setContentsMargins(18, 18, 18, 18)
        c_layout.setSpacing(12)

        # Top row: Code + Name + Status + Health
        r1 = QHBoxLayout()
        badge = QLabel(f" {p.get('code')} ")
        badge.setStyleSheet(f"""
            background-color: {p.get('color', '#3b82f6')};
            color: #ffffff;
            font-weight: 700;
            font-size: 13px;
            padding: 4px 10px;
            border-radius: 6px;
        """)
        name = QLabel(p.get("name"))
        name.setStyleSheet("font-size: 18px; font-weight: 700; color: #f8fafc;")

        r1.addWidget(badge)
        r1.addWidget(name)
        r1.addStretch()

        health = p.get("health", "On Track")
        h_color = "#10b981" if health == "On Track" else ("#ef4444" if health == "Delayed" else "#f59e0b")
        h_pill = QLabel(f"● {health}")
        h_pill.setStyleSheet(f"color: {h_color}; font-weight: 600; font-size: 13px; padding-right: 12px;")

        pri = p.get("priority", "High")
        pri_pill = QLabel(f"Priority: {pri}")
        pri_pill.setStyleSheet("color: #c7d2fe; font-size: 12px; background: #312e81; padding: 3px 8px; border-radius: 4px;")

        r1.addWidget(h_pill)
        r1.addWidget(pri_pill)
        c_layout.addLayout(r1)

        # Description
        desc = QLabel(p.get("description", ""))
        desc.setStyleSheet("color: #cbd5e1; font-size: 13px; line-height: 1.4;")
        desc.setWordWrap(True)
        c_layout.addWidget(desc)

        # Meta row: Lead, Dates, Task Counters
        total = p.get("total_tasks", 0)
        done = p.get("done_tasks", 0)
        in_prog = p.get("in_progress_tasks", 0)
        blocked = p.get("blocked_tasks", 0)
        pct = int((done / total * 100)) if total > 0 else 0

        meta_row = QHBoxLayout()
        lead_lbl = QLabel(f"👤 Lead: <b>{p.get('lead_name', 'Self')}</b>")
        lead_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")

        target_lbl = QLabel(f"🎯 Target: <b>{p.get('target_date', 'Ongoing')}</b>")
        target_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")

        counts_lbl = QLabel(f"Tasks: <b>{total}</b> (Done: <font color='#10b981'>{done}</font>, In-Progress: <font color='#f59e0b'>{in_prog}</font>, Blocked: <font color='#ef4444'>{blocked}</font>)")
        counts_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")

        meta_row.addWidget(lead_lbl)
        meta_row.addWidget(target_lbl)
        meta_row.addStretch()
        meta_row.addWidget(counts_lbl)
        c_layout.addLayout(meta_row)

        # Progress bar
        pbar_row = QHBoxLayout()
        pbar = QProgressBar()
        pbar.setValue(pct)
        pbar.setFixedHeight(8)
        pbar.setTextVisible(False)
        pbar.setStyleSheet(f"""
            QProgressBar {{
                background: #0f172a;
                border-radius: 4px;
            }}
            QProgressBar::chunk {{
                background: {p.get('color', '#3b82f6')};
                border-radius: 4px;
            }}
        """)
        pbar_pct = QLabel(f"{pct}%")
        pbar_pct.setStyleSheet(f"color: {p.get('color', '#3b82f6')}; font-weight: 700; font-size: 12px;")
        pbar_row.addWidget(pbar)
        pbar_row.addWidget(pbar_pct)
        c_layout.addLayout(pbar_row)

        # Bottom Action Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        btn_edit = QPushButton("Edit Project")
        btn_edit.setProperty("class", "SecondaryBtn")
        btn_edit.clicked.connect(lambda checked=False, pid=p.get("id"): self.show_edit_project_dialog(pid))

        btn_del = QPushButton("Delete")
        btn_del.setProperty("class", "DangerBtn")
        btn_del.clicked.connect(lambda checked=False, pid=p.get("id"): self._confirm_delete(pid))

        btn_row.addWidget(btn_edit)
        btn_row.addWidget(btn_del)
        c_layout.addLayout(btn_row)

        return card

    def show_add_project_dialog(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("Create New Project")
        dlg.resize(480, 420)
        form = QFormLayout(dlg)

        name_in = QLineEdit()
        code_in = QLineEdit()
        desc_in = QTextEdit()
        desc_in.setMaximumHeight(80)
        lead_in = QLineEdit("Arun K.")
        target_in = QLineEdit("2026-12-31")

        color_combo = QComboBox()
        color_combo.addItems(["#3b82f6 (Blue)", "#10b981 (Emerald)", "#8b5cf6 (Purple)", "#f59e0b (Amber)", "#ec4899 (Pink)"])

        health_combo = QComboBox()
        health_combo.addItems(["On Track", "At Risk", "Delayed"])

        priority_combo = QComboBox()
        priority_combo.addItems(["High", "Medium", "Urgent", "Low"])

        form.addRow("Project Name *:", name_in)
        form.addRow("Project Code (e.g. CP2) *:", code_in)
        form.addRow("Description:", desc_in)
        form.addRow("Project Lead:", lead_in)
        form.addRow("Target Completion Date:", target_in)
        form.addRow("Color:", color_combo)
        form.addRow("Health Status:", health_combo)
        form.addRow("Priority:", priority_combo)

        btn_save = QPushButton("Create Project")
        btn_save.setProperty("class", "PrimaryBtn")

        def save():
            name = name_in.text().strip()
            code = code_in.text().strip().upper()
            if not name or not code:
                QMessageBox.warning(dlg, "Validation Error", "Name and Code are required!")
                return
            col = color_combo.currentText().split(" ")[0]
            self.db.add_project({
                "name": name,
                "code": code,
                "description": desc_in.toPlainText().strip(),
                "color": col,
                "status": "Active",
                "priority": priority_combo.currentText(),
                "health": health_combo.currentText(),
                "start_date": "2026-11-01",
                "target_date": target_in.text().strip(),
                "lead_name": lead_in.text().strip()
            })
            dlg.accept()
            self.refresh()

        btn_save.clicked.connect(save)
        form.addRow(btn_save)
        dlg.exec()

    def show_edit_project_dialog(self, project_id: int) -> None:
        p = self.db.get_project_by_id(project_id)
        if not p:
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Edit Project: {p.get('name')}")
        dlg.resize(480, 420)
        form = QFormLayout(dlg)

        name_in = QLineEdit(p.get("name"))
        code_in = QLineEdit(p.get("code"))
        desc_in = QTextEdit()
        desc_in.setPlainText(p.get("description", ""))
        desc_in.setMaximumHeight(80)
        lead_in = QLineEdit(p.get("lead_name", ""))
        target_in = QLineEdit(p.get("target_date", ""))

        health_combo = QComboBox()
        health_combo.addItems(["On Track", "At Risk", "Delayed"])
        health_combo.setCurrentText(p.get("health", "On Track"))

        priority_combo = QComboBox()
        priority_combo.addItems(["High", "Medium", "Urgent", "Low"])
        priority_combo.setCurrentText(p.get("priority", "High"))

        form.addRow("Project Name *:", name_in)
        form.addRow("Project Code *:", code_in)
        form.addRow("Description:", desc_in)
        form.addRow("Project Lead:", lead_in)
        form.addRow("Target Date:", target_in)
        form.addRow("Health Status:", health_combo)
        form.addRow("Priority:", priority_combo)

        btn_save = QPushButton("Save Changes")
        btn_save.setProperty("class", "PrimaryBtn")

        def save():
            self.db.update_project(project_id, {
                "name": name_in.text().strip(),
                "code": code_in.text().strip().upper(),
                "description": desc_in.toPlainText().strip(),
                "health": health_combo.currentText(),
                "priority": priority_combo.currentText(),
                "lead_name": lead_in.text().strip(),
                "target_date": target_in.text().strip()
            })
            dlg.accept()
            self.refresh()

        btn_save.clicked.connect(save)
        form.addRow(btn_save)
        dlg.exec()

    def _confirm_delete(self, project_id: int) -> None:
        res = QMessageBox.question(
            self,
            "Confirm Delete",
            "Are you sure you want to delete this project? All associated tasks will also be removed.",
            QMessageBox.Yes | QMessageBox.No
        )
        if res == QMessageBox.Yes:
            self.db.delete_project(project_id)
            self.refresh()
