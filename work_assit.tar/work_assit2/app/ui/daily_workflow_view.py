"""Daily Workflow Journal and Standup Log View."""

from __future__ import annotations
from datetime import date
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QTextEdit, QComboBox, QDoubleSpinBox, QScrollArea, QMessageBox
)

from app.database import DatabaseManager
from app.ai_service import AIService


class DailyWorkflowView(QWidget):
    """Daily Standup, workflow logs, and task journal."""

    def __init__(self, db: DatabaseManager, ai_service: AIService, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.ai = ai_service
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Daily Workflow & Standup Journal")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        today_str = date.today().strftime("%A, %B %d, %Y")
        sub = QLabel(f"Document accomplishments, align tomorrow's priorities, and escalate blockers • {today_str}")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        # Action buttons
        btn_polish = QPushButton("🤖 AI Enhance Standup")
        btn_polish.setProperty("class", "SecondaryBtn")
        btn_polish.clicked.connect(self.ai_polish_standup)

        btn_save = QPushButton("💾 Save Standup Log")
        btn_save.setProperty("class", "PrimaryBtn")
        btn_save.clicked.connect(self.save_log)

        hdr.addWidget(btn_polish)
        hdr.addWidget(btn_save)
        layout.addLayout(hdr)

        # Main Split: Left (Today's Editor) & Right (Past Logs Timeline)
        split = QHBoxLayout()
        split.setSpacing(18)

        # Left: Today's Editor
        editor_frame = QFrame()
        editor_frame.setProperty("class", "Card")
        e_layout = QVBoxLayout(editor_frame)
        e_layout.setContentsMargins(18, 18, 18, 18)
        e_layout.setSpacing(12)

        # Project & Hours row
        meta_row = QHBoxLayout()
        meta_row.addWidget(QLabel("Primary Project Focus:"))
        self.proj_combo = QComboBox()
        self.proj_combo.setMinimumWidth(200)
        meta_row.addWidget(self.proj_combo)
        meta_row.addStretch()

        meta_row.addWidget(QLabel("Hours Spent Today:"))
        self.hours_spin = QDoubleSpinBox()
        self.hours_spin.setValue(8.0)
        self.hours_spin.setRange(0.5, 24.0)
        self.hours_spin.setSingleStep(0.5)
        self.hours_spin.setSuffix(" hrs")
        meta_row.addWidget(self.hours_spin)
        e_layout.addLayout(meta_row)

        # Section 1: Completed Today
        e_layout.addWidget(QLabel("✓ Completed Today (What did you achieve?):"))
        self.completed_in = QTextEdit()
        self.completed_in.setPlaceholderText("• Finished EKS node group security group rules...\n• Tested Local Claude response pipeline in WorkAssist...")
        self.completed_in.setMinimumHeight(100)
        e_layout.addWidget(self.completed_in)

        # Section 2: Planned Tomorrow
        e_layout.addWidget(QLabel("🎯 Planned for Tomorrow (What is your target?):"))
        self.planned_in = QTextEdit()
        self.planned_in.setPlaceholderText("• Complete Calico network policy tests on staging cluster...\n• Finalize PowerPoint slide template for weekly sync...")
        self.planned_in.setMinimumHeight(100)
        e_layout.addWidget(self.planned_in)

        # Section 3: Blockers
        e_layout.addWidget(QLabel("⛔ Blockers & Impediments (What is slowing you down?):"))
        self.blockers_in = QTextEdit()
        self.blockers_in.setPlaceholderText("• None (or note pending approvals, credentials, external reviews)...")
        self.blockers_in.setMinimumHeight(70)
        e_layout.addWidget(self.blockers_in)

        split.addWidget(editor_frame, 3)

        # Right: Past Logs History
        history_frame = QFrame()
        history_frame.setProperty("class", "Card")
        h_layout = QVBoxLayout(history_frame)
        h_layout.setContentsMargins(16, 16, 16, 16)
        h_layout.addWidget(QLabel("Past Standup Logs"))

        hist_scroll = QScrollArea()
        hist_scroll.setWidgetResizable(True)
        hist_scroll.setFrameShape(QFrame.NoFrame)
        hist_scroll.setStyleSheet("background: transparent;")

        self.hist_content = QWidget()
        self.hist_layout = QVBoxLayout(self.hist_content)
        self.hist_layout.setContentsMargins(0, 0, 0, 0)
        self.hist_layout.setSpacing(10)

        hist_scroll.setWidget(self.hist_content)
        h_layout.addWidget(hist_scroll)
        split.addWidget(history_frame, 2)

        layout.addLayout(split)

        self.refresh()

    def refresh(self) -> None:
        # Populate projects
        self.proj_combo.clear()
        for p in self.db.get_projects():
            self.proj_combo.addItem(f"[{p.get('code')}] {p.get('name')}", p.get("id"))

        # Load today's log if existing
        today_str = date.today().isoformat()
        today_log = self.db.get_log_by_date(today_str)
        if today_log:
            self.completed_in.setPlainText(today_log.get("completed_today") or "")
            self.planned_in.setPlainText(today_log.get("planned_tomorrow") or "")
            self.blockers_in.setPlainText(today_log.get("blockers") or "")
            self.hours_spin.setValue(float(today_log.get("hours_spent", 8.0)))
            if today_log.get("project_id"):
                idx = self.proj_combo.findData(today_log.get("project_id"))
                if idx >= 0:
                    self.proj_combo.setCurrentIndex(idx)

        # Populate history
        while self.hist_layout.count():
            item = self.hist_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        logs = self.db.get_daily_logs(limit=15)
        for l in logs:
            card = QFrame()
            card.setStyleSheet("""
                QFrame {
                    background: #0f172a;
                    border: 1px solid #334155;
                    border-radius: 6px;
                    padding: 8px;
                }
            """)
            c_layout = QVBoxLayout(card)
            c_layout.setContentsMargins(8, 8, 8, 8)
            c_layout.setSpacing(4)

            top = QHBoxLayout()
            d_lbl = QLabel(f"📅 {l.get('log_date')}")
            d_lbl.setStyleSheet("font-weight: 700; color: #f8fafc; font-size: 12px;")
            p_lbl = QLabel(l.get("project_code", "General"))
            p_lbl.setStyleSheet(f"color: {l.get('project_color', '#3b82f6')}; font-weight: 600; font-size: 11px;")
            top.addWidget(d_lbl)
            top.addStretch()
            top.addWidget(p_lbl)
            c_layout.addLayout(top)

            if l.get("completed_today"):
                comp_lbl = QLabel(l.get("completed_today"))
                comp_lbl.setStyleSheet("color: #94a3b8; font-size: 11px;")
                comp_lbl.setWordWrap(True)
                c_layout.addWidget(comp_lbl)

            self.hist_layout.addWidget(card)

        self.hist_layout.addStretch()

    def save_log(self) -> None:
        today_str = date.today().isoformat()
        p_id = self.proj_combo.currentData()
        self.db.add_or_update_daily_log({
            "log_date": today_str,
            "project_id": p_id,
            "completed_today": self.completed_in.toPlainText().strip(),
            "planned_tomorrow": self.planned_in.toPlainText().strip(),
            "blockers": self.blockers_in.toPlainText().strip(),
            "hours_spent": self.hours_spin.value(),
            "notes": ""
        })
        QMessageBox.information(self, "Success", "Daily Standup Log saved successfully!")
        self.refresh()

    def ai_polish_standup(self) -> None:
        raw_text = f"""
Completed Today:
{self.completed_in.toPlainText()}

Planned Tomorrow:
{self.planned_in.toPlainText()}

Blockers:
{self.blockers_in.toPlainText()}
"""
        prompt = f"""
Please polish and professionally format this engineer's daily standup update into clean, crisp, executive bullet points:

{raw_text}

Provide:
1. Completed accomplishments (concise action verbs)
2. Tomorrow's focus targets
3. Blockers with clear escalation requirement
"""
        res = self.ai.complete(prompt, "You are an executive engineering manager editing standup notes.")
        if res:
            dlg = QMessageBox(self)
            dlg.setWindowTitle("AI Enhanced Standup")
            dlg.setText("Standup update enhanced by AI Copilot:")
            dlg.setDetailedText(res)
            dlg.exec()
