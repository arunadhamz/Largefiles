"""Weekly Report Generator with AI Synthesis and ODT/Markdown Extraction."""

from __future__ import annotations
import os
from datetime import date, timedelta
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QTextEdit, QComboBox, QFileDialog, QMessageBox, QSplitter
)
from PySide6.QtGui import QGuiApplication

from app.database import DatabaseManager
from app.ai_service import AIService
from app.odt_generator import ODTGenerator


class ReportsView(QWidget):
    """Weekly Executive Report synthesis and document generation."""

    def __init__(self, db: DatabaseManager, ai_service: AIService, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.ai = ai_service
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Weekly Executive Report Generator")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        sub = QLabel("Synthesize multi-project delivery, weekly accomplishments, and blocker mitigations into executive briefs")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        # Generate Button
        btn_gen = QPushButton("🤖 Generate Report with Claude AI")
        btn_gen.setProperty("class", "PrimaryBtn")
        btn_gen.clicked.connect(self.generate_weekly_report)
        hdr.addWidget(btn_gen)
        layout.addLayout(hdr)

        # Toolbar for Filters & Export Formats
        toolbar = QFrame()
        toolbar.setStyleSheet("""
            QFrame {
                background: #1e293b;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        tb_layout = QHBoxLayout(toolbar)
        tb_layout.setContentsMargins(10, 6, 10, 6)

        tb_layout.addWidget(QLabel("Reporting Period:"))
        self.period_combo = QComboBox()
        self.period_combo.addItems(["Current Week", "Last Week", "Bi-Weekly Review"])
        tb_layout.addWidget(self.period_combo)

        tb_layout.addStretch()

        # Export Buttons
        btn_odt = QPushButton("📄 Extract & Download ODT (.odt)")
        btn_odt.setProperty("class", "SuccessBtn")
        btn_odt.clicked.connect(self.export_odt)

        btn_copy = QPushButton("📋 Copy to Clipboard")
        btn_copy.setProperty("class", "SecondaryBtn")
        btn_copy.clicked.connect(self.copy_to_clipboard)

        btn_save = QPushButton("💾 Save to Archive")
        btn_save.setProperty("class", "SecondaryBtn")
        btn_save.clicked.connect(self.save_to_db)

        tb_layout.addWidget(btn_odt)
        tb_layout.addWidget(btn_copy)
        tb_layout.addWidget(btn_save)
        layout.addWidget(toolbar)

        # Report Preview Text Area
        self.report_editor = QTextEdit()
        self.report_editor.setStyleSheet("""
            QTextEdit {
                background-color: #0f172a;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 16px;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace;
                font-size: 13px;
                line-height: 1.5;
                color: #f8fafc;
            }
        """)
        self.report_editor.setPlaceholderText("Click 'Generate Report with Claude AI' above to synthesize your weekly report...")
        layout.addWidget(self.report_editor)

        # Generate initial draft on first view
        self.generate_weekly_report()

    def generate_weekly_report(self) -> None:
        projects = self.db.get_projects()
        tasks = self.db.get_tasks()
        logs = self.db.get_daily_logs(limit=10)

        report_content = self.ai.generate_weekly_report(projects, tasks, logs)
        self.report_editor.setPlainText(report_content)

    def export_odt(self) -> None:
        projects = self.db.get_projects()
        tasks = self.db.get_tasks()
        meetings = self.db.get_meetings()

        gen = ODTGenerator()
        path = gen.generate_odt_report(projects, tasks, meetings)

        QMessageBox.information(
            self,
            "ODT File Exported",
            f"Weekly Report successfully exported to OpenDocument Text format:\n\n{path}\n\nCompatible with LibreOffice Writer, Microsoft Word, and Google Docs."
        )

    def copy_to_clipboard(self) -> None:
        text = self.report_editor.toPlainText()
        if text:
            clipboard = QGuiApplication.clipboard()
            clipboard.setText(text)
            QMessageBox.information(self, "Copied", "Report text copied to system clipboard!")

    def save_to_db(self) -> None:
        text = self.report_editor.toPlainText().strip()
        if not text:
            return
        today_str = date.today().isoformat()
        self.db.add_report({
            "title": f"Weekly Executive Status Report - {today_str}",
            "report_type": "Weekly",
            "period_start": (date.today() - timedelta(days=7)).isoformat(),
            "period_end": today_str,
            "content_markdown": text,
            "summary": "Weekly multi-project synthesis"
        })
        QMessageBox.information(self, "Saved", "Report saved to local database archive!")
