"""Settings and Configuration View for WorkAssist Pro."""

from __future__ import annotations
from typing import Any, Dict, Optional
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QLineEdit, QComboBox, QFormLayout, QMessageBox
)

from app.config import load_config, save_config, DB_PATH
from app.ai_service import AIService
from app.database import DatabaseManager
from app.sample_data import seed_sample_data


class SettingsView(QWidget):
    """System preferences, Local Claude configuration, and database controls."""

    def __init__(self, db: DatabaseManager, ai_service: AIService, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.ai = ai_service
        self.config = load_config()
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(18)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("System Settings & AI Configuration")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        sub = QLabel("Configure Local Claude, Ollama endpoints, personal profile, and export defaults")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        btn_save = QPushButton("💾 Save All Settings")
        btn_save.setProperty("class", "PrimaryBtn")
        btn_save.clicked.connect(self.save_settings)
        hdr.addWidget(btn_save)
        layout.addLayout(hdr)

        # 1. AI Assistant Engine Section
        ai_frame = QFrame()
        ai_frame.setProperty("class", "Card")
        ai_layout = QVBoxLayout(ai_frame)
        ai_layout.setContentsMargins(16, 16, 16, 16)
        ai_layout.setSpacing(12)

        ai_hdr = QLabel("🤖 AI Intelligence Engine & Local Claude Provider")
        ai_hdr.setStyleSheet("font-size: 16px; font-weight: 600; color: #f8fafc;")
        ai_layout.addWidget(ai_hdr)

        ai_form = QFormLayout()

        self.provider_combo = QComboBox()
        self.provider_combo.addItem("Local Ollama (Local Claude / Open-weights)", "ollama")
        self.provider_combo.addItem("Anthropic Claude API (Cloud Claude 3.5 Sonnet)", "anthropic")
        self.provider_combo.addItem("OpenAI-Compatible Local Endpoint (LM Studio / vLLM)", "openai_compatible")
        self.provider_combo.addItem("Built-in Smart Offline Engine (No Network Required)", "offline")

        cur_prov = self.config.get("ai_provider", "ollama")
        idx = self.provider_combo.findData(cur_prov)
        if idx >= 0:
            self.provider_combo.setCurrentIndex(idx)
        self.provider_combo.currentIndexChanged.connect(self._toggle_provider_fields)

        self.ollama_url_in = QLineEdit(self.config.get("ollama_url", "http://localhost:11434"))
        self.ollama_model_in = QLineEdit(self.config.get("ollama_model", "claude-3-5-sonnet"))

        self.anthropic_key_in = QLineEdit(self.config.get("anthropic_api_key", ""))
        self.anthropic_key_in.setEchoMode(QLineEdit.Password)
        self.anthropic_key_in.setPlaceholderText("sk-ant-api...")

        self.anthropic_model_in = QLineEdit(self.config.get("anthropic_model", "claude-3-5-sonnet-20241022"))

        self.openai_url_in = QLineEdit(self.config.get("openai_base_url", "http://localhost:1234/v1"))
        self.openai_model_in = QLineEdit(self.config.get("openai_model", "local-model"))

        ai_form.addRow("Active AI Provider:", self.provider_combo)
        ai_form.addRow("Ollama Endpoint URL:", self.ollama_url_in)
        ai_form.addRow("Ollama Model Tag:", self.ollama_model_in)
        ai_form.addRow("Anthropic API Key:", self.anthropic_key_in)
        ai_form.addRow("Anthropic Model:", self.anthropic_model_in)
        ai_form.addRow("OpenAI Base URL:", self.openai_url_in)
        ai_form.addRow("OpenAI Model Name:", self.openai_model_in)

        ai_layout.addLayout(ai_form)

        # Connection Test Row
        test_row = QHBoxLayout()
        btn_test = QPushButton("⚡ Test AI Connection")
        btn_test.setProperty("class", "SecondaryBtn")
        btn_test.clicked.connect(self.test_ai_connection)
        self.test_result_lbl = QLabel("")
        self.test_result_lbl.setStyleSheet("font-size: 12px; font-weight: 600;")
        test_row.addWidget(btn_test)
        test_row.addWidget(self.test_result_lbl)
        test_row.addStretch()
        ai_layout.addLayout(test_row)

        layout.addWidget(ai_frame)

        # 2. User Profile Section
        user_frame = QFrame()
        user_frame.setProperty("class", "Card")
        uf_layout = QVBoxLayout(user_frame)
        uf_layout.setContentsMargins(16, 16, 16, 16)

        u_hdr = QLabel("👤 User Profile & Presentation Signature")
        u_hdr.setStyleSheet("font-size: 16px; font-weight: 600; color: #f8fafc; margin-bottom: 8px;")
        uf_layout.addWidget(u_hdr)

        u_form = QFormLayout()
        self.user_name_in = QLineEdit(self.config.get("user_name", "Arun K."))
        self.user_title_in = QLineEdit(self.config.get("user_title", "Lead Engineer"))
        u_form.addRow("Full Name:", self.user_name_in)
        u_form.addRow("Job Title / Role:", self.user_title_in)
        uf_layout.addLayout(u_form)
        layout.addWidget(user_frame)

        # 3. Database & Storage Controls
        db_frame = QFrame()
        db_frame.setProperty("class", "Card")
        df_layout = QVBoxLayout(db_frame)
        df_layout.setContentsMargins(16, 16, 16, 16)

        db_hdr = QLabel("📁 Database & Storage Controls")
        db_hdr.setStyleSheet("font-size: 16px; font-weight: 600; color: #f8fafc;")
        df_layout.addWidget(db_hdr)

        path_lbl = QLabel(f"Database File: <font color='#818cf8'>{DB_PATH}</font>")
        path_lbl.setStyleSheet("font-size: 12px; color: #94a3b8;")
        df_layout.addWidget(path_lbl)

        btn_seed = QPushButton("🔄 Re-Seed Clean Demo Data (3 Projects & Meetings)")
        btn_seed.setProperty("class", "SecondaryBtn")
        btn_seed.clicked.connect(self.reseed_data)
        df_layout.addWidget(btn_seed)
        layout.addWidget(db_frame)

        layout.addStretch()
        self._toggle_provider_fields()

    def _toggle_provider_fields(self) -> None:
        prov = self.provider_combo.currentData()
        is_ollama = prov == "ollama"
        is_anthropic = prov == "anthropic"
        is_openai = prov == "openai_compatible"

        self.ollama_url_in.setEnabled(is_ollama)
        self.ollama_model_in.setEnabled(is_ollama)
        self.anthropic_key_in.setEnabled(is_anthropic)
        self.anthropic_model_in.setEnabled(is_anthropic)
        self.openai_url_in.setEnabled(is_openai)
        self.openai_model_in.setEnabled(is_openai)

    def test_ai_connection(self) -> None:
        self.save_settings(silent=True)
        ok, msg = self.ai.test_connection()
        col = "#10b981" if ok else "#ef4444"
        self.test_result_lbl.setStyleSheet(f"color: {col}; font-weight: 600; font-size: 12px;")
        self.test_result_lbl.setText(msg)

    def save_settings(self, silent: bool = False) -> None:
        cfg = {
            "ai_provider": self.provider_combo.currentData(),
            "ollama_url": self.ollama_url_in.text().strip(),
            "ollama_model": self.ollama_model_in.text().strip(),
            "anthropic_api_key": self.anthropic_key_in.text().strip(),
            "anthropic_model": self.anthropic_model_in.text().strip(),
            "openai_base_url": self.openai_url_in.text().strip(),
            "openai_model": self.openai_model_in.text().strip(),
            "user_name": self.user_name_in.text().strip(),
            "user_title": self.user_title_in.text().strip(),
        }
        save_config(cfg)
        self.ai.reload_config()
        if not silent:
            QMessageBox.information(self, "Settings Saved", "Preferences and AI configuration saved successfully!")

    def reseed_data(self) -> None:
        seed_sample_data(self.db)
        QMessageBox.information(self, "Data Reseeded", "Sample projects, tasks, and meetings verified in database!")
