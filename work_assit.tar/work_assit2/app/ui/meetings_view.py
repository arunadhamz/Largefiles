"""Comprehensive Meeting Assistant and MoM Data Manager."""

from __future__ import annotations
from datetime import datetime, date, timedelta
from typing import Any, Dict, List, Optional
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QScrollArea, QTabWidget, QTextEdit, QLineEdit, QComboBox, QSpinBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QDialog, QFormLayout,
    QMessageBox, QSplitter
)

from app.database import DatabaseManager
from app.ai_service import AIService
from app.odt_generator import ODTGenerator
from app.calendar_generator import CalendarGenerator


class MeetingsView(QWidget):
    """Full-featured meeting assistant with agenda prep, live MoM, and action items."""

    def __init__(self, db: DatabaseManager, ai_service: AIService, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.db = db
        self.ai = ai_service
        self.selected_meeting_id: Optional[int] = None
        self.init_ui()

    def init_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 24, 24, 24)
        main_layout.setSpacing(16)

        # Header
        hdr = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Executive Meeting Assistant")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #f8fafc;")
        sub = QLabel("Comprehensive meeting archives, live MoM records, AI talking points, and action items")
        sub.setStyleSheet("color: #94a3b8; font-size: 13px;")
        title_box.addWidget(title)
        title_box.addWidget(sub)
        hdr.addLayout(title_box)
        hdr.addStretch()

        btn_new_m = QPushButton("+ Schedule Meeting")
        btn_new_m.setProperty("class", "PrimaryBtn")
        btn_new_m.clicked.connect(self.show_new_meeting_dialog)
        hdr.addWidget(btn_new_m)
        main_layout.addLayout(hdr)

        # Splitter: Left (Meetings List) & Right (Active Meeting Work Area)
        splitter = QSplitter(Qt.Horizontal)
        splitter.setStyleSheet("""
            QSplitter::handle {
                background: #334155;
                width: 2px;
            }
        """)

        # Left Panel: Meetings List
        list_frame = QFrame()
        list_frame.setProperty("class", "Card")
        lf_layout = QVBoxLayout(list_frame)
        lf_layout.setContentsMargins(12, 12, 12, 12)
        lf_layout.addWidget(QLabel("Scheduled & Past Meetings"))

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background: transparent;")

        self.list_content = QWidget()
        self.list_layout = QVBoxLayout(self.list_content)
        self.list_layout.setContentsMargins(0, 0, 0, 0)
        self.list_layout.setSpacing(8)

        scroll.setWidget(self.list_content)
        lf_layout.addWidget(scroll)
        splitter.addWidget(list_frame)

        # Right Panel: Active Meeting Details & Tabs
        detail_frame = QFrame()
        detail_frame.setProperty("class", "Card")
        self.detail_layout = QVBoxLayout(detail_frame)
        self.detail_layout.setContentsMargins(16, 16, 16, 16)
        self.detail_layout.setSpacing(12)

        # Header of active meeting
        self.m_title_lbl = QLabel("Select a meeting from the left list")
        self.m_title_lbl.setStyleSheet("font-size: 18px; font-weight: 700; color: #f8fafc;")
        self.m_meta_lbl = QLabel("Time, attendees, and project details will appear here")
        self.m_meta_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")
        self.detail_layout.addWidget(self.m_title_lbl)
        self.detail_layout.addWidget(self.m_meta_lbl)

        # Tabs: 1. Agenda & MoM, 2. Action Items, 3. AI Copilot
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabBar::tab {
                background: #1e293b;
                color: #94a3b8;
                padding: 6px 16px;
                margin-right: 4px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                font-weight: 600;
            }
            QTabBar::tab:selected {
                background: #4f46e5;
                color: #ffffff;
            }
        """)

        # Tab 1: Agenda & MoM
        tab1 = QWidget()
        t1_layout = QVBoxLayout(tab1)
        t1_layout.addWidget(QLabel("Meeting Agenda & Discussion Topics:"))
        self.agenda_in = QTextEdit()
        self.agenda_in.setMaximumHeight(90)
        t1_layout.addWidget(self.agenda_in)

        t1_layout.addWidget(QLabel("Live Minutes of Meeting (MoM) / Notes:"))
        self.notes_in = QTextEdit()
        t1_layout.addWidget(self.notes_in)

        t1_layout.addWidget(QLabel("Key Decisions Agreed:"))
        self.decisions_in = QTextEdit()
        self.decisions_in.setMaximumHeight(80)
        t1_layout.addWidget(self.decisions_in)

        btn_save_notes = QPushButton("💾 Save Minutes of Meeting (MoM)")
        btn_save_notes.setProperty("class", "PrimaryBtn")
        btn_save_notes.clicked.connect(self.save_meeting_notes)
        t1_layout.addWidget(btn_save_notes)

        self.tabs.addTab(tab1, "📝 Minutes & Agenda")

        # Tab 2: Action Items
        tab2 = QWidget()
        t2_layout = QVBoxLayout(tab2)
        t2_layout.addWidget(QLabel("Meeting Action Items (Can be converted directly to Project Tasks):"))

        self.action_table = QTableWidget()
        self.action_table.setColumnCount(5)
        self.action_table.setHorizontalHeaderLabels(["Status", "Description", "Assignee", "Due Date", "Convert to Task"])
        self.action_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        t2_layout.addWidget(self.action_table)

        # Quick Add Action Item Row
        add_act_row = QHBoxLayout()
        self.new_act_desc = QLineEdit()
        self.new_act_desc.setPlaceholderText("New Action Item description...")
        self.new_act_assignee = QLineEdit("Arun K.")
        self.new_act_assignee.setMaximumWidth(120)
        self.new_act_due = QLineEdit(date.today().isoformat())
        self.new_act_due.setMaximumWidth(110)

        btn_add_act = QPushButton("+ Add Action")
        btn_add_act.setProperty("class", "SuccessBtn")
        btn_add_act.clicked.connect(self.add_action_item)

        add_act_row.addWidget(self.new_act_desc)
        add_act_row.addWidget(self.new_act_assignee)
        add_act_row.addWidget(self.new_act_due)
        add_act_row.addWidget(btn_add_act)
        t2_layout.addLayout(add_act_row)

        self.tabs.addTab(tab2, "🎯 Action Items")

        # Tab 3: AI Assistant & Exporters
        tab3 = QWidget()
        t3_layout = QVBoxLayout(tab3)
        t3_layout.setSpacing(12)

        t3_layout.addWidget(QLabel("Claude AI Meeting Assistant & Document Generator:"))

        ai_btn_row = QHBoxLayout()
        btn_ai_prep = QPushButton("🤖 AI Prep Docket & Talking Points")
        btn_ai_prep.setProperty("class", "PrimaryBtn")
        btn_ai_prep.clicked.connect(self.ai_prepare_docket)

        btn_ai_mom = QPushButton("🤖 AI Structure MoM from Notes")
        btn_ai_mom.setProperty("class", "SecondaryBtn")
        btn_ai_mom.clicked.connect(self.ai_structure_mom)

        ai_btn_row.addWidget(btn_ai_prep)
        ai_btn_row.addWidget(btn_ai_mom)
        t3_layout.addLayout(ai_btn_row)

        self.ai_output = QTextEdit()
        self.ai_output.setPlaceholderText("AI generated talking points, agendas, or structured MoM will appear here...")
        t3_layout.addWidget(self.ai_output)

        export_row = QHBoxLayout()
        btn_export_odt = QPushButton("📄 Export MoM to ODT (.odt)")
        btn_export_odt.setProperty("class", "SecondaryBtn")
        btn_export_odt.clicked.connect(self.export_meeting_odt)

        btn_export_ics = QPushButton("📅 Add to Calendar (.ics)")
        btn_export_ics.setProperty("class", "SecondaryBtn")
        btn_export_ics.clicked.connect(self.export_meeting_ics)

        export_row.addWidget(btn_export_odt)
        export_row.addWidget(btn_export_ics)
        t3_layout.addLayout(export_row)

        self.tabs.addTab(tab3, "🤖 Claude AI Prep & Exports")

        self.detail_layout.addWidget(self.tabs)
        splitter.addWidget(detail_frame)

        splitter.setSizes([260, 640])
        main_layout.addWidget(splitter)

        self.refresh()

    def refresh(self) -> None:
        while self.list_layout.count():
            item = self.list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        meetings = self.db.get_meetings()
        if not meetings:
            empty = QLabel("No meetings scheduled yet.")
            empty.setStyleSheet("color: #94a3b8; font-style: italic;")
            self.list_layout.addWidget(empty)
            return

        for m in meetings:
            btn = QPushButton(f"{m.get('title')}\n📅 {m.get('meeting_date')}")
            btn.setStyleSheet("""
                QPushButton {
                    background: #0f172a;
                    border: 1px solid #334155;
                    border-radius: 6px;
                    color: #f8fafc;
                    padding: 8px;
                    text-align: left;
                    font-size: 12px;
                }
                QPushButton:hover {
                    border-color: #6366f1;
                }
            """)
            mid = m.get("id")
            btn.clicked.connect(lambda checked=False, id_=mid: self.select_meeting(id_))
            self.list_layout.addWidget(btn)

        self.list_layout.addStretch()

        if self.selected_meeting_id:
            self.select_meeting(self.selected_meeting_id)
        elif meetings:
            self.select_meeting(meetings[0]["id"])

    def select_meeting(self, meeting_id: int) -> None:
        self.selected_meeting_id = meeting_id
        m = self.db.get_meeting_by_id(meeting_id)
        if not m:
            return

        self.m_title_lbl.setText(f"{m.get('title')} [{m.get('meeting_type')}]")
        self.m_meta_lbl.setText(f"Date: {m.get('meeting_date')}  |  Duration: {m.get('duration_minutes')}m  |  Attendees: {m.get('attendees')}")

        self.agenda_in.setPlainText(m.get("agenda") or "")
        self.notes_in.setPlainText(m.get("notes") or "")
        self.decisions_in.setPlainText(m.get("key_decisions") or "")

        self._refresh_action_items(meeting_id)

    def _refresh_action_items(self, meeting_id: int) -> None:
        items = self.db.get_action_items(meeting_id)
        self.action_table.setRowCount(len(items))

        for row, it in enumerate(items):
            status_item = QTableWidgetItem(it.get("status"))
            self.action_table.setItem(row, 0, status_item)

            desc_item = QTableWidgetItem(it.get("description"))
            self.action_table.setItem(row, 1, desc_item)

            assignee_item = QTableWidgetItem(it.get("assignee") or "")
            self.action_table.setItem(row, 2, assignee_item)

            due_item = QTableWidgetItem(it.get("due_date") or "")
            self.action_table.setItem(row, 3, due_item)

            # Convert to task button
            act_id = it.get("id")
            is_task = it.get("task_id") is not None
            btn_convert = QPushButton("✓ Linked to Task" if is_task else "+ Convert to Task")
            btn_convert.setEnabled(not is_task)
            btn_convert.setStyleSheet("""
                QPushButton {
                    background: #334155;
                    color: #f8fafc;
                    padding: 3px 6px;
                    border-radius: 4px;
                    font-size: 11px;
                }
            """)
            if not is_task:
                btn_convert.clicked.connect(lambda checked=False, aid=act_id: self.convert_action_to_task(aid))

            self.action_table.setCellWidget(row, 4, btn_convert)

    def save_meeting_notes(self) -> None:
        if not self.selected_meeting_id:
            return
        self.db.update_meeting(self.selected_meeting_id, {
            "agenda": self.agenda_in.toPlainText().strip(),
            "notes": self.notes_in.toPlainText().strip(),
            "key_decisions": self.decisions_in.toPlainText().strip()
        })
        QMessageBox.information(self, "Saved", "Meeting notes and decisions updated successfully!")

    def add_action_item(self) -> None:
        if not self.selected_meeting_id:
            return
        desc = self.new_act_desc.text().strip()
        if not desc:
            return
        self.db.add_action_item({
            "meeting_id": self.selected_meeting_id,
            "project_id": 1,
            "task_id": None,
            "description": desc,
            "assignee": self.new_act_assignee.text().strip(),
            "due_date": self.new_act_due.text().strip(),
            "status": "Open"
        })
        self.new_act_desc.clear()
        self._refresh_action_items(self.selected_meeting_id)

    def convert_action_to_task(self, action_id: int) -> None:
        projects = self.db.get_projects()
        pid = projects[0]["id"] if projects else 1
        tid = self.db.convert_action_item_to_task(action_id, pid)
        QMessageBox.information(self, "Task Created", f"Action item successfully converted into Task #{tid}!")
        if self.selected_meeting_id:
            self._refresh_action_items(self.selected_meeting_id)

    def ai_prepare_docket(self) -> None:
        if not self.selected_meeting_id:
            return
        m = self.db.get_meeting_by_id(self.selected_meeting_id)
        projects = self.db.get_projects()
        tasks = self.db.get_tasks()
        docket = self.ai.prepare_meeting_docket(m, projects, tasks)
        self.ai_output.setPlainText(docket)

    def ai_structure_mom(self) -> None:
        notes = self.notes_in.toPlainText().strip()
        if not notes:
            QMessageBox.warning(self, "No Notes", "Please write rough notes first in the Minutes tab!")
            return
        m = self.db.get_meeting_by_id(self.selected_meeting_id)
        mom = self.ai.synthesize_meeting_mom(notes, m.get("title", "Office Meeting"))
        self.ai_output.setPlainText(mom)

    def export_meeting_odt(self) -> None:
        if not self.selected_meeting_id:
            return
        m = self.db.get_meeting_by_id(self.selected_meeting_id)
        projects = self.db.get_projects()
        tasks = self.db.get_tasks()
        gen = ODTGenerator()
        path = gen.generate_odt_report(projects, tasks, [m], report_title=f"MoM: {m.get('title')}")
        QMessageBox.information(self, "ODT Exported", f"Meeting Minutes exported successfully to:\n{path}")

    def export_meeting_ics(self) -> None:
        if not self.selected_meeting_id:
            return
        m = self.db.get_meeting_by_id(self.selected_meeting_id)
        gen = CalendarGenerator()
        path = gen.export_calendar([m])
        QMessageBox.information(self, "Calendar Exported", f"Meeting event exported as iCalendar (.ics):\n{path}\n\nYou can now open it in Google Calendar, Outlook, or Thunderbird!")

    def show_new_meeting_dialog(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("Schedule New Meeting")
        dlg.resize(460, 420)
        form = QFormLayout(dlg)

        title_in = QLineEdit()
        type_combo = QComboBox()
        type_combo.addItems(["Weekly Sync", "Project Review", "Sprint Planning", "Client Demo", "1-on-1"])

        date_in = QLineEdit((datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d 10:00"))
        dur_in = QSpinBox()
        dur_in.setRange(15, 240)
        dur_in.setValue(45)
        dur_in.setSuffix(" mins")

        attendees_in = QLineEdit("Arun K., Team")
        projects_in = QLineEdit("CIM, CP2, AIO")
        agenda_in = QTextEdit()
        agenda_in.setMaximumHeight(80)

        form.addRow("Meeting Title *:", title_in)
        form.addRow("Meeting Type:", type_combo)
        form.addRow("Date & Time (YYYY-MM-DD HH:MM):", date_in)
        form.addRow("Duration:", dur_in)
        form.addRow("Attendees:", attendees_in)
        form.addRow("Projects Involved:", projects_in)
        form.addRow("Initial Agenda:", agenda_in)

        btn_save = QPushButton("Schedule Meeting")
        btn_save.setProperty("class", "PrimaryBtn")

        def save():
            m_title = title_in.text().strip()
            if not m_title:
                return
            mid = self.db.add_meeting({
                "title": m_title,
                "meeting_type": type_combo.currentText(),
                "meeting_date": date_in.text().strip(),
                "duration_minutes": dur_in.value(),
                "projects_involved": projects_in.text().strip(),
                "attendees": attendees_in.text().strip(),
                "agenda": agenda_in.toPlainText().strip(),
                "notes": "",
                "key_decisions": "",
                "status": "Scheduled"
            })
            dlg.accept()
            self.refresh()
            self.select_meeting(mid)

        btn_save.clicked.connect(save)
        form.addRow(btn_save)
        dlg.exec()
