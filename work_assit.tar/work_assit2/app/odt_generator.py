"""OpenDocument Text (.odt) Generator.
Generates native, beautifully formatted .odt documents using Python standard library.
Compatible with LibreOffice Writer, Microsoft Word, and Google Docs.
"""

from __future__ import annotations
import zipfile
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional
import xml.sax.saxutils as saxutils


class ODTGenerator:
    """Generates standard OpenDocument Text (.odt) documents."""

    def __init__(self, output_dir: Optional[Path] = None):
        self.output_dir = output_dir or (Path(__file__).resolve().parent.parent / "exports")
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_odt_report(
        self,
        projects: List[Dict[str, Any]],
        tasks: List[Dict[str, Any]],
        meetings: List[Dict[str, Any]],
        report_title: str = "Weekly Executive Delivery & Meeting Report",
        filename: Optional[str] = None
    ) -> Path:
        """Create a complete .odt document package."""
        if not filename:
            today_str = date.today().strftime("%Y%m%d")
            filename = f"Weekly_Office_Report_{today_str}.odt"

        output_path = self.output_dir / filename

        mimetype_content = "application/vnd.oasis.opendocument.text"

        manifest_content = """<?xml version="1.0" encoding="UTF-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
  <manifest:file-entry manifest:full-path="/" manifest:version="1.2" manifest:media-type="application/vnd.oasis.opendocument.text"/>
  <manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>
  <manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>
</manifest:manifest>
"""

        styles_content = """<?xml version="1.0" encoding="UTF-8"?>
<office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
  xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0"
  xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"
  office:version="1.2">
  <office:styles>
    <style:default-style style:family="paragraph">
      <style:paragraph-properties fo:line-height="120%" fo:margin-bottom="0.2cm"/>
      <style:text-properties fo:font-family="Arial, Helvetica, sans-serif" fo:font-size="11pt" fo:color="#1e293b"/>
    </style:default-style>
  </office:styles>
</office:document-styles>
"""

        # Build Body XML
        body_xml = self._build_content_xml(projects, tasks, meetings, report_title)

        # Write ZIP container
        with zipfile.ZipFile(str(output_path), "w", compression=zipfile.ZIP_DEFLATED) as zf:
            # mimetype must be stored uncompressed as the first entry
            zf.writestr("mimetype", mimetype_content, compress_type=zipfile.ZIP_STORED)
            zf.writestr("META-INF/manifest.xml", manifest_content)
            zf.writestr("styles.xml", styles_content)
            zf.writestr("content.xml", body_xml)

        return output_path

    def _build_content_xml(
        self,
        projects: List[Dict[str, Any]],
        tasks: List[Dict[str, Any]],
        meetings: List[Dict[str, Any]],
        report_title: str
    ) -> str:
        esc = saxutils.escape
        today_formatted = date.today().strftime("%B %d, %Y")

        done_tasks = [t for t in tasks if t.get("status") == "Done"]
        in_prog_tasks = [t for t in tasks if t.get("status") == "In Progress"]
        blocked_tasks = [t for t in tasks if t.get("status") == "Blocked"]

        p_xml = []
        p_xml.append(f'<text:h text:outline-level="1">{esc(report_title)}</text:h>')
        p_xml.append(f'<text:p><text:span text:style-name="Bold">Date: </text:span>{esc(today_formatted)} | <text:span text:style-name="Bold">Lead Officer: </text:span>Arun K. | <text:span text:style-name="Bold">System: </text:span>WorkAssist Pro</text:p>')
        p_xml.append('<text:p/>')

        # 1. Executive Summary
        p_xml.append('<text:h text:outline-level="2">1. Executive Summary & Health Assessment</text:h>')
        summary_text = (
            f"During this period, active engineering delivery spanned {len(projects)} primary enterprise projects. "
            f"A total of {len(done_tasks)} critical tasks have been finalized, while {len(in_prog_tasks)} items are under active development. "
            f"There are currently {len(blocked_tasks)} active blocker(s) requiring management intervention."
        )
        p_xml.append(f'<text:p>{esc(summary_text)}</text:p>')
        p_xml.append('<text:p/>')

        # 2. Projects Table
        p_xml.append('<text:h text:outline-level="2">2. Active Project Portfolio</text:h>')
        for p in projects:
            p_desc = p.get('description', 'No description provided')
            p_xml.append(f'<text:h text:outline-level="3">[{esc(p.get("code", ""))}] {esc(p.get("name", ""))}</text:h>')
            p_xml.append(f'<text:p><text:span text:style-name="Bold">Health: </text:span>{esc(p.get("health", ""))} | <text:span text:style-name="Bold">Priority: </text:span>{esc(p.get("priority", ""))} | <text:span text:style-name="Bold">Target: </text:span>{esc(p.get("target_date", "TBD"))}</text:p>')
            p_xml.append(f'<text:p>{esc(p_desc)}</text:p>')
        p_xml.append('<text:p/>')

        # 3. Task Accomplishments
        p_xml.append('<text:h text:outline-level="2">3. Key Accomplishments Completed</text:h>')
        if done_tasks:
            for t in done_tasks:
                p_xml.append(f'<text:p>• [DONE] {esc(t.get("title", ""))} ({esc(t.get("project_code", "General"))}) - Logged: {t.get("actual_hours", 0)}h</text:p>')
        else:
            p_xml.append('<text:p>• Scoping phase underway.</text:p>')
        p_xml.append('<text:p/>')

        # 4. In Progress & Blockers
        p_xml.append('<text:h text:outline-level="2">4. Active Tasks & Blockers</text:h>')
        for t in in_prog_tasks:
            p_xml.append(f'<text:p>• [IN PROGRESS] {esc(t.get("title", ""))} ({esc(t.get("project_code", "General"))}) - Due: {t.get("due_date", "")}</text:p>')
        
        if blocked_tasks:
            p_xml.append('<text:p/>')
            p_xml.append('<text:h text:outline-level="3">Critical Blockers:</text:h>')
            for t in blocked_tasks:
                p_xml.append(f'<text:p>⛔ [BLOCKED] {esc(t.get("title", ""))} | Reason: {esc(t.get("blocker_reason", "Pending escalation"))}</text:p>')
        p_xml.append('<text:p/>')

        # 5. Meeting Minutes & Action Items
        p_xml.append('<text:h text:outline-level="2">5. Upcoming Meetings & Action Items</text:h>')
        for m in meetings:
            p_xml.append(f'<text:p><text:span text:style-name="Bold">{esc(m.get("title", ""))}</text:span> ({esc(m.get("meeting_date", ""))})</text:p>')
            if m.get("agenda"):
                p_xml.append(f'<text:p>Agenda: {esc(m.get("agenda", ""))}</text:p>')
            if m.get("notes"):
                p_xml.append(f'<text:p>Notes: {esc(m.get("notes", ""))}</text:p>')

        content_inner = "\n".join(p_xml)

        return f"""<?xml version="1.0" encoding="UTF-8"?>
<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
  xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"
  xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0"
  xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"
  office:version="1.2">
  <office:automatic-styles>
    <style:style style:name="Bold" style:family="text">
      <style:text-properties fo:font-weight="bold"/>
    </style:style>
  </office:automatic-styles>
  <office:body>
    <office:text>
      {content_inner}
    </office:text>
  </office:body>
</office:document-content>
"""
