"""Seeds real office data for SVPDMG and OSS projects.
Includes System ATP, 0500 ATP, 5105 ATP, 0500 Library Delivery, System PBIT,
Software PDR preparation, and weekly Wednesday customer meetings (6 completed till today).
"""

from datetime import datetime, date, timedelta
from app.database import DatabaseManager


def seed_sample_data(db: DatabaseManager, force: bool = False) -> None:
    """Populates realistic data for SVPDMG and OSS."""
    if not force:
        existing = db.get_projects()
        if existing and any(p.get("code") in ("SVPDMG", "OSS") for p in existing):
            return  # Already seeded with user projects

    # If force, clear old tables
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM action_items")
        cursor.execute("DELETE FROM daily_logs")
        cursor.execute("DELETE FROM tasks")
        cursor.execute("DELETE FROM meetings")
        cursor.execute("DELETE FROM projects")
        cursor.execute("DELETE FROM reports")
        conn.commit()

    today = date.today()

    # Calculate this coming Wednesday
    days_ahead = (2 - today.weekday()) % 7  # 2 is Wednesday (Monday=0, Tuesday=1, Wednesday=2)
    if days_ahead == 0:
        days_ahead = 7  # Next Wednesday if today is Wednesday
    next_wednesday = today + timedelta(days=days_ahead)

    # =========================================================================
    # 1. Projects
    # =========================================================================
    p_svpdmg = db.add_project({
        "name": "SVPDMG Program",
        "code": "SVPDMG",
        "description": "SVPDMG core system: System ATP, 0500 ATP & library deliveries, 5105 ATP, System PBIT, and Software PDR preparation.",
        "color": "#3b82f6",  # Blue
        "status": "Active",
        "priority": "Urgent",
        "health": "On Track",
        "start_date": (today - timedelta(days=60)).isoformat(),
        "target_date": (today + timedelta(days=45)).isoformat(),
        "lead_name": "Arun K."
    })

    p_oss = db.add_project({
        "name": "OSS Program",
        "code": "OSS",
        "description": "OSS system deliveries, recurring Wednesday customer meetings (6 completed), milestone reviews, and customer sign-off.",
        "color": "#10b981",  # Emerald Green
        "status": "Active",
        "priority": "High",
        "health": "On Track",
        "start_date": (today - timedelta(days=50)).isoformat(),
        "target_date": (today + timedelta(days=60)).isoformat(),
        "lead_name": "Arun K."
    })

    # =========================================================================
    # 2. Tasks under SVPDMG
    # =========================================================================
    # 0500 ATP & Library
    db.add_task({
        "project_id": p_svpdmg,
        "title": "0500 Library Build & Deliver Libraries",
        "description": "Compile, package, and deliver the 0500 binaries/libraries to the system integration and test bench.",
        "status": "In Progress",
        "priority": "Urgent",
        "category": "Development",
        "due_date": (today + timedelta(days=2)).isoformat(),
        "estimated_hours": 12.0,
        "actual_hours": 8.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    db.add_task({
        "project_id": p_svpdmg,
        "title": "0500 ATP Application Status & Test Verification",
        "description": "Execute 0500 ATP test cases, record application health logs, and verify pass/fail criteria.",
        "status": "In Progress",
        "priority": "High",
        "category": "Review",
        "due_date": (today + timedelta(days=3)).isoformat(),
        "estimated_hours": 10.0,
        "actual_hours": 5.5,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    db.add_task({
        "project_id": p_svpdmg,
        "title": "System PBIT (Power-On Built-In Test) Execution",
        "description": "Perform System PBIT diagnostic sequences, self-test health checks, and fault reporting verification.",
        "status": "To Do",
        "priority": "High",
        "category": "Architecture",
        "due_date": (today + timedelta(days=4)).isoformat(),
        "estimated_hours": 8.0,
        "actual_hours": 1.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    db.add_task({
        "project_id": p_svpdmg,
        "title": "System 0500 Application Status Review & Validation",
        "description": "Audit system 0500 application runtime stability, memory footprint, and telemetry outputs.",
        "status": "In Progress",
        "priority": "High",
        "category": "Development",
        "due_date": (today + timedelta(days=3)).isoformat(),
        "estimated_hours": 8.0,
        "actual_hours": 4.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    # System ATP & 5105 ATP
    db.add_task({
        "project_id": p_svpdmg,
        "title": "System ATP Protocol & Test Bench Setup",
        "description": "Comprehensive system-level Acceptance Test Procedure execution on integrated hardware bench.",
        "status": "Done",
        "priority": "High",
        "category": "Development",
        "due_date": (today - timedelta(days=2)).isoformat(),
        "estimated_hours": 16.0,
        "actual_hours": 15.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    db.add_task({
        "project_id": p_svpdmg,
        "title": "5105 ATP Module Verification & Test Procedure",
        "description": "Run 5105 ATP protocol tests, signal line checks, and interface communication validation.",
        "status": "To Do",
        "priority": "Medium",
        "category": "Review",
        "due_date": (today + timedelta(days=5)).isoformat(),
        "estimated_hours": 10.0,
        "actual_hours": 0.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    # Software PDR
    db.add_task({
        "project_id": p_svpdmg,
        "title": "Software PDR (Preliminary Design Review) Deck & Technical Dossier",
        "description": "Prepare comprehensive Software PDR slide deck, architectural diagrams, compliance matrix, and technical readiness report.",
        "status": "In Progress",
        "priority": "Urgent",
        "category": "Documentation",
        "due_date": next_wednesday.isoformat(),
        "estimated_hours": 20.0,
        "actual_hours": 12.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    # =========================================================================
    # 3. Tasks under OSS
    # =========================================================================
    db.add_task({
        "project_id": p_oss,
        "title": "Weekly Wednesday Customer Meeting Deck & Delivery Docket Preparation",
        "description": "Compile status report, 0500 library delivery items, and Software PDR progress for Wednesday Customer review.",
        "status": "In Progress",
        "priority": "Urgent",
        "category": "Management",
        "due_date": next_wednesday.isoformat(),
        "estimated_hours": 6.0,
        "actual_hours": 3.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    db.add_task({
        "project_id": p_oss,
        "title": "OSS Customer Action Items Tracking & Sign-off",
        "description": "Track, close, and verify all action items raised across past 6 customer meetings.",
        "status": "Done",
        "priority": "High",
        "category": "Management",
        "due_date": (today - timedelta(days=1)).isoformat(),
        "estimated_hours": 8.0,
        "actual_hours": 8.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    db.add_task({
        "project_id": p_oss,
        "title": "OSS Software Release Package & Checksum Verification",
        "description": "Bundle latest validated libraries and release notes for upcoming customer milestone signoff.",
        "status": "To Do",
        "priority": "High",
        "category": "DevOps",
        "due_date": (next_wednesday + timedelta(days=2)).isoformat(),
        "estimated_hours": 6.0,
        "actual_hours": 0.0,
        "blocker_reason": "",
        "assigned_to": "Arun K."
    })

    # =========================================================================
    # 4. Meetings: 6 Completed OSS Customer Meetings + Upcoming Wednesday Meeting
    # =========================================================================
    # Meeting 1
    db.add_meeting({
        "title": "OSS Customer Meeting #1 — Requirements & Scope Baseline",
        "meeting_type": "Weekly Sync",
        "meeting_date": (today - timedelta(days=42)).strftime("%Y-%m-%d 14:00"),
        "duration_minutes": 60,
        "projects_involved": "OSS, SVPDMG",
        "attendees": "Arun K., Customer Technical Director, Systems Engineering",
        "agenda": "1. OSS program kickoff\n2. Scope definition and ATP roadmap\n3. Set weekly Wednesday sync cadence",
        "notes": "Customer agreed to weekly Wednesday reviews. Outlined preliminary delivery dates.",
        "key_decisions": "Weekly Wednesday customer meeting fixed at 14:00.",
        "status": "Completed"
    })

    # Meeting 2
    db.add_meeting({
        "title": "OSS Customer Meeting #2 — Architecture & Interface Spec Review",
        "meeting_type": "Weekly Sync",
        "meeting_date": (today - timedelta(days=35)).strftime("%Y-%m-%d 14:00"),
        "duration_minutes": 60,
        "projects_involved": "OSS, SVPDMG",
        "attendees": "Arun K., Lead Architect, Customer Program Manager",
        "agenda": "1. 0500 library interface specification\n2. System PBIT protocol alignment",
        "notes": "Reviewed ICD (Interface Control Document). Customer requested 0500 library delivery timeline.",
        "key_decisions": "0500 library deliverables defined.",
        "status": "Completed"
    })

    # Meeting 3
    db.add_meeting({
        "title": "OSS Customer Meeting #3 — 0500 Library & ATP Milestone Review",
        "meeting_type": "Weekly Sync",
        "meeting_date": (today - timedelta(days=28)).strftime("%Y-%m-%d 14:00"),
        "duration_minutes": 45,
        "projects_involved": "OSS, SVPDMG",
        "attendees": "Arun K., QA Lead, Customer Tech Team",
        "agenda": "1. 0500 ATP execution progress\n2. Library delivery format and checksum validation",
        "notes": "Customer confirmed receipt of initial test report for 0500 ATP.",
        "key_decisions": "Approved automated test report generation format.",
        "status": "Completed"
    })

    # Meeting 4
    db.add_meeting({
        "title": "OSS Customer Meeting #4 — System PBIT & 5105 ATP Alignment",
        "meeting_type": "Weekly Sync",
        "meeting_date": (today - timedelta(days=21)).strftime("%Y-%m-%d 14:00"),
        "duration_minutes": 50,
        "projects_involved": "OSS, SVPDMG",
        "attendees": "Arun K., Systems Team, Customer Lead",
        "agenda": "1. System PBIT sequence demo\n2. 5105 ATP test setup timeline\n3. Software PDR roadmap",
        "notes": "Demonstrated PBIT diagnostics. Customer satisfied with power-on sequence time.",
        "key_decisions": "Software PDR target date confirmed.",
        "status": "Completed"
    })

    # Meeting 5
    db.add_meeting({
        "title": "OSS Customer Meeting #5 — Pre-PDR Review & Deliverables Check",
        "meeting_type": "Weekly Sync",
        "meeting_date": (today - timedelta(days=14)).strftime("%Y-%m-%d 14:00"),
        "duration_minutes": 60,
        "projects_involved": "OSS, SVPDMG",
        "attendees": "Arun K., Project Director, Customer Evaluation Team",
        "agenda": "1. Pre-PDR slide package dry run\n2. 0500 application status review\n3. Deliverable libraries status",
        "notes": "Reviewed first draft of Software PDR deck. Received feedback on slide layout.",
        "key_decisions": "Customer requested detailed 0500 library status slide in next presentation.",
        "status": "Completed"
    })

    # Meeting 6 (Most recent completed meeting)
    m6_id = db.add_meeting({
        "title": "OSS Customer Meeting #6 — Weekly Status & Software PDR Readiness",
        "meeting_type": "Weekly Sync",
        "meeting_date": (today - timedelta(days=7)).strftime("%Y-%m-%d 14:00"),
        "duration_minutes": 60,
        "projects_involved": "OSS, SVPDMG",
        "attendees": "Arun K., Customer Technical Director, Chief Systems Engineer",
        "agenda": "1. Review completed System ATP test results\n2. Current 0500 ATP application status\n3. System 0500 application stability report\n4. Finalize date for Software PDR",
        "notes": "Meeting #6 successfully completed. Customer acknowledged strong progress on 0500 ATP and PBIT.",
        "key_decisions": "Agreed to finalize 0500 library deliverable package prior to Meeting #7.",
        "status": "Completed"
    })

    # Upcoming Meeting 7 (This Wednesday!)
    m7_id = db.add_meeting({
        "title": f"OSS Customer Meeting #7 — Weekly Wednesday Sync & Software PDR Signoff",
        "meeting_type": "Weekly Sync",
        "meeting_date": f"{next_wednesday.strftime('%Y-%m-%d')} 14:00",
        "duration_minutes": 60,
        "projects_involved": "OSS, SVPDMG",
        "attendees": "Arun K. (Lead Engineer), Customer Technical Lead, Defense Systems PM",
        "agenda": (
            "1. Deliver libraries: 0500 library build delivery & checksum verification\n"
            "2. ATP Application status: System ATP, 0500 ATP, and 5105 ATP test metrics\n"
            "3. System PBIT: Power-On Built-In Test diagnostics report & fault injection\n"
            "4. System 0500 application status & memory profile\n"
            "5. Software PDR preparation & slide deck walkthrough (PPT presentation)"
        ),
        "notes": "Key preparation meeting for final Software PDR. Presentation slide deck (.pptx) must be delivered 2 hours before the call.",
        "key_decisions": "Pending customer sign-off on 0500 library package and PDR readiness.",
        "status": "Scheduled"
    })

    # Action Items for Meeting 7
    db.add_action_item({
        "meeting_id": m7_id,
        "project_id": p_svpdmg,
        "task_id": None,
        "description": "Package 0500 library binaries and deliver with release notes",
        "assignee": "Arun K.",
        "due_date": (next_wednesday - timedelta(days=1)).isoformat(),
        "status": "Open"
    })

    db.add_action_item({
        "meeting_id": m7_id,
        "project_id": p_svpdmg,
        "task_id": None,
        "description": "Finalize Software PDR presentation slides (.pptx) for Customer Meeting #7",
        "assignee": "Arun K.",
        "due_date": next_wednesday.isoformat(),
        "status": "Open"
    })

    db.add_action_item({
        "meeting_id": m7_id,
        "project_id": p_svpdmg,
        "task_id": None,
        "description": "Execute System PBIT validation and compile telemetry log summary",
        "assignee": "Arun K.",
        "due_date": next_wednesday.isoformat(),
        "status": "Open"
    })

    # Daily Standup Log
    db.add_or_update_daily_log({
        "log_date": today.isoformat(),
        "project_id": p_svpdmg,
        "completed_today": (
            "• Validated System ATP baseline results on integration test bench.\n"
            "• Built preliminary 0500 library deliverable package.\n"
            "• Drafted slides 1-5 for Software PDR presentation."
        ),
        "planned_tomorrow": (
            "• Complete 0500 ATP application status verification.\n"
            "• Run System PBIT test sequences and record telemetry.\n"
            "• Prep executive deck for upcoming Wednesday Customer Meeting #7."
        ),
        "blockers": "None at present. Hardware bench is available for 5105 ATP verification.",
        "hours_spent": 8.0,
        "notes": "On track for Wednesday customer review and Software PDR sign-off."
    })
