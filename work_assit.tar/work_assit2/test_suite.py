"""Automated Test Suite for WorkAssist Pro.
Verifies all backend engines, generators (PPT, ODT, CAL), database, and Qt views.
Can run in offscreen/headless mode.
"""

import sys
import os
from pathlib import Path

# Add root to sys.path
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Ensure user site-packages are reachable
user_site = Path.home() / ".local/lib/python3.10/site-packages"
if user_site.exists() and str(user_site) not in sys.path:
    sys.path.insert(0, str(user_site))

os.environ["QT_QPA_PLATFORM"] = "offscreen"


def run_tests():
    print("==================================================")
    print(" Running WorkAssist Pro Verification Suite")
    print("==================================================")

    # 1. Test Database & Schema
    print("[1/6] Testing Database & Schema Initialization...")
    from app.database import DatabaseManager
    from app.sample_data import seed_sample_data

    test_db_path = ROOT_DIR / "data" / "test_workassist.db"
    if test_db_path.exists():
        test_db_path.unlink()

    db = DatabaseManager(test_db_path)
    seed_sample_data(db)

    projects = db.get_projects()
    tasks = db.get_tasks()
    meetings = db.get_meetings()
    logs = db.get_daily_logs()
    metrics = db.get_dashboard_metrics()

    assert len(projects) >= 2, f"Expected >= 2 projects (SVPDMG, OSS), got {len(projects)}"
    assert any(p["code"] == "SVPDMG" for p in projects), "Missing SVPDMG project"
    assert any(p["code"] == "OSS" for p in projects), "Missing OSS project"
    assert len(tasks) >= 6, f"Expected >= 6 tasks, got {len(tasks)}"
    assert len(meetings) >= 2, f"Expected >= 2 meetings, got {len(meetings)}"
    assert len(logs) >= 1, f"Expected >= 1 daily log, got {len(logs)}"
    print(f"      ✓ Database initialized with {len(projects)} projects, {len(tasks)} tasks, {len(meetings)} meetings.")

    # 2. Test AI Service & Resilient Completions
    print("[2/6] Testing Local Claude / AI Office Copilot Engine...")
    from app.ai_service import AIService
    ai = AIService()
    weekly_rep = ai.generate_weekly_report(projects, tasks, logs)
    assert len(weekly_rep) > 100, "Weekly report should not be empty"

    docket = ai.prepare_meeting_docket(meetings[0], projects, tasks)
    assert len(docket) > 100, "Meeting docket should not be empty"

    chat_res = ai.chat("What are my highest priority tasks?", projects, tasks, meetings, logs)
    assert len(chat_res) > 50, "Chat response should not be empty"
    print("      ✓ AI Service, weekly synthesis, and offline reasoning engine verified.")

    # 3. Test PPTX Presentation Generator
    print("[3/6] Testing Executive PowerPoint (.pptx) Generator...")
    from app.ppt_generator import PPTGenerator
    ppt_gen = PPTGenerator()
    ppt_file = ppt_gen.generate_presentation(projects, tasks, meetings, filename="Test_Weekly_Deck.pptx")
    assert ppt_file.exists(), f"PPTX file was not created: {ppt_file}"
    assert ppt_file.stat().st_size > 1000, f"PPTX file size suspiciously small: {ppt_file.stat().st_size} bytes"
    print(f"      ✓ PPTX generated successfully: {ppt_file.name} ({ppt_file.stat().st_size} bytes)")

    # 4. Test ODT Report Generator
    print("[4/6] Testing OpenDocument Text (.odt) Generator...")
    from app.odt_generator import ODTGenerator
    odt_gen = ODTGenerator()
    odt_file = odt_gen.generate_odt_report(projects, tasks, meetings, filename="Test_Office_Report.odt")
    assert odt_file.exists(), f"ODT file was not created: {odt_file}"
    assert odt_file.stat().st_size > 500, f"ODT file size suspiciously small: {odt_file.stat().st_size} bytes"
    print(f"      ✓ ODT generated successfully: {odt_file.name} ({odt_file.stat().st_size} bytes)")

    # 5. Test Calendar (.ics / CAL) Generator
    print("[5/6] Testing iCalendar (.ics / CAL) Generator...")
    from app.calendar_generator import CalendarGenerator
    cal_gen = CalendarGenerator()
    ics_file = cal_gen.export_calendar(meetings, tasks, filename="Test_Calendar.ics")
    assert ics_file.exists(), f"ICS file was not created: {ics_file}"
    with open(ics_file, "r", encoding="utf-8") as f:
        ics_text = f.read()
    assert "BEGIN:VCALENDAR" in ics_text and "END:VCALENDAR" in ics_text
    assert "BEGIN:VEVENT" in ics_text
    print(f"      ✓ Calendar file generated successfully: {ics_file.name} ({len(ics_text.splitlines())} lines)")

    # 6. Test Qt GUI & Navigation Stack
    print("[6/6] Testing PySide6 GUI Components & Navigation Stack (Offscreen)...")
    from PySide6.QtWidgets import QApplication
    from app.ui.main_window import MainWindow

    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow(db, ai)
    assert window.stack.count() == 10, f"Expected 10 stacked views, found {window.stack.count()}"

    # Cycle through tabs to verify each view initializes and refreshes cleanly
    for i in range(10):
        window.stack.setCurrentIndex(i)
        w = window.stack.currentWidget()
        if hasattr(w, "refresh"):
            w.refresh()
    print("      ✓ All 10 Qt GUI views (Dashboard, Projects, Tasks, Daily, Meetings, Reports, PPT, Calendar, Claude, Settings) initialized and verified!")

    # Cleanup test db
    if test_db_path.exists():
        test_db_path.unlink()

    print("\n==================================================")
    print(" 🎉 ALL TESTS PASSED! APPLICATION IS 100% READY!")
    print("==================================================")


if __name__ == "__main__":
    run_tests()
