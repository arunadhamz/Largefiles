#pragma once

#include "geospatial_types.hpp"
#include <deque>
#include <string>

class KinematicEngine {
public:
    KinematicEngine();

    void setSensorLocation(double latDeg, double lonDeg, double altMeters, const std::string& name = "Sensor Station");
    const GeoPoint& sensorLocation() const { return sensorGeo_; }
    const std::string& sensorName() const { return sensorName_; }

    KinematicState process(double azimuthDeg,
                           double elevationDeg,
                           double detectedPixelWidth,
                           double dt,
                           bool isTracking);

    void reset();

    const std::vector<TrajectoryPoint3D>& trajectoryHistory() const { return history_; }

private:
    GeoPoint sensorGeo_;
    std::string sensorName_;

    // Filtered state
    double prevEast_{0.0};
    double prevNorth_{0.0};
    double prevUp_{0.0};
    double filteredVelEast_{0.0};
    double filteredVelNorth_{0.0};
    double filteredVelUp_{5.2}; // Standard 5.2 m/s ascent rate initial prior
    double estimatedAltitude_{800.0};
    double sessionTime_{0.0};
    bool initialized_{false};

    std::vector<TrajectoryPoint3D> history_;

    GeoPoint enuToGeo(double eastM, double northM, double upM) const;
};
