#pragma once

#include <QMainWindow>
#include <QLabel>
#include <QComboBox>
#include <QPushButton>
#include <QCheckBox>
#include <QTabWidget>
#include <QProgressBar>
#include <QTextEdit>
#include "map_canvas_2d.hpp"
#include "kinematic_engine.hpp"
#include "kinematic_plot_widget.hpp"
#include "target_tracker.hpp"

class GeospatialWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit GeospatialWindow(QWidget* parent = nullptr);
    ~GeospatialWindow() override = default;

public slots:
    void updateTargetTelemetry(const TrackedTarget& target, double dt);

private slots:
    void onStationChanged(int index);
    void onResetViewClicked();
    void onFocusTargetClicked();
    void onFocusSensorClicked();
    void onZoomInClicked();
    void onZoomOutClicked();

private:
    MapCanvas2D* mapCanvas_{nullptr};
    KinematicPlotWidget* plotWidget_{nullptr};
    KinematicEngine kinematicEngine_;

    // Top Mission Header
    QLabel* missionStatusLabel_{nullptr};
    QLabel* utcClockLabel_{nullptr};

    // Telemetry Tab 1 UI elements
    QLabel* targetIdBadge_{nullptr};
    QLabel* positionLabel_{nullptr};
    QLabel* rangeLabel_{nullptr};
    QLabel* velocityLabel_{nullptr};
    QLabel* anglesLabel_{nullptr};
    QProgressBar* altitudeBar_{nullptr};
    QProgressBar* speedBar_{nullptr};

    // Launch Site Tab 3 UI elements
    QLabel* launchCoordLabel_{nullptr};
    QLabel* launchDistanceLabel_{nullptr};
    QLabel* launchBearingLabel_{nullptr};

    // Station selection
    QComboBox* stationCombo_{nullptr};

    // Map Layer Checkboxes
    QCheckBox* chkRadar_{nullptr};
    QCheckBox* chkTrajectory_{nullptr};
    QCheckBox* chkGrid_{nullptr};
    QCheckBox* chkStations_{nullptr};
    QCheckBox* chkLaunch_{nullptr};

    // Mathematical Derivation Text
    QTextEdit* mathDerivationText_{nullptr};

    void setupUi();
    void updateTelemetryCard(const KinematicState& state);
};
