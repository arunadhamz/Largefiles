#pragma once

#include <vector>
#include <string>

struct GeoPoint {
    double lat{0.0};  // Degrees North
    double lon{0.0};  // Degrees East
    double alt{0.0};  // Altitude in meters ASL
};

struct KinematicState {
    // 3D Cartesian coordinates in Local Tangent Plane (East-North-Up) in meters
    double eastMeters{0.0};
    double northMeters{0.0};
    double upMeters{0.0};
    double rangeMeters{0.0};

    // 3D Velocity vector in m/s
    double velEast{0.0};
    double velNorth{0.0};
    double velUp{0.0};
    double speedGround{0.0};
    double speedTotal{0.0};
    double climbRate{0.0};

    // Angles
    double flightPathAngleDeg{0.0};
    double headingDeg{0.0};
    double azimuthDeg{0.0};
    double elevationDeg{0.0};

    // Geodetic Coordinates
    GeoPoint targetGeo;
    GeoPoint estimatedLaunchGeo;
    double launchDistanceKm{0.0};

    bool hasValidSolution{false};
};

struct TrajectoryPoint3D {
    double east;
    double north;
    double alt;
    GeoPoint geo;
    double timestamp;
};
