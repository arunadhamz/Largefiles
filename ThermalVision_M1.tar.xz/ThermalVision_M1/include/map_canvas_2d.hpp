#pragma once

#include "geospatial_types.hpp"
#include <QWidget>
#include <QImage>
#include <QPointF>
#include <vector>

class MapCanvas2D : public QWidget {
    Q_OBJECT
public:
    explicit MapCanvas2D(QWidget* parent = nullptr);
    ~MapCanvas2D() override = default;

    void setSensorLocation(const GeoPoint& geo, const std::string& name);
    void updateKinematics(const KinematicState& state, const std::vector<TrajectoryPoint3D>& history);

    void resetView();
    void zoomIn();
    void zoomOut();
    void centerOnTarget();
    void centerOnSensor();

    void toggleRadarRings(bool enable) { showRadarRings_ = enable; update(); }
    void toggleTrajectory(bool enable) { showTrajectory_ = enable; update(); }
    void toggleGrid(bool enable) { showGrid_ = enable; update(); }
    void toggleStations(bool enable) { showStations_ = enable; update(); }
    void toggleLaunchOrigin(bool enable) { showLaunchOrigin_ = enable; update(); }

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void wheelEvent(QWheelEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

private:
    GeoPoint sensorGeo_;
    std::string sensorName_{"Sensor Station"};
    KinematicState currentState_;
    std::vector<TrajectoryPoint3D> history_;

    // 2D Pan and Zoom
    double zoom_{1.0};
    QPointF panOffset_{0.0, 0.0};
    QPoint lastMousePos_;
    QRectF mapRect_; // Bounding rectangle where indian_map.jpg is drawn

    QImage mapImage_;
    bool hasMapImage_{false};

    // Layer Visibility
    bool showRadarRings_{true};
    bool showTrajectory_{true};
    bool showGrid_{true};
    bool showStations_{true};
    bool showLaunchOrigin_{true};

    void loadMapImage();
    void updateMapRect();
    QPointF geoToScreen(double lat, double lon) const;
    double metersToPixels(double meters, double atLat) const;
};
