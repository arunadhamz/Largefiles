#pragma once

#include <QCheckBox>
#include <QComboBox>
#include <QLabel>
#include <QMainWindow>
#include <QTimer>
#include <chrono>
#include <memory>
#include "cuda_processor.hpp"
#include "rtsp_capture.hpp"
#include "target_tracker.hpp"

class GeospatialWindow;
class QPushButton;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(const QString& rtspUrl, QWidget* parent = nullptr);
    ~MainWindow() override;

protected:
    void keyPressEvent(QKeyEvent* event) override;

private slots:
    void updateFrame();

private:
    QLabel* videoLabel_{nullptr};
    QLabel* statusLabel_{nullptr};
    QLabel* targetsLabel_{nullptr};
    QCheckBox* trackingCheckBox_{nullptr};
    QCheckBox* trajectoryCheckBox_{nullptr};
    QCheckBox* cudaEnhanceCheckBox_{nullptr};
    QComboBox* colormapComboBox_{nullptr};
    QPushButton* openGeospatialBtn_{nullptr};
    GeospatialWindow* geospatialWindow_{nullptr};

    QTimer timer_;
    RtspCapture capture_;
    CudaProcessor processor_;
    TargetDetector detector_;
    TargetTracker tracker_;

    cv::Mat input_;
    std::vector<std::uint8_t> output_;
    std::chrono::steady_clock::time_point lastUpdate_;
    double displayedFps_{0.0};
    QString url_;
};
