#pragma once

#include <cstdint>
#include <cstddef>
#include <vector>

class CudaProcessor {
public:
    CudaProcessor();
    ~CudaProcessor();

    CudaProcessor(const CudaProcessor&) = delete;
    CudaProcessor& operator=(const CudaProcessor&) = delete;

    // Input/output are interleaved 8-bit BGR frames.
    // contrast=1.0 and brightness=0.0 gives an identity-like pass.
    bool processBgr(const std::uint8_t* input,
                    std::uint8_t* output,
                    int width,
                    int height,
                    float contrast = 1.15f,
                    float brightness = 0.0f);

    const char* lastError() const;

private:
    bool ensureCapacity(std::size_t bytes);

    std::uint8_t* d_input_{nullptr};
    std::uint8_t* d_output_{nullptr};
    std::size_t capacity_{0};
    char error_[512]{};
};
