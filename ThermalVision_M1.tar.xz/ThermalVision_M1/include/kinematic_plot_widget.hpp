#pragma once

#include "geospatial_types.hpp"
#include <QWidget>
#include <vector>

class KinematicPlotWidget : public QWidget {
    Q_OBJECT
public:
    explicit KinematicPlotWidget(QWidget* parent = nullptr);
    ~KinematicPlotWidget() override = default;

    void updateData(const KinematicState& state, const std::vector<TrajectoryPoint3D>& history);
    void reset();

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    KinematicState currentState_;
    std::vector<TrajectoryPoint3D> history_;
    std::vector<double> speedHistory_;
    std::vector<double> climbHistory_;
    std::vector<double> rangeHistory_;
};
