#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <thread>
#include <opencv2/core.hpp>

class RtspCapture {
public:
    RtspCapture() = default;
    ~RtspCapture();

    bool start(const std::string& url);
    void stop();
    bool latestFrame(cv::Mat& frame);
    std::string errorMessage() const;
    bool isRunning() const { return running_.load(); }

private:
    void captureLoop(std::string url);

    std::atomic<bool> running_{false};
    std::thread worker_;
    mutable std::mutex mutex_;
    cv::Mat latest_;
    std::string error_;
};
