#pragma once

#include <opencv2/core.hpp>
#include <opencv2/video/tracking.hpp>
#include <vector>
#include <string>

struct Detection {
    cv::Rect bbox;
    cv::Point2f centroid;
    float area;
    float peakIntensity;
};

struct TrackedTarget {
    int id{0};
    cv::Rect bbox;
    cv::Point2f centroid;
    cv::Point2f velocity{0.0f, 0.0f};
    std::vector<cv::Point2f> trajectory;
    int age{0};
    int lostFrames{0};
    bool locked{false};
    float azimuthDeg{0.0f};
    float elevationDeg{0.0f};
    float speedPxSec{0.0f};
    std::string classification{"WEATHER BALLOON"};
    cv::KalmanFilter kalman;
};

class TargetDetector {
public:
    TargetDetector();
    std::vector<Detection> detect(const cv::Mat& bgrFrame);

    void setMinArea(float area) { minArea_ = area; }
    void setMaxArea(float area) { maxArea_ = area; }
    void setThreshold(double thresh) { thresholdValue_ = thresh; }

    const cv::Mat& debugMask() const { return debugMask_; }

private:
    float minArea_{12.0f};
    float maxArea_{4000.0f};
    double thresholdValue_{28.0};
    cv::Mat morphKernel_;
    cv::Mat debugMask_;
};

class TargetTracker {
public:
    TargetTracker();

    void update(const std::vector<Detection>& detections, float dt = 1.0f / 24.0f);
    void reset();

    const std::vector<TrackedTarget>& targets() const { return tracks_; }

    void drawOverlay(cv::Mat& bgrFrame,
                     bool showBbox = true,
                     bool showTrajectory = true,
                     bool showHud = true);

private:
    int nextId_{1};
    int maxLostFrames_{12};
    float matchDistanceThreshold_{85.0f};
    std::vector<TrackedTarget> tracks_;

    void initKalman(TrackedTarget& target, const cv::Point2f& initPos);
};
