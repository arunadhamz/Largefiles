# ThermalVision M1 synthetic input pack

Files:
- synthetic_clouds_only_1280x1024_h264.mp4
- synthetic_clouds_weather_balloon_1280x1024_h264.mp4
- generate_synthetic_clouds.py

Both videos are 1280x1024, 24 FPS, H.264, 8 seconds.

These are procedurally generated monochrome thermal-style test images. They are
not captured by a thermal camera, are not radiometrically calibrated, and do
not represent real atmospheric measurements.

After building ThermalVision M1, run either clip directly:

```bash
./build/thermalvision ./datasets/input/synthetic_clouds_only_1280x1024_h264.mp4
./build/thermalvision ./datasets/input/synthetic_clouds_weather_balloon_1280x1024_h264.mp4
```

For a standalone GStreamer decode test:

```bash
gst-launch-1.0 -v   filesrc location=./datasets/input/synthetic_clouds_weather_balloon_1280x1024_h264.mp4 !   qtdemux ! h264parse ! avdec_h264 ! videoconvert !   video/x-raw,format=BGR ! fakesink sync=false
```

If `avdec_h264` is unavailable, install the GStreamer libav plugin package.
