#!/usr/bin/env python3
"""Generate synthetic monochrome thermal-style cloud test clips.
Requires: Python 3, numpy, opencv-python, ffmpeg with libx264.
These are illustrative synthetic images, not calibrated thermal measurements.
"""
import cv2, numpy as np, subprocess, math, argparse

W, H, FPS, SECONDS = 1280, 1024, 24, 8
def field(seed, h, w):
    return np.random.default_rng(seed).random((h, w), dtype=np.float32)

def cloud_frame(t, rng):
    layers = []
    for f, weight, sx, sy in [
        (field(11,5,7),.48,.35,.60), (field(22,9,13),.25,.65,.85),
        (field(33,18,25),.17,1.10,1.20), (field(44,36,50),.10,1.65,1.70)]:
        sh, sw = f.shape
        f = np.roll(np.roll(f, int(t*sx*sw*.32)%sw, 1),
                    int(t*sy*sh*.18)%sh, 0)
        layers.append((cv2.resize(f,(W,H),interpolation=cv2.INTER_CUBIC)-.5)*weight)
    n = cv2.GaussianBlur(sum(layers), (0,0), 5.0)
    yy, xx = np.mgrid[0:H,0:W].astype(np.float32)
    n += .12*np.sin(yy/H*2.8+t*.10+.5*np.sin(xx/W*4.0))
    lo, hi = np.percentile(n,8), np.percentile(n,98)
    z = np.clip((n-lo)/(hi-lo+1e-6),0,1)**.82
    return np.clip(18+205*z+rng.normal(0,1.8,(H,W)),0,255).astype(np.uint8)

def balloon_frame(gray, t):
    frame = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    cx = int(W*(.24+.48*t/SECONDS)); cy = int(H*(.42+.035*math.sin(t*.7)))
    glow = np.zeros((H,W),np.uint8)
    cv2.circle(glow,(cx,cy),34,70,-1,cv2.LINE_AA)
    glow = cv2.GaussianBlur(glow,(0,0),18)
    frame = cv2.add(frame,cv2.cvtColor(glow,cv2.COLOR_GRAY2BGR))
    cv2.ellipse(frame,(cx,cy),(13,19),-8,0,360,(248,248,248),-1,cv2.LINE_AA)
    cv2.ellipse(frame,(cx,cy),(13,19),-8,0,360,(190,190,190),1,cv2.LINE_AA)
    cv2.line(frame,(cx-7,cy+15),(cx+7,cy+15),(100,100,100),1,cv2.LINE_AA)
    cv2.line(frame,(cx,cy+19),(cx+2,cy+39),(225,225,225),1,cv2.LINE_AA)
    cv2.rectangle(frame,(cx-3,cy+39),(cx+4,cy+46),(235,235,235),-1)
    return frame

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--output",default="synthetic_clouds_weather_balloon.mp4")
    ap.add_argument("--clouds-only",action="store_true")
    a=ap.parse_args()
    cmd=["ffmpeg","-y","-loglevel","error","-f","rawvideo","-pix_fmt","bgr24",
         "-s",f"{W}x{H}","-r",str(FPS),"-i","-","-an","-c:v","libx264",
         "-preset","veryfast","-crf","20","-pix_fmt","yuv420p","-movflags","+faststart",a.output]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE); rng=np.random.default_rng(20261105)
    try:
        for i in range(FPS*SECONDS):
            t=i/FPS; g=cloud_frame(t,rng)
            bgr=cv2.cvtColor(g,cv2.COLOR_GRAY2BGR) if a.clouds_only else balloon_frame(g,t)
            p.stdin.write(bgr.tobytes())
    finally: p.stdin.close()
    raise SystemExit(p.wait())
if __name__=="__main__": main()
