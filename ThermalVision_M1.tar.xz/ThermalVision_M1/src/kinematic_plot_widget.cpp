#include "kinematic_plot_widget.hpp"

#include <QPainter>
#include <QPaintEvent>
#include <QLinearGradient>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <sstream>

KinematicPlotWidget::KinematicPlotWidget(QWidget* parent) : QWidget(parent) {
    setMinimumSize(420, 360);
    setStyleSheet("background: #080c10;");
}

void KinematicPlotWidget::reset() {
    history_.clear();
    speedHistory_.clear();
    climbHistory_.clear();
    rangeHistory_.clear();
    update();
}

void KinematicPlotWidget::updateData(const KinematicState& state, const std::vector<TrajectoryPoint3D>& history) {
    currentState_ = state;
    history_ = history;

    if (state.hasValidSolution) {
        speedHistory_.push_back(state.speedTotal);
        climbHistory_.push_back(state.climbRate);
        rangeHistory_.push_back(state.rangeMeters / 1000.0);

        if (speedHistory_.size() > 120) {
            speedHistory_.erase(speedHistory_.begin());
            climbHistory_.erase(climbHistory_.begin());
            rangeHistory_.erase(rangeHistory_.begin());
        }
    }
    update();
}

void KinematicPlotWidget::paintEvent(QPaintEvent* /*event*/) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.setRenderHint(QPainter::TextAntialiasing, true);

    const int w = width();
    const int h = height();

    // Dark sleek background
    p.fillRect(0, 0, w, h, QColor(9, 14, 20));

    const int padLeft = 60;
    const int padRight = 20;
    const int padTop = 32;
    const int padBot = 28;
    const int gap = 16;

    const int plotH = (h - padTop - padBot - gap) / 2;
    const int plotW = w - padLeft - padRight;

    if (plotW < 50 || plotH < 40) return;

    // ─────────────────────────────────────────────────────────────
    // GRAPH 1: ALTITUDE PROFILE Z(t) [METERS ASL]
    // ─────────────────────────────────────────────────────────────
    const QRect rect1(padLeft, padTop, plotW, plotH);
    p.fillRect(rect1, QColor(14, 20, 28));
    p.setPen(QPen(QColor(25, 45, 65), 1));
    p.drawRect(rect1);

    // Title 1
    p.setPen(QColor(0, 240, 255));
    p.setFont(QFont("Monospace", 8, QFont::Bold));
    p.drawText(padLeft, padTop - 10, "📈 ALTITUDE PROFILE Z(t) [METERS ASL]");

    // Current Altitude Tag
    const QString altTag = QString("CUR: %1 m (%2 ft)")
                               .arg(static_cast<int>(currentState_.upMeters))
                               .arg(static_cast<int>(currentState_.upMeters * 3.28084));
    p.setPen(QColor(0, 255, 180));
    p.drawText(padLeft + plotW - 170, padTop - 10, altTag);

    // Grid lines for Graph 1
    p.setPen(QPen(QColor(30, 50, 70, 100), 1, Qt::DotLine));
    for (int i = 1; i <= 3; ++i) {
        int gy = rect1.top() + (rect1.height() * i) / 4;
        p.drawLine(rect1.left(), gy, rect1.right(), gy);
    }

    if (!history_.empty()) {
        double maxAlt = 500.0;
        for (const auto& pt : history_) {
            maxAlt = std::max(maxAlt, pt.alt);
        }
        maxAlt = std::ceil(maxAlt / 250.0) * 250.0;

        // Y-axis labels
        p.setPen(QColor(100, 140, 180));
        p.setFont(QFont("Monospace", 7));
        p.drawText(8, rect1.top() + 10, QString("%1m").arg(static_cast<int>(maxAlt)));
        p.drawText(8, rect1.bottom() - 2, "0m");

        QPolygonF polyline;
        QPolygonF areaFill;
        areaFill << QPointF(rect1.left(), rect1.bottom());

        for (std::size_t i = 0; i < history_.size(); ++i) {
            const double fracX = static_cast<double>(i) / std::max(1.0, static_cast<double>(history_.size() - 1));
            const double px = rect1.left() + fracX * rect1.width();
            const double fracY = std::clamp(history_[i].alt / maxAlt, 0.0, 1.0);
            const double py = rect1.bottom() - fracY * rect1.height();
            polyline << QPointF(px, py);
            areaFill << QPointF(px, py);
        }
        areaFill << QPointF(rect1.right(), rect1.bottom());

        // Glowing gradient under altitude curve
        QLinearGradient grad(0, rect1.top(), 0, rect1.bottom());
        grad.setColorAt(0.0, QColor(0, 240, 255, 90));
        grad.setColorAt(1.0, QColor(0, 240, 255, 5));
        p.setBrush(grad);
        p.setPen(Qt::NoPen);
        p.drawPolygon(areaFill);

        // Curve stroke
        p.setPen(QPen(QColor(0, 240, 255), 2.2));
        p.drawPolyline(polyline);
    }

    // ─────────────────────────────────────────────────────────────
    // GRAPH 2: SPEED & CLIMB RATE V(t), Vz(t) [M/S]
    // ─────────────────────────────────────────────────────────────
    const int top2 = rect1.bottom() + gap + 18;
    const QRect rect2(padLeft, top2, plotW, plotH);
    p.fillRect(rect2, QColor(14, 20, 28));
    p.setPen(QPen(QColor(25, 45, 65), 1));
    p.drawRect(rect2);

    // Title 2
    p.setPen(QColor(255, 200, 0));
    p.setFont(QFont("Monospace", 8, QFont::Bold));
    p.drawText(padLeft, top2 - 10, "⚡ SPEED [m/s] (GOLD) vs CLIMB RATE Vz (GREEN)");

    const QString spdTag = QString("SPD: %1 m/s | Vz: %2 m/s")
                               .arg(currentState_.speedTotal, 0, 'f', 1)
                               .arg((currentState_.climbRate >= 0.0 ? "+" : "") + QString::number(currentState_.climbRate, 'f', 1));
    p.setPen(QColor(255, 220, 100));
    p.drawText(padLeft + plotW - 190, top2 - 10, spdTag);

    // Grid lines for Graph 2
    p.setPen(QPen(QColor(30, 50, 70, 100), 1, Qt::DotLine));
    for (int i = 1; i <= 3; ++i) {
        int gy = rect2.top() + (rect2.height() * i) / 4;
        p.drawLine(rect2.left(), gy, rect2.right(), gy);
    }

    if (speedHistory_.size() >= 2) {
        double maxSpeed = 30.0;
        for (double s : speedHistory_) maxSpeed = std::max(maxSpeed, s);
        maxSpeed = std::ceil(maxSpeed / 10.0) * 10.0;

        p.setPen(QColor(100, 140, 180));
        p.setFont(QFont("Monospace", 7));
        p.drawText(8, rect2.top() + 10, QString("%1m/s").arg(static_cast<int>(maxSpeed)));
        p.drawText(8, rect2.bottom() - 2, "0m/s");

        QPolygonF speedLine;
        QPolygonF climbLine;

        for (std::size_t i = 0; i < speedHistory_.size(); ++i) {
            const double fracX = static_cast<double>(i) / std::max(1.0, static_cast<double>(speedHistory_.size() - 1));
            const double px = rect2.left() + fracX * rect2.width();

            const double fracSpd = std::clamp(speedHistory_[i] / maxSpeed, 0.0, 1.0);
            const double pySpd = rect2.bottom() - fracSpd * rect2.height();
            speedLine << QPointF(px, pySpd);

            const double fracClimb = std::clamp(climbHistory_[i] / maxSpeed, 0.0, 1.0);
            const double pyClimb = rect2.bottom() - fracClimb * rect2.height();
            climbLine << QPointF(px, pyClimb);
        }

        // Draw Climb Rate in Green
        p.setPen(QPen(QColor(0, 255, 120), 1.8));
        p.drawPolyline(climbLine);

        // Draw Total Speed in Gold
        p.setPen(QPen(QColor(255, 200, 0), 2.2));
        p.drawPolyline(speedLine);
    }
}
