#include "main_window.hpp"
#include "geospatial_window.hpp"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QWidget>
#include <QPushButton>
#include <QImage>
#include <QPixmap>
#include <QDateTime>
#include <QKeyEvent>
#include <opencv2/imgproc.hpp>
#include <sstream>
#include <iomanip>

MainWindow::MainWindow(const QString& rtspUrl, QWidget* parent)
    : QMainWindow(parent), url_(rtspUrl) {
    setWindowTitle("ThermalVision — Aerial Target Detection & Tracking");
    resize(1200, 900);

    auto* central = new QWidget(this);
    central->setStyleSheet("background: #0f0f0f; color: #ffffff;");
    auto* rootLayout = new QVBoxLayout(central);
    rootLayout->setContentsMargins(10, 10, 10, 10);
    rootLayout->setSpacing(8);

    // Controls bar
    auto* controlsWidget = new QWidget(central);
    controlsWidget->setStyleSheet(
        "QCheckBox { color: #dddddd; font-size: 13px; spacing: 6px; } "
        "QCheckBox::indicator { width: 16px; height: 16px; } "
        "QLabel { color: #aaaaaa; font-size: 13px; font-weight: bold; } "
        "QComboBox { background: #222222; color: #00f0ff; border: 1px solid #444444; "
        "            border-radius: 4px; padding: 4px 10px; font-weight: bold; min-width: 220px; } "
        "QComboBox QAbstractItemView { background: #222222; color: #ffffff; selection-background-color: #0078d7; }"
    );
    auto* controlsLayout = new QHBoxLayout(controlsWidget);
    controlsLayout->setContentsMargins(0, 0, 0, 0);

    trackingCheckBox_ = new QCheckBox("Target Tracking [T]", controlsWidget);
    trackingCheckBox_->setChecked(true);
    trackingCheckBox_->setStyleSheet("color: #00f0ff; font-weight: bold;");

    trajectoryCheckBox_ = new QCheckBox("Trajectory Trail", controlsWidget);
    trajectoryCheckBox_->setChecked(true);

    cudaEnhanceCheckBox_ = new QCheckBox("CUDA Contrast [C]", controlsWidget);
    cudaEnhanceCheckBox_->setChecked(true);

    colormapComboBox_ = new QComboBox(controlsWidget);
    colormapComboBox_->addItem("1: White-Hot (Standard)");
    colormapComboBox_->addItem("2: Black-Hot (Inverted)");
    colormapComboBox_->addItem("3: Ironbow / Inferno");
    colormapComboBox_->addItem("4: Rainbow / Jet");
    colormapComboBox_->addItem("5: Hot Metal / Lava");

    controlsLayout->addWidget(trackingCheckBox_);
    controlsLayout->addWidget(trajectoryCheckBox_);
    controlsLayout->addWidget(cudaEnhanceCheckBox_);
    controlsLayout->addSpacing(15);
    controlsLayout->addWidget(new QLabel("Thermal Palette [1-5]:", controlsWidget));
    controlsLayout->addWidget(colormapComboBox_);
    controlsLayout->addSpacing(15);

    openGeospatialBtn_ = new QPushButton("🗺️ 2D Airspace & Kinematics [K]", controlsWidget);
    openGeospatialBtn_->setStyleSheet(
        "QPushButton { background: #00384d; color: #00f0ff; border: 1px solid #00a0cc; "
        "            border-radius: 4px; padding: 5px 12px; font-weight: bold; } "
        "QPushButton:hover { background: #00506e; color: #ffffff; }"
    );
    controlsLayout->addWidget(openGeospatialBtn_);
    controlsLayout->addStretch();

    rootLayout->addWidget(controlsWidget);

    // Video display
    videoLabel_ = new QLabel("Waiting for video stream...", central);
    videoLabel_->setAlignment(Qt::AlignCenter);
    videoLabel_->setMinimumSize(640, 480);
    videoLabel_->setStyleSheet("background:#080808; color:#00f0ff; font-family: monospace; border: 1px solid #222;");
    videoLabel_->setScaledContents(false);
    rootLayout->addWidget(videoLabel_, 1);

    // Target telemetry readout
    targetsLabel_ = new QLabel("TARGET ACQUISITION: INITIALIZING...", central);
    targetsLabel_->setStyleSheet("background:#151515; color:#00f0ff; padding: 6px 10px; font-family: monospace; font-size: 13px; border: 1px solid #333;");
    rootLayout->addWidget(targetsLabel_);

    // Pipeline status readout
    statusLabel_ = new QLabel("Starting GStreamer pipeline...", central);
    statusLabel_->setStyleSheet("background:#151515; color:#bbbbbb; padding: 6px 10px; font-family: monospace; font-size: 12px; border: 1px solid #2a2a2a;");
    rootLayout->addWidget(statusLabel_);

    setCentralWidget(central);

    geospatialWindow_ = new GeospatialWindow(nullptr);
    connect(openGeospatialBtn_, &QPushButton::clicked, this, [this]() {
        geospatialWindow_->show();
        geospatialWindow_->raise();
        geospatialWindow_->activateWindow();
    });

    capture_.start(url_.toStdString());

    connect(&timer_, &QTimer::timeout, this, &MainWindow::updateFrame);
    timer_.start(15);
    lastUpdate_ = std::chrono::steady_clock::now();
}

MainWindow::~MainWindow() {
    timer_.stop();
    capture_.stop();
    delete geospatialWindow_;
}

void MainWindow::keyPressEvent(QKeyEvent* event) {
    if (event->key() == Qt::Key_1) {
        colormapComboBox_->setCurrentIndex(0);
    } else if (event->key() == Qt::Key_2) {
        colormapComboBox_->setCurrentIndex(1);
    } else if (event->key() == Qt::Key_3) {
        colormapComboBox_->setCurrentIndex(2);
    } else if (event->key() == Qt::Key_4) {
        colormapComboBox_->setCurrentIndex(3);
    } else if (event->key() == Qt::Key_5) {
        colormapComboBox_->setCurrentIndex(4);
    } else if (event->key() == Qt::Key_T) {
        trackingCheckBox_->setChecked(!trackingCheckBox_->isChecked());
    } else if (event->key() == Qt::Key_C) {
        cudaEnhanceCheckBox_->setChecked(!cudaEnhanceCheckBox_->isChecked());
    } else if (event->key() == Qt::Key_K) {
        geospatialWindow_->show();
        geospatialWindow_->raise();
        geospatialWindow_->activateWindow();
    } else {
        QMainWindow::keyPressEvent(event);
    }
}

void MainWindow::updateFrame() {
    if (!capture_.latestFrame(input_)) {
        const std::string err = capture_.errorMessage();
        if (!err.empty()) {
            statusLabel_->setText(QString::fromStdString(err));
            videoLabel_->setText(QString::fromStdString(err));
        }
        return;
    }

    if (!input_.isContinuous()) input_ = input_.clone();

    const int width = input_.cols;
    const int height = input_.rows;
    output_.resize(static_cast<std::size_t>(width) * height * 3U);

    double cudaMs = 0.0;
    cv::Mat enhancedMat;

    if (cudaEnhanceCheckBox_->isChecked()) {
        const auto startCuda = std::chrono::steady_clock::now();
        const bool ok = processor_.processBgr(
            input_.ptr<std::uint8_t>(), output_.data(), width, height,
            1.20f, 0.0f);
        const auto endCuda = std::chrono::steady_clock::now();

        if (!ok) {
            statusLabel_->setText(QString("CUDA error: %1").arg(processor_.lastError()));
            return;
        }
        cudaMs = std::chrono::duration<double, std::milli>(endCuda - startCuda).count();
        enhancedMat = cv::Mat(height, width, CV_8UC3, output_.data());
    } else {
        enhancedMat = input_;
    }

    // Time delta for tracking
    const auto now = std::chrono::steady_clock::now();
    const double interval = std::chrono::duration<double>(now - lastUpdate_).count();
    if (interval > 0.0) displayedFps_ = 0.9 * displayedFps_ + 0.1 / interval;
    lastUpdate_ = now;
    const float dt = static_cast<float>(std::max(0.005, std::min(interval, 0.2)));

    // Target Detection & Tracking (ALWAYS run on pure thermal sensor data)
    double trackMs = 0.0;
    if (trackingCheckBox_->isChecked()) {
        const auto startTrack = std::chrono::steady_clock::now();
        const auto detections = detector_.detect(enhancedMat);
        tracker_.update(detections, dt);
        const auto endTrack = std::chrono::steady_clock::now();
        trackMs = std::chrono::duration<double, std::milli>(endTrack - startTrack).count();

        // Update target telemetry label
        const auto& targets = tracker_.targets();
        if (targets.empty()) {
            targetsLabel_->setText("TARGET ACQUISITION: SCANNING | ACTIVE TARGETS: 0");
        } else {
            std::ostringstream ss;
            ss << "TARGETS DETECTED: " << targets.size() << " | ";
            for (const auto& t : targets) {
                ss << "[ID #" << t.id << " "
                   << (t.lostFrames == 0 ? "LOCKED" : "COASTING")
                   << " (" << t.classification << ")"
                   << " AZ:" << (t.azimuthDeg >= 0 ? "+" : "") << std::fixed << std::setprecision(1) << t.azimuthDeg << "°"
                   << " EL:" << (t.elevationDeg >= 0 ? "+" : "") << std::fixed << std::setprecision(1) << t.elevationDeg << "°"
                   << " SPD:" << std::fixed << std::setprecision(1) << t.speedPxSec << " px/s] ";
            }
            targetsLabel_->setText(QString::fromStdString(ss.str()));

            if (geospatialWindow_) {
                geospatialWindow_->updateTargetTelemetry(targets.front(), dt);
            }
        }
    } else {
        targetsLabel_->setText("TARGET TRACKING: DISABLED");
    }

    // Prepare Display Frame with Selected Thermal Palette
    cv::Mat displayMat;
    cv::Mat gray;
    if (enhancedMat.channels() == 3) {
        cv::cvtColor(enhancedMat, gray, cv::COLOR_BGR2GRAY);
    } else {
        gray = enhancedMat.clone();
    }

    const int paletteIdx = colormapComboBox_->currentIndex();
    switch (paletteIdx) {
        case 1: { // Black-Hot (Inverted Monochrome)
            cv::bitwise_not(gray, gray);
            cv::cvtColor(gray, displayMat, cv::COLOR_GRAY2BGR);
            break;
        }
        case 2: { // Ironbow / Inferno
            cv::applyColorMap(gray, displayMat, cv::COLORMAP_INFERNO);
            break;
        }
        case 3: { // Rainbow / Jet
            cv::applyColorMap(gray, displayMat, cv::COLORMAP_JET);
            break;
        }
        case 4: { // Hot Metal / Lava
            cv::applyColorMap(gray, displayMat, cv::COLORMAP_HOT);
            break;
        }
        case 0: // White-Hot (Standard Monochrome)
        default: {
            if (enhancedMat.channels() == 3) {
                displayMat = enhancedMat.clone();
            } else {
                cv::cvtColor(gray, displayMat, cv::COLOR_GRAY2BGR);
            }
            break;
        }
    }

    // Draw Target HUD Overlay on top of the rendered palette
    if (trackingCheckBox_->isChecked()) {
        tracker_.drawOverlay(displayMat, true, trajectoryCheckBox_->isChecked(), true);
    }

    statusLabel_->setText(
        QString("Resolution: %1x%2 | CUDA: %3 ms | Tracking: %4 ms | FPS: %5 | Palette: %6")
            .arg(width)
            .arg(height)
            .arg(cudaMs, 0, 'f', 2)
            .arg(trackMs, 0, 'f', 2)
            .arg(displayedFps_, 0, 'f', 1)
            .arg(colormapComboBox_->currentText()));

    QImage image(displayMat.data, width, height, static_cast<int>(displayMat.step),
                 QImage::Format_BGR888);
    videoLabel_->setPixmap(QPixmap::fromImage(image.copy()).scaled(
        videoLabel_->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
}
