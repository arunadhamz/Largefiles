#include "geospatial_window.hpp"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QTabWidget>
#include <QDateTime>
#include <QScrollArea>
#include <sstream>
#include <iomanip>
#include <cmath>

namespace {
constexpr double PI = 3.14159265358979323846;
constexpr double DEG2RAD = PI / 180.0;
}

GeospatialWindow::GeospatialWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowTitle("ThermalVision — Advanced 2D Airspace & Kinematic Trajectory Mission Dashboard");
    resize(1440, 920);
    setupUi();
}

void GeospatialWindow::setupUi() {
    auto* central = new QWidget(this);
    central->setStyleSheet("background: #070b10; color: #ffffff; font-family: 'Segoe UI', Arial, sans-serif;");
    auto* rootLayout = new QVBoxLayout(central);
    rootLayout->setContentsMargins(12, 10, 12, 10);
    rootLayout->setSpacing(8);

    // ─────────────────────────────────────────────────────────────
    // 1. TOP MISSION CONTROL HEADER BAR
    // ─────────────────────────────────────────────────────────────
    auto* headerWidget = new QWidget(central);
    headerWidget->setStyleSheet("background: #0f1622; border: 1px solid #1a293d; border-radius: 6px; padding: 4px;");
    auto* headerLayout = new QHBoxLayout(headerWidget);
    headerLayout->setContentsMargins(10, 4, 10, 4);

    auto* titleLabel = new QLabel("🛰️ THERMALVISION | 2D AEROSPACE FLIGHT DYNAMICS & KINEMATICS", headerWidget);
    titleLabel->setStyleSheet("font-size: 14px; font-weight: bold; color: #00f0ff; letter-spacing: 1px;");
    headerLayout->addWidget(titleLabel);

    headerLayout->addStretch();

    missionStatusLabel_ = new QLabel("● SYSTEM READY | TRACKING ACTIVE", headerWidget);
    missionStatusLabel_->setStyleSheet("background: #0c281e; color: #00ff88; font-weight: bold; font-family: monospace; "
                                       "padding: 4px 10px; border-radius: 4px; border: 1px solid #00aa55; font-size: 11px;");
    headerLayout->addWidget(missionStatusLabel_);

    utcClockLabel_ = new QLabel(headerWidget);
    utcClockLabel_->setStyleSheet("font-family: monospace; font-size: 12px; color: #88c0d0; padding-left: 10px;");
    utcClockLabel_->setText(QDateTime::currentDateTimeUtc().toString("yyyy-MM-dd hh:mm:ss 'UTC'"));
    headerLayout->addWidget(utcClockLabel_);

    rootLayout->addWidget(headerWidget);

    // ─────────────────────────────────────────────────────────────
    // 2. MAIN SPLIT BODY (LEFT: 2D MAP & CONTROLS | RIGHT: ADVANCED TABS)
    // ─────────────────────────────────────────────────────────────
    auto* bodyWidget = new QWidget(central);
    auto* bodyLayout = new QHBoxLayout(bodyWidget);
    bodyLayout->setContentsMargins(0, 0, 0, 0);
    bodyLayout->setSpacing(10);

    // ── LEFT COLUMN: Map + Layer Toolbar ─────────────────────────
    auto* leftCol = new QWidget(bodyWidget);
    auto* leftLayout = new QVBoxLayout(leftCol);
    leftLayout->setContentsMargins(0, 0, 0, 0);
    leftLayout->setSpacing(6);

    // Map Quick Action Bar
    auto* mapToolBar = new QWidget(leftCol);
    mapToolBar->setStyleSheet("background: #0d141e; border: 1px solid #1a2838; border-radius: 4px;");
    auto* mapToolLayout = new QHBoxLayout(mapToolBar);
    mapToolLayout->setContentsMargins(8, 4, 8, 4);

    auto* focusTgtBtn = new QPushButton("🎯 Focus Target", mapToolBar);
    auto* focusBaseBtn = new QPushButton("📡 Focus Base", mapToolBar);
    auto* zoomInBtn = new QPushButton("➕ Zoom In", mapToolBar);
    auto* zoomOutBtn = new QPushButton("➖ Zoom Out", mapToolBar);
    auto* resetViewBtn = new QPushButton("⟲ Fit India", mapToolBar);

    const QString btnStyle = "QPushButton { background: #132232; color: #00e6ff; border: 1px solid #1d354d; "
                             "padding: 4px 10px; font-weight: bold; font-size: 11px; border-radius: 3px; } "
                             "QPushButton:hover { background: #1a3048; color: #ffffff; }";

    focusTgtBtn->setStyleSheet(btnStyle);
    focusBaseBtn->setStyleSheet(btnStyle);
    zoomInBtn->setStyleSheet(btnStyle);
    zoomOutBtn->setStyleSheet(btnStyle);
    resetViewBtn->setStyleSheet(btnStyle);

    connect(focusTgtBtn, &QPushButton::clicked, this, &GeospatialWindow::onFocusTargetClicked);
    connect(focusBaseBtn, &QPushButton::clicked, this, &GeospatialWindow::onFocusSensorClicked);
    connect(zoomInBtn, &QPushButton::clicked, this, &GeospatialWindow::onZoomInClicked);
    connect(zoomOutBtn, &QPushButton::clicked, this, &GeospatialWindow::onZoomOutClicked);
    connect(resetViewBtn, &QPushButton::clicked, this, &GeospatialWindow::onResetViewClicked);

    mapToolLayout->addWidget(focusTgtBtn);
    mapToolLayout->addWidget(focusBaseBtn);
    mapToolLayout->addSpacing(10);
    mapToolLayout->addWidget(zoomInBtn);
    mapToolLayout->addWidget(zoomOutBtn);
    mapToolLayout->addWidget(resetViewBtn);
    mapToolLayout->addStretch();

    stationCombo_ = new QComboBox(mapToolBar);
    stationCombo_->addItem("SDSC SHAR (Sriharikota) [13.72°N, 80.23°E]");
    stationCombo_->addItem("TERLS (Thumba / Trivandrum) [8.53°N, 76.87°E]");
    stationCombo_->addItem("ISTRAC Ground Station (Bengaluru) [13.03°N, 77.51°E]");
    stationCombo_->addItem("IMD Atmospheric Laboratory (Pune) [18.52°N, 73.85°E]");
    stationCombo_->addItem("IMD HQ Tracking Base (New Delhi) [28.61°N, 77.21°E]");
    stationCombo_->setStyleSheet("QComboBox { background: #14202c; color: #00f0ff; border: 1px solid #204060; "
                                "padding: 3px 8px; border-radius: 3px; font-weight: bold; font-size: 11px; } "
                                "QComboBox QAbstractItemView { background: #14202c; color: #ffffff; }");
    connect(stationCombo_, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &GeospatialWindow::onStationChanged);
    mapToolLayout->addWidget(new QLabel("Station:", mapToolBar));
    mapToolLayout->addWidget(stationCombo_);

    leftLayout->addWidget(mapToolBar);

    // 2D Map Canvas
    mapCanvas_ = new MapCanvas2D(leftCol);
    leftLayout->addWidget(mapCanvas_, 1);

    // Map Layer Toggles Bar
    auto* layerBar = new QWidget(leftCol);
    layerBar->setStyleSheet("background: #0d141e; border: 1px solid #1a2838; border-radius: 4px;");
    auto* layerLayout = new QHBoxLayout(layerBar);
    layerLayout->setContentsMargins(8, 4, 8, 4);

    const QString chkStyle = "QCheckBox { color: #cccccc; font-size: 11px; font-weight: bold; spacing: 5px; } "
                             "QCheckBox::indicator { width: 14px; height: 14px; }";

    chkRadar_ = new QCheckBox("Radar Rings", layerBar);
    chkRadar_->setChecked(true);
    chkRadar_->setStyleSheet(chkStyle);
    connect(chkRadar_, &QCheckBox::toggled, mapCanvas_, &MapCanvas2D::toggleRadarRings);

    chkTrajectory_ = new QCheckBox("Trajectory Trail", layerBar);
    chkTrajectory_->setChecked(true);
    chkTrajectory_->setStyleSheet(chkStyle);
    connect(chkTrajectory_, &QCheckBox::toggled, mapCanvas_, &MapCanvas2D::toggleTrajectory);

    chkGrid_ = new QCheckBox("Lat/Lon Grid", layerBar);
    chkGrid_->setChecked(true);
    chkGrid_->setStyleSheet(chkStyle);
    connect(chkGrid_, &QCheckBox::toggled, mapCanvas_, &MapCanvas2D::toggleGrid);

    chkStations_ = new QCheckBox("ISRO/IMD Stations", layerBar);
    chkStations_->setChecked(true);
    chkStations_->setStyleSheet(chkStyle);
    connect(chkStations_, &QCheckBox::toggled, mapCanvas_, &MapCanvas2D::toggleStations);

    chkLaunch_ = new QCheckBox("Launch Vector", layerBar);
    chkLaunch_->setChecked(true);
    chkLaunch_->setStyleSheet(chkStyle);
    connect(chkLaunch_, &QCheckBox::toggled, mapCanvas_, &MapCanvas2D::toggleLaunchOrigin);

    layerLayout->addWidget(new QLabel("Map Layers:", layerBar));
    layerLayout->addWidget(chkRadar_);
    layerLayout->addWidget(chkTrajectory_);
    layerLayout->addWidget(chkGrid_);
    layerLayout->addWidget(chkStations_);
    layerLayout->addWidget(chkLaunch_);
    layerLayout->addStretch();

    leftLayout->addWidget(layerBar);
    bodyLayout->addWidget(leftCol, 3);

    // ── RIGHT COLUMN: Advanced Tabbed Analysis Deck ──────────────
    auto* tabWidget = new QTabWidget(bodyWidget);
    tabWidget->setStyleSheet(
        "QTabWidget::pane { border: 1px solid #1a2838; background: #0c1218; border-radius: 4px; } "
        "QTabBar::tab { background: #101824; color: #88a0b8; padding: 8px 14px; font-weight: bold; "
        "              border: 1px solid #1a2838; border-bottom: none; border-top-left-radius: 4px; border-top-right-radius: 4px; margin-right: 2px; } "
        "QTabBar::tab:selected { background: #162436; color: #00f0ff; border-top: 2px solid #00f0ff; } "
        "QTabBar::tab:hover { color: #ffffff; }"
    );

    // ─────────────────────────────────────────────────────────────
    // TAB 1: LIVE TELEMETRY & GAUGES
    // ─────────────────────────────────────────────────────────────
    auto* tab1 = new QWidget();
    auto* tab1Layout = new QVBoxLayout(tab1);
    tab1Layout->setContentsMargins(12, 12, 12, 12);
    tab1Layout->setSpacing(10);

    // Target Identity Pod
    targetIdBadge_ = new QLabel("TARGET IDENTIFIER: #1 [WEATHER BALLOON / RADIOSONDE]", tab1);
    targetIdBadge_->setStyleSheet("background: #102436; color: #00f0ff; padding: 6px 12px; font-weight: bold; "
                                  "font-family: monospace; border: 1px solid #00a0cc; border-radius: 4px; font-size: 12px;");
    tab1Layout->addWidget(targetIdBadge_);

    // Geodetic Coordinates Pod
    auto* geoBox = new QGroupBox("GEODETIC POSITION & ALTITUDE", tab1);
    geoBox->setStyleSheet("QGroupBox { font-weight: bold; color: #00ff88; border: 1px solid #1a3828; margin-top: 8px; padding-top: 8px; border-radius: 4px; } "
                          "QGroupBox::title { subcontrol-origin: margin; left: 10px; }");
    auto* geoLayout = new QVBoxLayout(geoBox);

    positionLabel_ = new QLabel("Target Geodetic: --\nAltitude ASL: --", geoBox);
    positionLabel_->setStyleSheet("font-family: monospace; color: #e5e9f0; font-size: 12px; padding: 2px;");
    geoLayout->addWidget(positionLabel_);

    // Visual Altitude Bar
    auto* altBarLayout = new QHBoxLayout();
    altBarLayout->addWidget(new QLabel("Alt (0-10km):", geoBox));
    altitudeBar_ = new QProgressBar(geoBox);
    altitudeBar_->setRange(0, 10000);
    altitudeBar_->setValue(0);
    altitudeBar_->setTextVisible(true);
    altitudeBar_->setStyleSheet("QProgressBar { background: #141f2c; border: 1px solid #203548; height: 16px; border-radius: 3px; text-align: center; color: #ffffff; } "
                               "QProgressBar::chunk { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0088cc, stop:1 #00ff88); border-radius: 2px; }");
    altBarLayout->addWidget(altitudeBar_);
    geoLayout->addLayout(altBarLayout);

    tab1Layout->addWidget(geoBox);

    // Kinematic Velocity Pod
    auto* velBox = new QGroupBox("3D VELOCITY & DYNAMICS", tab1);
    velBox->setStyleSheet("QGroupBox { font-weight: bold; color: #ffd700; border: 1px solid #38301a; margin-top: 8px; padding-top: 8px; border-radius: 4px; } "
                          "QGroupBox::title { subcontrol-origin: margin; left: 10px; }");
    auto* velLayout = new QVBoxLayout(velBox);

    velocityLabel_ = new QLabel("Total Velocity: --\nClimb Rate (Vz): -- | Ground Speed: --", velBox);
    velocityLabel_->setStyleSheet("font-family: monospace; color: #ebcb8b; font-size: 12px; padding: 2px;");
    velLayout->addWidget(velocityLabel_);

    // Visual Speed Bar
    auto* spdBarLayout = new QHBoxLayout();
    spdBarLayout->addWidget(new QLabel("Speed (0-80m/s):", velBox));
    speedBar_ = new QProgressBar(velBox);
    speedBar_->setRange(0, 80);
    speedBar_->setValue(0);
    speedBar_->setTextVisible(true);
    speedBar_->setStyleSheet("QProgressBar { background: #141f2c; border: 1px solid #203548; height: 16px; border-radius: 3px; text-align: center; color: #ffffff; } "
                             "QProgressBar::chunk { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #e6a100, stop:1 #ff4400); border-radius: 2px; }");
    spdBarLayout->addWidget(speedBar_);
    velLayout->addLayout(spdBarLayout);

    anglesLabel_ = new QLabel("Flight Path Angle (γ): --\nHeading (ψ): --", velBox);
    anglesLabel_->setStyleSheet("font-family: monospace; color: #d8dee9; font-size: 12px; padding: 2px;");
    velLayout->addWidget(anglesLabel_);

    tab1Layout->addWidget(velBox);

    // Range & Tangent Coordinates Pod
    auto* rangeBox = new QGroupBox("PASSIVE RANGE & TANGENT PLANE (ENU)", tab1);
    rangeBox->setStyleSheet("QGroupBox { font-weight: bold; color: #88c0d0; border: 1px solid #1a2a38; margin-top: 8px; padding-top: 8px; border-radius: 4px; } "
                            "QGroupBox::title { subcontrol-origin: margin; left: 10px; }");
    auto* rangeLayout = new QVBoxLayout(rangeBox);

    rangeLabel_ = new QLabel("Passive Range: --\nTangent (ENU): [E: --, N: --, U: --]", rangeBox);
    rangeLabel_->setStyleSheet("font-family: monospace; color: #88c0d0; font-size: 12px; padding: 2px;");
    rangeLayout->addWidget(rangeLabel_);

    tab1Layout->addWidget(rangeBox);
    tab1Layout->addStretch();

    tabWidget->addTab(tab1, "📊 Live Telemetry");

    // ─────────────────────────────────────────────────────────────
    // TAB 2: LIVE ALTITUDE & SPEED PROFILER (CHARTS)
    // ─────────────────────────────────────────────────────────────
    auto* tab2 = new QWidget();
    auto* tab2Layout = new QVBoxLayout(tab2);
    tab2Layout->setContentsMargins(8, 8, 8, 8);
    plotWidget_ = new KinematicPlotWidget(tab2);
    tab2Layout->addWidget(plotWidget_);
    tabWidget->addTab(tab2, "📈 Kinematic Profiler");

    // ─────────────────────────────────────────────────────────────
    // TAB 3: ESTIMATED LAUNCH / ORIGIN POINT
    // ─────────────────────────────────────────────────────────────
    auto* tab3 = new QWidget();
    auto* tab3Layout = new QVBoxLayout(tab3);
    tab3Layout->setContentsMargins(12, 12, 12, 12);
    tab3Layout->setSpacing(12);

    auto* lTitle = new QLabel("AERODYNAMIC TRAJECTORY BACK-PROJECTION", tab3);
    lTitle->setStyleSheet("font-size: 13px; font-weight: bold; color: #ffd700;");
    tab3Layout->addWidget(lTitle);

    auto* lDesc = new QLabel(
        "By integrating the measured 3D wind drift vectors and vertical ascent rate, "
        "the flight trajectory is traced backwards to ground level (Z = 0) to estimate "
        "the launch site / release origin location.", tab3);
    lDesc->setWordWrap(true);
    lDesc->setStyleSheet("color: #bbbbbb; font-size: 12px;");
    tab3Layout->addWidget(lDesc);

    auto* lCard = new QGroupBox("LAUNCH SITE PARAMETERS", tab3);
    lCard->setStyleSheet("QGroupBox { font-weight: bold; color: #ffd700; border: 1px solid #38301a; margin-top: 8px; padding-top: 8px; border-radius: 4px; } "
                         "QGroupBox::title { subcontrol-origin: margin; left: 10px; }");
    auto* lCardLayout = new QVBoxLayout(lCard);

    launchCoordLabel_ = new QLabel("Origin Coordinates: --\nGround Elevation: 0 m ASL", lCard);
    launchCoordLabel_->setStyleSheet("font-family: monospace; color: #ffd700; font-size: 13px; font-weight: bold; padding: 4px;");
    lCardLayout->addWidget(launchCoordLabel_);

    launchDistanceLabel_ = new QLabel("Distance from Sensor Station: --", lCard);
    launchDistanceLabel_->setStyleSheet("font-family: monospace; color: #e5e9f0; font-size: 12px; padding: 4px;");
    lCardLayout->addWidget(launchDistanceLabel_);

    launchBearingLabel_ = new QLabel("Bearing from Sensor Station: --", lCard);
    launchBearingLabel_->setStyleSheet("font-family: monospace; color: #e5e9f0; font-size: 12px; padding: 4px;");
    lCardLayout->addWidget(launchBearingLabel_);

    tab3Layout->addWidget(lCard);
    tab3Layout->addStretch();
    tabWidget->addTab(tab3, "🎯 Launch Point");

    // ─────────────────────────────────────────────────────────────
    // TAB 4: MATHEMATICAL DERIVATION & PHYSICS ENGINE
    // ─────────────────────────────────────────────────────────────
    auto* tab4 = new QWidget();
    auto* tab4Layout = new QVBoxLayout(tab4);
    tab4Layout->setContentsMargins(8, 8, 8, 8);

    mathDerivationText_ = new QTextEdit(tab4);
    mathDerivationText_->setReadOnly(true);
    mathDerivationText_->setStyleSheet("background: #080c10; color: #a3be8c; border: 1px solid #1a2a3a; font-family: monospace; font-size: 11px;");
    mathDerivationText_->setPlainText(
        "=================================================================\n"
        "AEROSPACE PASSIVE RANGING & KINEMATIC TRAJECTORY DERIVATION\n"
        "=================================================================\n\n"
        "1. PASSIVE RANGING (SINGLE SENSOR ANGLE-ONLY FUSION):\n"
        "   Direct range R is unobservable from a single line-of-sight.\n"
        "   We fuse Stadiametric Ranging and Barometric Ascent Dynamics:\n\n"
        "   (A) Stadiametric Ranging:\n"
        "       R_stad = (D_envelope * f_pixels) / w_detected\n"
        "       where D_envelope = 2.4 m, f_pixels = 1758 px\n\n"
        "   (B) Barometric Climb Integration:\n"
        "       Z_altitude(t) = Z_altitude(t-dt) + V_z * dt\n"
        "       R_baro = (Z_altitude - Z_station) / sin(elevation)\n\n"
        "   (C) Fused Passive Range Solution:\n"
        "       R = 0.65 * R_stad + 0.35 * R_baro\n\n"
        "2. 3D LOCAL TANGENT PLANE (EAST-NORTH-UP) CARTESIAN PROJECTION:\n"
        "   Given Line-of-Sight Azimuth (θ) and Elevation (φ):\n"
        "       X_East  = R * cos(φ) * sin(θ)\n"
        "       Y_North = R * cos(φ) * cos(θ)\n"
        "       Z_Up    = R * sin(φ)\n\n"
        "3. KINEMATIC VELOCITY VECTOR DERIVATION:\n"
        "   Filtered time-derivatives of 3D trajectory state:\n"
        "       V_East  = dX_East / dt  (Eastward wind drift)\n"
        "       V_North = dY_North / dt (Northward wind drift)\n"
        "       V_Up    = dZ_Up / dt    (Vertical climb rate)\n"
        "       V_total = sqrt(V_East² + V_North² + V_Up²)\n"
        "       Flight Path Angle γ = atan2(V_Up, V_ground)\n"
        "       Ground Heading   ψ = atan2(V_East, V_North)\n\n"
        "4. LAUNCH / RELEASE ORIGIN ESTIMATION:\n"
        "   Back-projects the smooth ascent drift trajectory to Z = 0:\n"
        "       t_elapsed = Z_Up / V_Up\n"
        "       X_launch  = X_East - V_East * t_elapsed\n"
        "       Y_launch  = Y_North - V_North * t_elapsed\n"
        "   Maps [X_launch, Y_launch] back to WGS-84 Geodetic (Lat, Lon)."
    );
    tab4Layout->addWidget(mathDerivationText_);
    tabWidget->addTab(tab4, "📐 Math Derivation");

    bodyLayout->addWidget(tabWidget, 2);
    rootLayout->addWidget(bodyWidget);

    setCentralWidget(central);
}

void GeospatialWindow::onStationChanged(int index) {
    switch (index) {
        case 0:
            kinematicEngine_.setSensorLocation(13.7200, 80.2300, 18.0, "SDSC SHAR (Sriharikota)");
            break;
        case 1:
            kinematicEngine_.setSensorLocation(8.5300, 76.8700, 12.0, "TERLS (Thumba / Trivandrum)");
            break;
        case 2:
            kinematicEngine_.setSensorLocation(13.0300, 77.5100, 920.0, "ISTRAC Ground Station (Bengaluru)");
            break;
        case 3:
            kinematicEngine_.setSensorLocation(18.5200, 73.8500, 560.0, "IMD Atmospheric Lab (Pune)");
            break;
        case 4:
            kinematicEngine_.setSensorLocation(28.6100, 77.2100, 216.0, "IMD HQ Tracking Base (New Delhi)");
            break;
    }
    mapCanvas_->setSensorLocation(kinematicEngine_.sensorLocation(), kinematicEngine_.sensorName());
    if (plotWidget_) plotWidget_->reset();
}

void GeospatialWindow::onResetViewClicked() {
    mapCanvas_->resetView();
}

void GeospatialWindow::onFocusTargetClicked() {
    mapCanvas_->centerOnTarget();
}

void GeospatialWindow::onFocusSensorClicked() {
    mapCanvas_->centerOnSensor();
}

void GeospatialWindow::onZoomInClicked() {
    mapCanvas_->zoomIn();
}

void GeospatialWindow::onZoomOutClicked() {
    mapCanvas_->zoomOut();
}

void GeospatialWindow::updateTargetTelemetry(const TrackedTarget& target, double dt) {
    const double rawWidth = std::max(6, target.bbox.width);
    const KinematicState state = kinematicEngine_.process(
        target.azimuthDeg,
        target.elevationDeg,
        rawWidth,
        dt,
        true);

    mapCanvas_->updateKinematics(state, kinematicEngine_.trajectoryHistory());
    if (plotWidget_) {
        plotWidget_->updateData(state, kinematicEngine_.trajectoryHistory());
    }
    updateTelemetryCard(state);

    utcClockLabel_->setText(QDateTime::currentDateTimeUtc().toString("yyyy-MM-dd hh:mm:ss 'UTC'"));
}

void GeospatialWindow::updateTelemetryCard(const KinematicState& state) {
    if (!state.hasValidSolution) {
        missionStatusLabel_->setText("● SCANNING AIRSPACE | NO LOCK");
        missionStatusLabel_->setStyleSheet("background: #281414; color: #ff5555; padding: 4px 10px; font-weight: bold; border: 1px solid #aa2222;");
        return;
    }

    missionStatusLabel_->setText("● 3D KINEMATICS LOCKED | SENSOR: ACTIVE");
    missionStatusLabel_->setStyleSheet("background: #0c281e; color: #00ff88; padding: 4px 10px; font-weight: bold; border: 1px solid #00aa55;");

    positionLabel_->setText(
        QString("Target Geodetic: %1°N, %2°E\nAltitude ASL: %3 m (%4 ft)")
            .arg(state.targetGeo.lat, 0, 'f', 4)
            .arg(state.targetGeo.lon, 0, 'f', 4)
            .arg(static_cast<int>(std::round(state.upMeters)))
            .arg(static_cast<int>(std::round(state.upMeters * 3.28084)))
    );

    if (altitudeBar_) {
        altitudeBar_->setValue(std::clamp(static_cast<int>(state.upMeters), 0, 10000));
        altitudeBar_->setFormat(QString("%1 m").arg(static_cast<int>(state.upMeters)));
    }

    rangeLabel_->setText(
        QString("Passive Range: %1 km (%2 m)\nTangent (ENU): [E: %3 m, N: %4 m, U: %5 m]")
            .arg(state.rangeMeters / 1000.0, 0, 'f', 2)
            .arg(static_cast<int>(std::round(state.rangeMeters)))
            .arg((state.eastMeters >= 0 ? "+" : "") + QString::number(static_cast<int>(std::round(state.eastMeters))))
            .arg((state.northMeters >= 0 ? "+" : "") + QString::number(static_cast<int>(std::round(state.northMeters))))
            .arg((state.upMeters >= 0 ? "+" : "") + QString::number(static_cast<int>(std::round(state.upMeters))))
    );

    velocityLabel_->setText(
        QString("Total Velocity: %1 m/s (%2 km/h)\nClimb Rate (Vz): %3 m/s | Ground Speed: %4 m/s")
            .arg(state.speedTotal, 0, 'f', 1)
            .arg(state.speedTotal * 3.6, 0, 'f', 1)
            .arg((state.climbRate >= 0 ? "+" : "") + QString::number(state.climbRate, 'f', 1))
            .arg(state.speedGround, 0, 'f', 1)
    );

    if (speedBar_) {
        speedBar_->setValue(std::clamp(static_cast<int>(state.speedTotal), 0, 80));
        speedBar_->setFormat(QString("%1 m/s").arg(state.speedTotal, 0, 'f', 1));
    }

    anglesLabel_->setText(
        QString("Flight Path Angle (γ): %1°\nHeading (ψ): %2° (Track Bearing)")
            .arg((state.flightPathAngleDeg >= 0 ? "+" : "") + QString::number(state.flightPathAngleDeg, 'f', 1))
            .arg(state.headingDeg, 0, 'f', 1)
    );

    launchCoordLabel_->setText(
        QString("Origin Coordinates: %1°N, %2°E\nGround Elevation: 0 m ASL")
            .arg(state.estimatedLaunchGeo.lat, 0, 'f', 4)
            .arg(state.estimatedLaunchGeo.lon, 0, 'f', 4)
    );

    launchDistanceLabel_->setText(
        QString("Distance from Sensor Station: %1 km")
            .arg(state.launchDistanceKm, 0, 'f', 2)
    );

    // Compute bearing to launch origin from sensor station
    const double dLon = (state.estimatedLaunchGeo.lon - kinematicEngine_.sensorLocation().lon) * DEG2RAD;
    const double y = std::sin(dLon) * std::cos(state.estimatedLaunchGeo.lat * DEG2RAD);
    const double x = std::cos(kinematicEngine_.sensorLocation().lat * DEG2RAD) * std::sin(state.estimatedLaunchGeo.lat * DEG2RAD) -
                     std::sin(kinematicEngine_.sensorLocation().lat * DEG2RAD) * std::cos(state.estimatedLaunchGeo.lat * DEG2RAD) * std::cos(dLon);
    double bearing = std::atan2(y, x) * (180.0 / PI);
    if (bearing < 0.0) bearing += 360.0;

    launchBearingLabel_->setText(
        QString("Bearing from Sensor Station: %1°").arg(bearing, 0, 'f', 1)
    );
}
