#include "target_tracker.hpp"

#include <opencv2/imgproc.hpp>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <algorithm>

TargetDetector::TargetDetector() {
    // 17x17 elliptical kernel for morphological top-hat
    // Effectively suppresses large cloud gradients while preserving localized aerial targets
    morphKernel_ = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(17, 17));
}

std::vector<Detection> TargetDetector::detect(const cv::Mat& bgrFrame) {
    std::vector<Detection> detections;
    if (bgrFrame.empty()) return detections;

    cv::Mat gray;
    if (bgrFrame.channels() == 3) {
        cv::cvtColor(bgrFrame, gray, cv::COLOR_BGR2GRAY);
    } else {
        gray = bgrFrame;
    }

    // Morphological White Top-Hat: isolation of localized bright thermal anomalies
    cv::Mat topHat;
    cv::morphologyEx(gray, topHat, cv::MORPH_TOPHAT, morphKernel_);

    // Threshold high-frequency thermal highlights
    cv::Mat thresh;
    cv::threshold(topHat, thresh, thresholdValue_, 255.0, cv::THRESH_BINARY);

    // Consolidate candidate region
    cv::Mat closeKernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5));
    cv::morphologyEx(thresh, thresh, cv::MORPH_CLOSE, closeKernel);
    debugMask_ = thresh;

    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(thresh, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    for (const auto& contour : contours) {
        const double area = cv::contourArea(contour);
        if (area < minArea_ || area > maxArea_) continue;

        const cv::Rect r = cv::boundingRect(contour);
        const float aspectRatio = static_cast<float>(r.width) / static_cast<float>(r.height);
        if (aspectRatio < 0.15f || aspectRatio > 6.5f) continue;

        cv::Moments m = cv::moments(contour);
        cv::Point2f centroid;
        if (m.m00 > 1e-4) {
            centroid = cv::Point2f(static_cast<float>(m.m10 / m.m00),
                                  static_cast<float>(m.m01 / m.m00));
        } else {
            centroid = cv::Point2f(r.x + r.width * 0.5f, r.y + r.height * 0.5f);
        }

        double minVal = 0.0, maxVal = 0.0;
        cv::minMaxLoc(gray(r), &minVal, &maxVal);

        Detection det;
        det.bbox = r;
        det.centroid = centroid;
        det.area = static_cast<float>(area);
        det.peakIntensity = static_cast<float>(maxVal);
        detections.push_back(det);
    }

    return detections;
}

TargetTracker::TargetTracker() = default;

void TargetTracker::reset() {
    tracks_.clear();
    nextId_ = 1;
}

void TargetTracker::initKalman(TrackedTarget& target, const cv::Point2f& initPos) {
    target.kalman.init(4, 2, 0, CV_32F);

    target.kalman.transitionMatrix = (cv::Mat_<float>(4, 4) <<
        1, 0, 1.0f / 24.0f, 0,
        0, 1, 0, 1.0f / 24.0f,
        0, 0, 1, 0,
        0, 0, 0, 1);

    target.kalman.measurementMatrix = (cv::Mat_<float>(2, 4) <<
        1, 0, 0, 0,
        0, 1, 0, 0);

    cv::setIdentity(target.kalman.processNoiseCov, cv::Scalar::all(1e-2));
    cv::setIdentity(target.kalman.measurementNoiseCov, cv::Scalar::all(1e-1));
    cv::setIdentity(target.kalman.errorCovPost, cv::Scalar::all(1.0));

    target.kalman.statePost.at<float>(0) = initPos.x;
    target.kalman.statePost.at<float>(1) = initPos.y;
    target.kalman.statePost.at<float>(2) = 0.0f;
    target.kalman.statePost.at<float>(3) = 0.0f;
}

void TargetTracker::update(const std::vector<Detection>& detections, float dt) {
    // 1. Predict next state for existing tracks
    for (auto& track : tracks_) {
        track.kalman.transitionMatrix.at<float>(0, 2) = dt;
        track.kalman.transitionMatrix.at<float>(1, 3) = dt;

        cv::Mat pred = track.kalman.predict();
        track.centroid.x = pred.at<float>(0);
        track.centroid.y = pred.at<float>(1);
        track.velocity.x = pred.at<float>(2);
        track.velocity.y = pred.at<float>(3);
    }

    std::vector<bool> detMatched(detections.size(), false);

    // 2. Nearest-neighbor data association
    for (std::size_t i = 0; i < tracks_.size(); ++i) {
        float bestDist = matchDistanceThreshold_;
        int bestDetIdx = -1;

        for (std::size_t j = 0; j < detections.size(); ++j) {
            if (detMatched[j]) continue;

            const float dx = tracks_[i].centroid.x - detections[j].centroid.x;
            const float dy = tracks_[i].centroid.y - detections[j].centroid.y;
            const float dist = std::sqrt(dx * dx + dy * dy);

            if (dist < bestDist) {
                bestDist = dist;
                bestDetIdx = static_cast<int>(j);
            }
        }

        if (bestDetIdx >= 0) {
            detMatched[bestDetIdx] = true;

            cv::Mat measurement = (cv::Mat_<float>(2, 1) <<
                detections[bestDetIdx].centroid.x,
                detections[bestDetIdx].centroid.y);
            cv::Mat corrected = tracks_[i].kalman.correct(measurement);

            tracks_[i].centroid.x = corrected.at<float>(0);
            tracks_[i].centroid.y = corrected.at<float>(1);
            tracks_[i].velocity.x = corrected.at<float>(2);
            tracks_[i].velocity.y = corrected.at<float>(3);
            tracks_[i].bbox = detections[bestDetIdx].bbox;

            tracks_[i].trajectory.push_back(tracks_[i].centroid);
            if (tracks_[i].trajectory.size() > 60) {
                tracks_[i].trajectory.erase(tracks_[i].trajectory.begin());
            }

            tracks_[i].age++;
            tracks_[i].lostFrames = 0;
            if (tracks_[i].age >= 2) tracks_[i].locked = true;
        } else {
            // Coasting
            tracks_[i].lostFrames++;
            tracks_[i].trajectory.push_back(tracks_[i].centroid);
            if (tracks_[i].trajectory.size() > 60) {
                tracks_[i].trajectory.erase(tracks_[i].trajectory.begin());
            }
        }

        // Calculate speed, azimuth and elevation
        tracks_[i].speedPxSec = std::sqrt(tracks_[i].velocity.x * tracks_[i].velocity.x +
                                          tracks_[i].velocity.y * tracks_[i].velocity.y);

        // Assume standard optical FOV (HFOV = 40.0 deg, VFOV = 32.0 deg for 1280x1024)
        constexpr float hfov = 40.0f;
        constexpr float vfov = 32.0f;
        constexpr float cx0 = 1280.0f / 2.0f;
        constexpr float cy0 = 1024.0f / 2.0f;

        tracks_[i].azimuthDeg = ((tracks_[i].centroid.x - cx0) / cx0) * (hfov * 0.5f);
        tracks_[i].elevationDeg = -((tracks_[i].centroid.y - cy0) / cy0) * (vfov * 0.5f);

        // Target classification based on speed, aspect ratio, and vertical climb
        const float area = static_cast<float>(tracks_[i].bbox.width * tracks_[i].bbox.height);
        const float aspect = static_cast<float>(tracks_[i].bbox.width) /
                             static_cast<float>(std::max(1, tracks_[i].bbox.height));

        if (tracks_[i].speedPxSec > 130.0f || (tracks_[i].speedPxSec > 55.0f && tracks_[i].velocity.y < -25.0f)) {
            tracks_[i].classification = "ROCKET / MISSILE";
        } else if (aspect >= 0.40f && aspect <= 1.85f && area >= 25.0f && area <= 3500.0f) {
            tracks_[i].classification = "WEATHER BALLOON";
        } else if (tracks_[i].speedPxSec > 95.0f || aspect > 2.6f) {
            tracks_[i].classification = "AIRCRAFT / UAV";
        } else if (area < 25.0f) {
            tracks_[i].classification = "POINT SOURCE";
        } else {
            tracks_[i].classification = "AERIAL TARGET";
        }
    }

    // 3. Remove stale tracks
    tracks_.erase(
        std::remove_if(tracks_.begin(), tracks_.end(),
                       [this](const TrackedTarget& t) {
                           return t.lostFrames > maxLostFrames_;
                       }),
        tracks_.end());

    // 4. Initialize new tracks
    for (std::size_t j = 0; j < detections.size(); ++j) {
        if (!detMatched[j]) {
            TrackedTarget newTrack;
            newTrack.id = nextId_++;
            newTrack.bbox = detections[j].bbox;
            newTrack.centroid = detections[j].centroid;
            newTrack.age = 1;
            newTrack.lostFrames = 0;
            newTrack.locked = false;
            newTrack.trajectory.push_back(detections[j].centroid);
            newTrack.classification = "WEATHER BALLOON";
            initKalman(newTrack, detections[j].centroid);
            tracks_.push_back(newTrack);
        }
    }
}

void TargetTracker::drawOverlay(cv::Mat& frame,
                                bool showBbox,
                                bool showTrajectory,
                                bool showHud) {
    if (frame.empty()) return;

    // Draw central optical boresight reference
    const int midX = frame.cols / 2;
    const int midY = frame.rows / 2;
    const cv::Scalar boresightColor(80, 80, 80);
    cv::line(frame, cv::Point(midX - 14, midY), cv::Point(midX + 14, midY), boresightColor, 1, cv::LINE_AA);
    cv::line(frame, cv::Point(midX, midY - 14), cv::Point(midX, midY + 14), boresightColor, 1, cv::LINE_AA);
    cv::circle(frame, cv::Point(midX, midY), 4, boresightColor, 1, cv::LINE_AA);
    cv::putText(frame, "OPTICAL AXIS [0.0 deg, 0.0 deg]", cv::Point(midX + 18, midY - 6),
                cv::FONT_HERSHEY_SIMPLEX, 0.38, boresightColor, 1, cv::LINE_AA);

    for (const auto& track : tracks_) {
        // Flight trajectory trail
        if (showTrajectory && track.trajectory.size() >= 2) {
            for (std::size_t i = 1; i < track.trajectory.size(); ++i) {
                const float alpha = static_cast<float>(i) / static_cast<float>(track.trajectory.size());
                const int thickness = (alpha > 0.6f) ? 2 : 1;
                const cv::Scalar trailColor(static_cast<int>(255 * (1.0f - alpha)),
                                            static_cast<int>(220 * alpha + 35),
                                            static_cast<int>(255 * alpha));
                cv::line(frame, track.trajectory[i - 1], track.trajectory[i], trailColor, thickness, cv::LINE_AA);
            }
        }

        if (showBbox) {
            // Theme: Bright Cyan (#00F0FF) for locked track, Bright Amber (#FFB000) for coasting
            const cv::Scalar themeColor = (track.lostFrames == 0) ? cv::Scalar(255, 240, 0)   // BGR: Cyan
                                                                  : cv::Scalar(0, 176, 255);  // BGR: Amber
            const cv::Scalar textColor(245, 245, 245);

            // Symmetrical TARGET SQUARE centered on object
            const int rawSide = std::max(track.bbox.width, track.bbox.height);
            const int side = std::max(52, rawSide + 20);
            const int cx = static_cast<int>(std::round(track.centroid.x));
            const int cy = static_cast<int>(std::round(track.centroid.y));

            const int sqX = std::max(0, std::min(frame.cols - side - 1, cx - side / 2));
            const int sqY = std::max(0, std::min(frame.rows - side - 1, cy - side / 2));
            const cv::Rect targetSquare(sqX, sqY, side, side);

            // Draw target square boundary
            cv::rectangle(frame, targetSquare, themeColor, 2, cv::LINE_AA);

            // Corner reticle accents on square
            const int corner = 10;
            cv::line(frame, cv::Point(sqX, sqY), cv::Point(sqX + corner, sqY), cv::Scalar(255, 255, 255), 2);
            cv::line(frame, cv::Point(sqX, sqY), cv::Point(sqX, sqY + corner), cv::Scalar(255, 255, 255), 2);
            cv::line(frame, cv::Point(sqX + side, sqY), cv::Point(sqX + side - corner, sqY), cv::Scalar(255, 255, 255), 2);
            cv::line(frame, cv::Point(sqX + side, sqY), cv::Point(sqX + side, sqY + corner), cv::Scalar(255, 255, 255), 2);
            cv::line(frame, cv::Point(sqX, sqY + side), cv::Point(sqX + corner, sqY + side), cv::Scalar(255, 255, 255), 2);
            cv::line(frame, cv::Point(sqX, sqY + side), cv::Point(sqX, sqY + side - corner), cv::Scalar(255, 255, 255), 2);
            cv::line(frame, cv::Point(sqX + side, sqY + side), cv::Point(sqX + side - corner, sqY + side), cv::Scalar(255, 255, 255), 2);
            cv::line(frame, cv::Point(sqX + side, sqY + side), cv::Point(sqX + side, sqY + side - corner), cv::Scalar(255, 255, 255), 2);

            // Centroid crosshair inside square
            cv::drawMarker(frame, cv::Point(cx, cy), themeColor, cv::MARKER_CROSS, 14, 1, cv::LINE_AA);

            if (showHud) {
                // Determine placement for the side telemetry block (Right vs Left)
                const int cardW = 230;
                const int cardH = 108;
                const bool placeRight = (sqX + side + 30 + cardW < frame.cols);

                int cardX = 0;
                int leaderStartX = 0;
                int leaderCornerX = 0;

                if (placeRight) {
                    leaderStartX = sqX + side;
                    leaderCornerX = leaderStartX + 20;
                    cardX = leaderCornerX + 6;
                } else {
                    leaderStartX = sqX;
                    leaderCornerX = leaderStartX - 20;
                    cardX = leaderCornerX - cardW - 6;
                }

                int cardY = std::max(10, std::min(frame.rows - cardH - 10, cy - cardH / 2));
                const int leaderY = cy;

                // Tactical Leader Line from target square to telemetry card
                cv::line(frame, cv::Point(leaderStartX, leaderY), cv::Point(leaderCornerX, cardY + 22), themeColor, 1, cv::LINE_AA);
                cv::circle(frame, cv::Point(leaderStartX, leaderY), 3, themeColor, cv::FILLED, cv::LINE_AA);

                // Side Telemetry Card Background
                const cv::Rect cardRect(cardX, cardY, cardW, cardH);
                cv::rectangle(frame, cardRect, cv::Scalar(15, 15, 15), cv::FILLED);
                cv::rectangle(frame, cardRect, themeColor, 1, cv::LINE_AA);

                // Header tag bar
                const cv::Rect headerRect(cardX, cardY, cardW, 20);
                cv::rectangle(frame, headerRect, themeColor, cv::FILLED);

                std::ostringstream hdr;
                hdr << "TARGET #" << track.id << "  ["
                    << (track.lostFrames == 0 ? "LOCKED" : "COASTING") << "]";
                cv::putText(frame, hdr.str(), cv::Point(cardX + 8, cardY + 15),
                            cv::FONT_HERSHEY_SIMPLEX, 0.44, cv::Scalar(10, 10, 10), 1, cv::LINE_AA);

                // Telemetry line entries
                std::ostringstream lClass, lAz, lEl, lSpd;

                lClass << "CLASS:  " << track.classification;

                lAz << "AZ:     "
                    << (track.azimuthDeg >= 0.0f ? "+" : "")
                    << std::fixed << std::setprecision(1) << track.azimuthDeg << " deg";

                lEl << "EL:     "
                    << (track.elevationDeg >= 0.0f ? "+" : "")
                    << std::fixed << std::setprecision(1) << track.elevationDeg << " deg";

                lSpd << "SPEED:  "
                     << std::fixed << std::setprecision(1) << track.speedPxSec << " px/s";

                const int tx = cardX + 10;
                cv::putText(frame, lClass.str(), cv::Point(tx, cardY + 38), cv::FONT_HERSHEY_SIMPLEX, 0.40, cv::Scalar(0, 255, 180), 1, cv::LINE_AA);
                cv::putText(frame, lAz.str(),    cv::Point(tx, cardY + 56), cv::FONT_HERSHEY_SIMPLEX, 0.40, textColor, 1, cv::LINE_AA);
                cv::putText(frame, lEl.str(),    cv::Point(tx, cardY + 74), cv::FONT_HERSHEY_SIMPLEX, 0.40, textColor, 1, cv::LINE_AA);
                cv::putText(frame, lSpd.str(),   cv::Point(tx, cardY + 92), cv::FONT_HERSHEY_SIMPLEX, 0.40, cv::Scalar(255, 230, 80), 1, cv::LINE_AA);
            }
        }
    }
}
