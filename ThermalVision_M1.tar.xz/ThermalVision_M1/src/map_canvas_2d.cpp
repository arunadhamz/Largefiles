#include "map_canvas_2d.hpp"

#include <QPainter>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QResizeEvent>
#include <QLinearGradient>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <sstream>

namespace {
constexpr double PI = 3.14159265358979323846;
constexpr double DEG2RAD = PI / 180.0;
// Calibrated geographic bounds for indian_map.jpg (724x1024)
constexpr double MAP_LAT_MAX = 37.2; // Northern Kashmir
constexpr double MAP_LAT_MIN = 6.8;  // South of Kanyakumari / Indian Ocean
constexpr double MAP_LON_MIN = 68.0; // Western Gujarat / Arabian Sea
constexpr double MAP_LON_MAX = 97.5; // Eastern Arunachal Pradesh
}

MapCanvas2D::MapCanvas2D(QWidget* parent) : QWidget(parent) {
    setMinimumSize(600, 500);
    setStyleSheet("background: #080c10;");
    setMouseTracking(true);
    loadMapImage();
}

void MapCanvas2D::loadMapImage() {
    const QStringList candidatePaths = {
        "datasets/input/indian_map.jpg",
        "../datasets/input/indian_map.jpg",
        "../../datasets/input/indian_map.jpg",
        "/home/arun/Documents/aerial_tracking/ThermalVision_M1_Synthetic_Test_Bundle/ThermalVision_M1/datasets/input/indian_map.jpg"
    };

    for (const auto& path : candidatePaths) {
        if (mapImage_.load(path)) {
            hasMapImage_ = true;
            break;
        }
    }
}

void MapCanvas2D::updateMapRect() {
    if (!hasMapImage_ || mapImage_.isNull()) {
        mapRect_ = rect();
        return;
    }

    const double imgAspect = static_cast<double>(mapImage_.width()) / static_cast<double>(mapImage_.height());
    const double viewAspect = static_cast<double>(width()) / static_cast<double>(height());

    double baseW = 0.0;
    double baseH = 0.0;

    if (viewAspect > imgAspect) {
        baseH = height() * 0.95;
        baseW = baseH * imgAspect;
    } else {
        baseW = width() * 0.95;
        baseH = baseW / imgAspect;
    }

    const double finalW = baseW * zoom_;
    const double finalH = baseH * zoom_;

    const double centerX = (width() * 0.5) + panOffset_.x();
    const double centerY = (height() * 0.5) + panOffset_.y();

    mapRect_ = QRectF(centerX - finalW * 0.5, centerY - finalH * 0.5, finalW, finalH);
}

void MapCanvas2D::resizeEvent(QResizeEvent* /*event*/) {
    updateMapRect();
}

void MapCanvas2D::setSensorLocation(const GeoPoint& geo, const std::string& name) {
    sensorGeo_ = geo;
    sensorName_ = name;
    update();
}

void MapCanvas2D::updateKinematics(const KinematicState& state, const std::vector<TrajectoryPoint3D>& history) {
    currentState_ = state;
    history_ = history;
    update();
}

void MapCanvas2D::resetView() {
    zoom_ = 1.0;
    panOffset_ = QPointF(0.0, 0.0);
    updateMapRect();
    update();
}

void MapCanvas2D::zoomIn() {
    zoom_ = std::min(12.0, zoom_ * 1.25);
    updateMapRect();
    update();
}

void MapCanvas2D::zoomOut() {
    zoom_ = std::max(0.5, zoom_ / 1.25);
    updateMapRect();
    update();
}

void MapCanvas2D::centerOnTarget() {
    if (!currentState_.hasValidSolution) return;
    zoom_ = std::max(2.5, zoom_);
    updateMapRect();
    const QPointF tgtScreen = geoToScreen(currentState_.targetGeo.lat, currentState_.targetGeo.lon);
    const QPointF center(width() * 0.5, height() * 0.5);
    panOffset_ += (center - tgtScreen);
    updateMapRect();
    update();
}

void MapCanvas2D::centerOnSensor() {
    zoom_ = std::max(2.0, zoom_);
    updateMapRect();
    const QPointF sensorScreen = geoToScreen(sensorGeo_.lat, sensorGeo_.lon);
    const QPointF center(width() * 0.5, height() * 0.5);
    panOffset_ += (center - sensorScreen);
    updateMapRect();
    update();
}

QPointF MapCanvas2D::geoToScreen(double lat, double lon) const {
    const double u = (lon - MAP_LON_MIN) / (MAP_LON_MAX - MAP_LON_MIN);
    const double v = (MAP_LAT_MAX - lat) / (MAP_LAT_MAX - MAP_LAT_MIN);
    return QPointF(mapRect_.left() + u * mapRect_.width(),
                   mapRect_.top() + v * mapRect_.height());
}

double MapCanvas2D::metersToPixels(double meters, double /*atLat*/) const {
    const double totalMetersLat = (MAP_LAT_MAX - MAP_LAT_MIN) * 111000.0;
    return (meters / totalMetersLat) * mapRect_.height();
}

void MapCanvas2D::paintEvent(QPaintEvent* /*event*/) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.setRenderHint(QPainter::TextAntialiasing, true);
    p.setRenderHint(QPainter::SmoothPixmapTransform, true);

    const int w = width();
    const int h = height();

    // 1. Dark Modern Background
    p.fillRect(0, 0, w, h, QColor(7, 11, 16));

    // 2. Render 2D Indian Map Image
    if (hasMapImage_) {
        p.drawImage(mapRect_, mapImage_);
        p.setPen(QPen(QColor(0, 220, 255, 140), 1.5));
        p.drawRect(mapRect_);
    } else {
        p.setPen(QColor(255, 100, 100));
        p.drawText(rect(), Qt::AlignCenter, "Map image (indian_map.jpg) not found in datasets/input/");
    }

    // 3. Coordinate Grid Lines & Labels
    if (showGrid_) {
        p.setPen(QPen(QColor(0, 220, 255, 45), 1, Qt::DotLine));
        p.setFont(QFont("Monospace", 8));

        for (double lat = 10.0; lat <= 35.0; lat += 5.0) {
            QPointF pStart = geoToScreen(lat, MAP_LON_MIN);
            QPointF pEnd = geoToScreen(lat, MAP_LON_MAX);
            p.drawLine(pStart, pEnd);

            p.setPen(QColor(0, 220, 255, 130));
            p.drawText(pStart + QPointF(6, -3), QString::number(static_cast<int>(lat)) + "°N");
            p.setPen(QPen(QColor(0, 220, 255, 45), 1, Qt::DotLine));
        }

        for (double lon = 70.0; lon <= 95.0; lon += 5.0) {
            QPointF pStart = geoToScreen(MAP_LAT_MAX, lon);
            QPointF pEnd = geoToScreen(MAP_LAT_MIN, lon);
            p.drawLine(pStart, pEnd);

            p.setPen(QColor(0, 220, 255, 130));
            p.drawText(pEnd + QPointF(-12, -6), QString::number(static_cast<int>(lon)) + "°E");
            p.setPen(QPen(QColor(0, 220, 255, 45), 1, Qt::DotLine));
        }
    }

    // 4. Ground Reference Stations in India
    if (showStations_) {
        const std::vector<std::tuple<std::string, double, double>> stations = {
            {"SDSC SHAR (Sriharikota)", 13.72, 80.23},
            {"TERLS (Thumba)", 8.53, 76.87},
            {"ISTRAC (Bengaluru)", 13.03, 77.51},
            {"IMD HQ (New Delhi)", 28.61, 77.21},
            {"IMD Pune", 18.52, 73.85}
        };

        for (const auto& st : stations) {
            QPointF pt = geoToScreen(std::get<1>(st), std::get<2>(st));
            if (mapRect_.contains(pt)) {
                p.setPen(Qt::NoPen);
                p.setBrush(QColor(0, 230, 255, 190));
                p.drawEllipse(pt, 3.5, 3.5);
                p.setPen(QColor(180, 235, 255, 210));
                p.drawText(pt + QPointF(6, 4), QString::fromStdString(std::get<0>(st)));
            }
        }
    }

    // 5. Active Sensor Station & Concentric Radar Rings
    QPointF sensorPt = geoToScreen(sensorGeo_.lat, sensorGeo_.lon);
    if (mapRect_.contains(sensorPt)) {
        if (showRadarRings_) {
            p.setBrush(Qt::NoBrush);
            p.setFont(QFont("Monospace", 7));
            for (double rKm : {25.0, 50.0, 100.0, 150.0}) {
                const double rPx = metersToPixels(rKm * 1000.0, sensorGeo_.lat);
                p.setPen(QPen(QColor(0, 255, 100, 70), 1, Qt::DashLine));
                p.drawEllipse(sensorPt, rPx, rPx);

                p.setPen(QColor(0, 255, 120, 160));
                p.drawText(sensorPt + QPointF(rPx + 3, 3), QString("%1 km").arg(static_cast<int>(rKm)));
            }
        }

        // Sensor Base Icon & Badge
        p.setPen(QPen(QColor(0, 255, 120), 2));
        p.setBrush(QColor(0, 255, 100, 230));
        p.drawEllipse(sensorPt, 5.0, 5.0);
        p.drawEllipse(sensorPt, 8.5, 8.5);

        p.setPen(QColor(0, 255, 120));
        p.setFont(QFont("Monospace", 9, QFont::Bold));
        p.drawText(sensorPt + QPointF(12, -4), QString("[BASE: %1]").arg(QString::fromStdString(sensorName_)));
    }

    // 6. Estimated Launch / Origin Point Marker
    if (showLaunchOrigin_ && currentState_.hasValidSolution) {
        QPointF launchPt = geoToScreen(currentState_.estimatedLaunchGeo.lat,
                                       currentState_.estimatedLaunchGeo.lon);
        if (mapRect_.contains(launchPt)) {
            p.setPen(QPen(QColor(255, 215, 0), 2));
            p.setBrush(QColor(255, 200, 0, 170));
            p.drawEllipse(launchPt, 6.0, 6.0);
            p.setBrush(Qt::NoBrush);
            p.drawEllipse(launchPt, 11.0, 11.0);
            p.drawEllipse(launchPt, 16.0, 16.0);

            // Connect sensor to launch site line
            p.setPen(QPen(QColor(255, 215, 0, 150), 1.5, Qt::DashLine));
            p.drawLine(sensorPt, launchPt);

            // Origin Label
            p.setPen(QColor(255, 220, 0));
            p.setFont(QFont("Monospace", 8, QFont::Bold));
            QString launchTxt = QString("ESTIMATED LAUNCH / ORIGIN\n%1°N, %2°E\nDist: %3 km")
                                    .arg(currentState_.estimatedLaunchGeo.lat, 0, 'f', 3)
                                    .arg(currentState_.estimatedLaunchGeo.lon, 0, 'f', 3)
                                    .arg(currentState_.launchDistanceKm, 0, 'f', 1);
            p.drawText(launchPt + QPointF(15, -12), launchTxt);
        }
    }

    // 7. 2D Flight Trajectory Trail Across Map
    if (showTrajectory_ && history_.size() >= 2) {
        for (std::size_t i = 1; i < history_.size(); ++i) {
            QPointF p1 = geoToScreen(history_[i - 1].geo.lat, history_[i - 1].geo.lon);
            QPointF p2 = geoToScreen(history_[i].geo.lat, history_[i].geo.lon);

            const float progress = static_cast<float>(i) / static_cast<float>(history_.size());
            const QColor segColor = QColor::fromHsvF(0.33f * (1.0f - progress) + 0.08f * progress, 0.95f, 1.0f);

            p.setPen(QPen(segColor, 3.2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            p.drawLine(p1, p2);

            // Directional Chevron Arrow every 15 waypoints
            if (i % 15 == 0) {
                const double dx = p2.x() - p1.x();
                const double dy = p2.y() - p1.y();
                const double len = std::sqrt(dx * dx + dy * dy);
                if (len > 1.0) {
                    const double ux = dx / len;
                    const double uy = dy / len;
                    const double vx = -uy;
                    const double vy = ux;
                    QPolygonF arrow;
                    arrow << p2
                          << QPointF(p2.x() - ux * 8 + vx * 4, p2.y() - uy * 8 + vy * 4)
                          << QPointF(p2.x() - ux * 8 - vx * 4, p2.y() - uy * 8 - vy * 4);
                    p.setBrush(segColor);
                    p.setPen(Qt::NoPen);
                    p.drawPolygon(arrow);
                }
            }
        }
    }

    // 8. Current Target Reticle & Telemetry Callout Box
    if (currentState_.hasValidSolution) {
        QPointF tgtPt = geoToScreen(currentState_.targetGeo.lat, currentState_.targetGeo.lon);
        if (mapRect_.contains(tgtPt)) {
            // Target Reticle
            p.setPen(QPen(QColor(255, 230, 0), 2));
            p.setBrush(QColor(255, 80, 0, 240));
            p.drawEllipse(tgtPt, 6.0, 6.0);
            p.drawEllipse(tgtPt, 11.0, 11.0);
            p.setPen(QPen(QColor(255, 255, 255), 1.5));
            p.drawLine(tgtPt.x() - 10, tgtPt.y(), tgtPt.x() + 10, tgtPt.y());
            p.drawLine(tgtPt.x(), tgtPt.y() - 10, tgtPt.x(), tgtPt.y() + 10);

            // Heading Vector Line
            const double headingRad = (90.0 - currentState_.headingDeg) * DEG2RAD;
            const double vecLen = std::max(20.0, currentState_.speedGround * 1.5);
            QPointF vecEnd(tgtPt.x() + vecLen * std::cos(headingRad),
                           tgtPt.y() - vecLen * std::sin(headingRad));
            p.setPen(QPen(QColor(0, 255, 200), 2, Qt::SolidLine));
            p.drawLine(tgtPt, vecEnd);

            // Floating Telemetry Callout Box
            const QString tagText = QString("TARGET #1 (AIRSPACE)\nAlt:   %1 m (%2 ft)\nRange: %3 km\nSpeed: %4 m/s (%5 km/h)\nClimb: %6 m/s\nCoord: %7°N, %8°E")
                                        .arg(static_cast<int>(currentState_.upMeters))
                                        .arg(static_cast<int>(currentState_.upMeters * 3.28084))
                                        .arg(currentState_.rangeMeters / 1000.0, 0, 'f', 2)
                                        .arg(currentState_.speedTotal, 0, 'f', 1)
                                        .arg(currentState_.speedTotal * 3.6, 0, 'f', 1)
                                        .arg((currentState_.climbRate >= 0 ? "+" : "") + QString::number(currentState_.climbRate, 'f', 1))
                                        .arg(currentState_.targetGeo.lat, 0, 'f', 3)
                                        .arg(currentState_.targetGeo.lon, 0, 'f', 3);

            const int boxW = 190;
            const int boxH = 92;
            const int boxX = (tgtPt.x() + boxW + 20 < w) ? (tgtPt.x() + 16) : (tgtPt.x() - boxW - 16);
            const int boxY = std::max(15, std::min(h - boxH - 15, static_cast<int>(tgtPt.y()) - boxH / 2));

            p.setBrush(QColor(10, 16, 24, 230));
            p.setPen(QPen(QColor(0, 240, 255), 1.2));
            p.drawRect(boxX, boxY, boxW, boxH);

            p.setPen(QColor(0, 240, 255));
            p.setFont(QFont("Monospace", 8, QFont::Bold));
            p.drawText(boxX + 8, boxY + 16, tagText);
        }
    }

    // 9. Top Tactical HUD Bar
    p.setBrush(QColor(10, 16, 24, 220));
    p.setPen(QPen(QColor(0, 220, 255, 120), 1));
    p.drawRect(12, 10, 480, 26);

    p.setPen(QColor(0, 240, 255));
    p.setFont(QFont("Monospace", 8, QFont::Bold));
    p.drawText(20, 27, "🗺️ 2D TACTICAL AIRSPACE MAP | INDIAN SUB-CONTINENT | REAL-TIME");

    // 10. Inset Altitude Profile Sparkline (Bottom-Right)
    if (!history_.empty()) {
        const int spkW = 175;
        const int spkH = 65;
        const int spkX = w - spkW - 16;
        const int spkY = h - spkH - 35;

        p.fillRect(spkX, spkY, spkW, spkH, QColor(10, 16, 24, 220));
        p.setPen(QPen(QColor(0, 220, 255, 100), 1));
        p.drawRect(spkX, spkY, spkW, spkH);

        p.setFont(QFont("Monospace", 7, QFont::Bold));
        p.setPen(QColor(0, 240, 255));
        p.drawText(spkX + 6, spkY + 12, "ALTITUDE SPARKLINE (m)");

        double maxAlt = 500.0;
        for (const auto& pt : history_) maxAlt = std::max(maxAlt, pt.alt);

        QPolygonF sparkLine;
        for (std::size_t i = 0; i < history_.size(); ++i) {
            const double fx = static_cast<double>(i) / std::max(1.0, static_cast<double>(history_.size() - 1));
            const double sx = spkX + 6 + fx * (spkW - 12);
            const double fy = std::clamp(history_[i].alt / maxAlt, 0.0, 1.0);
            const double sy = spkY + spkH - 6 - fy * (spkH - 22);
            sparkLine << QPointF(sx, sy);
        }
        p.setPen(QPen(QColor(0, 255, 180), 1.5));
        p.drawPolyline(sparkLine);
    }

    // 11. Scale Bar (Bottom-Left)
    const double scaleBarKm = 200.0;
    const double scaleBarPx = metersToPixels(scaleBarKm * 1000.0, 20.0);
    const int scaleX = 20;
    const int scaleY = h - 22;

    p.setPen(QPen(QColor(255, 255, 255), 2));
    p.drawLine(scaleX, scaleY, scaleX + static_cast<int>(scaleBarPx), scaleY);
    p.drawLine(scaleX, scaleY - 4, scaleX, scaleY + 4);
    p.drawLine(scaleX + static_cast<int>(scaleBarPx), scaleY - 4, scaleX + static_cast<int>(scaleBarPx), scaleY + 4);

    p.setPen(QColor(220, 240, 255));
    p.setFont(QFont("Monospace", 8));
    p.drawText(scaleX + 5, scaleY - 6, QString("%1 km Scale").arg(static_cast<int>(scaleBarKm)));

    // 12. Navigation Guide
    p.setPen(QColor(120, 160, 190));
    p.setFont(QFont("Monospace", 8));
    p.drawText(scaleX + static_cast<int>(scaleBarPx) + 20, scaleY - 6,
               QString("2D NAVIGATION: Drag to Pan | Wheel to Zoom (%1x)").arg(zoom_, 0, 'f', 2));

    // 13. Compass Rose (Top-Right)
    const int compassX = w - 35;
    const int compassY = 35;
    p.setPen(QPen(QColor(0, 240, 255), 1.5));
    p.setBrush(QColor(10, 16, 24, 200));
    p.drawEllipse(QPoint(compassX, compassY), 18, 18);

    p.setPen(QPen(QColor(255, 60, 60), 2.2));
    p.drawLine(compassX, compassY + 10, compassX, compassY - 12);
    p.setPen(QColor(255, 80, 80));
    p.setFont(QFont("Monospace", 8, QFont::Bold));
    p.drawText(compassX - 3, compassY - 14, "N");
}

void MapCanvas2D::mousePressEvent(QMouseEvent* event) {
    lastMousePos_ = event->pos();
}

void MapCanvas2D::mouseMoveEvent(QMouseEvent* event) {
    if (event->buttons() & (Qt::LeftButton | Qt::RightButton | Qt::MiddleButton)) {
        const QPoint delta = event->pos() - lastMousePos_;
        panOffset_ += delta;
        updateMapRect();
        update();
    }
    lastMousePos_ = event->pos();
}

void MapCanvas2D::wheelEvent(QWheelEvent* event) {
    const double numDegrees = event->angleDelta().y() / 8.0;
    const double numSteps = numDegrees / 15.0;
    const double oldZoom = zoom_;
    zoom_ = std::clamp(zoom_ + numSteps * 0.15, 0.5, 12.0);

    const QPointF mousePos = event->position();
    const QPointF center(width() * 0.5, height() * 0.5);
    panOffset_ = (panOffset_ + center - mousePos) * (zoom_ / oldZoom) + mousePos - center;

    updateMapRect();
    update();
}
