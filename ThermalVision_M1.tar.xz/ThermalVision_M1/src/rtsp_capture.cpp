#include "rtsp_capture.hpp"

#include <gst/gst.h>
#include <gst/video/video.h>
#include <gst/app/gstappsink.h>
#include <gst/video/video.h>
#include <cstring>
#include <filesystem>
#include <sstream>

RtspCapture::~RtspCapture() {
    stop();
}

bool RtspCapture::start(const std::string& url) {
    if (running_.load()) return true;

    {
        std::lock_guard<std::mutex> lock(mutex_);
        error_.clear();
        latest_.release();
    }

    gst_init(nullptr, nullptr);
    running_.store(true);
    worker_ = std::thread(&RtspCapture::captureLoop, this, url);
    return true;
}

void RtspCapture::stop() {
    running_.store(false);
    if (worker_.joinable()) worker_.join();
}

bool RtspCapture::latestFrame(cv::Mat& frame) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (latest_.empty()) return false;
    latest_.copyTo(frame);
    return true;
}

std::string RtspCapture::errorMessage() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return error_;
}

void RtspCapture::captureLoop(std::string url) {
    const bool isLive = (url.rfind("rtsp://", 0) == 0 || url.rfind("rtsps://", 0) == 0);

    // If local file, resolve and verify existence
    if (!isLive) {
        if (!std::filesystem::exists(url)) {
            // Check fallback in datasets/input/
            std::filesystem::path p(url);
            std::filesystem::path fallback = std::filesystem::path("datasets/input") / p.filename();
            if (std::filesystem::exists(fallback)) {
                url = fallback.string();
            } else {
                std::lock_guard<std::mutex> lock(mutex_);
                error_ = "File not found: " + url;
                running_.store(false);
                return;
            }
        }
    }

    // Accept either an RTSP URL or a local file path.
    std::ostringstream pipelineText;
    if (isLive) {
        pipelineText
            << "rtspsrc location=\"" << url
            << "\" protocols=tcp latency=150 ! "
            << "decodebin ! videoconvert ! "
            << "video/x-raw,format=BGR ! "
            << "appsink name=framesink sync=false max-buffers=1 drop=true";
    } else {
        GError* uriError = nullptr;
        gchar* fileUri = gst_filename_to_uri(url.c_str(), &uriError);
        if (!fileUri) {
            std::lock_guard<std::mutex> lock(mutex_);
            error_ = uriError ? uriError->message : "Could not convert file path to URI";
            if (uriError) g_error_free(uriError);
            running_.store(false);
            return;
        }
        pipelineText
            << "uridecodebin uri=\"" << fileUri
            << "\" ! videoconvert ! "
            << "video/x-raw,format=BGR ! "
            << "appsink name=framesink sync=true max-buffers=2 drop=false";
        g_free(fileUri);
    }

    GError* parseError = nullptr;
    GstElement* pipeline = gst_parse_launch(pipelineText.str().c_str(), &parseError);

    if (!pipeline) {
        std::lock_guard<std::mutex> lock(mutex_);
        error_ = parseError ? parseError->message : "Could not create GStreamer pipeline";
        if (parseError) g_error_free(parseError);
        running_.store(false);
        return;
    }
    if (parseError) g_error_free(parseError);

    GstElement* sinkElement = gst_bin_get_by_name(GST_BIN(pipeline), "framesink");
    if (!sinkElement) {
        std::lock_guard<std::mutex> lock(mutex_);
        error_ = "Could not find appsink element";
        gst_object_unref(pipeline);
        running_.store(false);
        return;
    }

    GstBus* bus = gst_element_get_bus(pipeline);
    GstAppSink* sink = GST_APP_SINK(sinkElement);
    gst_element_set_state(pipeline, GST_STATE_PLAYING);

    while (running_.load()) {
        if (bus) {
            GstMessage* msg = gst_bus_pop_filtered(bus, static_cast<GstMessageType>(GST_MESSAGE_ERROR));
            if (msg) {
                GError* gerr = nullptr;
                gchar* debug = nullptr;
                gst_message_parse_error(msg, &gerr, &debug);
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    error_ = gerr ? gerr->message : "GStreamer pipeline error";
                }
                if (gerr) g_error_free(gerr);
                if (debug) g_free(debug);
                gst_message_unref(msg);
                break;
            }
        }

        GstSample* sample = gst_app_sink_try_pull_sample(
            sink, 100 * GST_MSECOND);

        if (!sample) {
            if (gst_app_sink_is_eos(sink)) {
                if (!isLive) {
                    // Loop local test file
                    gst_element_seek_simple(
                        pipeline,
                        GST_FORMAT_TIME,
                        static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_KEY_UNIT),
                        0);
                    continue;
                }
                std::lock_guard<std::mutex> lock(mutex_);
                if (error_.empty()) {
                    error_ = "End of stream reached";
                }
                break;
            }
            continue;
        }

        GstCaps* caps = gst_sample_get_caps(sample);
        GstVideoInfo info;
        gst_video_info_init(&info);

        if (!caps || !gst_video_info_from_caps(&info, caps)) {
            gst_sample_unref(sample);
            continue;
        }

        GstBuffer* buffer = gst_sample_get_buffer(sample);
        GstMapInfo map;
        if (buffer && gst_buffer_map(buffer, &map, GST_MAP_READ)) {
            const int width = static_cast<int>(GST_VIDEO_INFO_WIDTH(&info));
            const int height = static_cast<int>(GST_VIDEO_INFO_HEIGHT(&info));
            const int stride = GST_VIDEO_INFO_PLANE_STRIDE(&info, 0);
            cv::Mat view(height, width, CV_8UC3,
                         map.data + GST_VIDEO_INFO_PLANE_OFFSET(&info, 0),
                         static_cast<std::size_t>(stride));

            {
                std::lock_guard<std::mutex> lock(mutex_);
                view.copyTo(latest_);
            }
            gst_buffer_unmap(buffer, &map);
        }

        gst_sample_unref(sample);
    }

    if (bus) gst_object_unref(bus);
    gst_element_set_state(pipeline, GST_STATE_NULL);
    gst_object_unref(sinkElement);
    gst_object_unref(pipeline);
    running_.store(false);
}
