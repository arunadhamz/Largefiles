#include "kinematic_engine.hpp"

#include <cmath>
#include <algorithm>

namespace {
constexpr double PI = 3.14159265358979323846;
constexpr double DEG2RAD = PI / 180.0;
constexpr double RAD2DEG = 180.0 / PI;
constexpr double EARTH_RADIUS_M = 6371000.0;
constexpr double PHYSICAL_DIAMETER_M = 2.4; // 2.4 meter meteorological balloon envelope
constexpr double FOCAL_LENGTH_PX = 1758.0;   // Focal length for 40 deg HFOV on 1280px width
}

KinematicEngine::KinematicEngine() {
    // Default sensor station: Sriharikota / SDSC SHAR tracking center
    setSensorLocation(13.7200, 80.2300, 18.0, "SDSC SHAR Tracking Station");
}

void KinematicEngine::setSensorLocation(double latDeg, double lonDeg, double altMeters, const std::string& name) {
    sensorGeo_.lat = latDeg;
    sensorGeo_.lon = lonDeg;
    sensorGeo_.alt = altMeters;
    sensorName_ = name;
    reset();
}

void KinematicEngine::reset() {
    initialized_ = false;
    history_.clear();
    sessionTime_ = 0.0;
    prevEast_ = 0.0;
    prevNorth_ = 0.0;
    prevUp_ = 0.0;
    filteredVelEast_ = 0.0;
    filteredVelNorth_ = 0.0;
    filteredVelUp_ = 5.2;
    estimatedAltitude_ = 800.0;
}

GeoPoint KinematicEngine::enuToGeo(double eastM, double northM, double upM) const {
    GeoPoint pt;
    const double dLat = (northM / EARTH_RADIUS_M) * RAD2DEG;
    const double cosLat = std::cos(sensorGeo_.lat * DEG2RAD);
    const double dLon = (eastM / (EARTH_RADIUS_M * (std::abs(cosLat) > 1e-6 ? cosLat : 1.0))) * RAD2DEG;

    pt.lat = sensorGeo_.lat + dLat;
    pt.lon = sensorGeo_.lon + dLon;
    pt.alt = sensorGeo_.alt + upM;
    return pt;
}

KinematicState KinematicEngine::process(double azimuthDeg,
                                        double elevationDeg,
                                        double detectedPixelWidth,
                                        double dt,
                                        bool isTracking) {
    KinematicState state;
    state.azimuthDeg = azimuthDeg;
    state.elevationDeg = elevationDeg;

    if (!isTracking || dt <= 0.0) {
        state.hasValidSolution = false;
        return state;
    }

    sessionTime_ += dt;

    // 1. Passive Ranging Derivation
    // Method A: Stadiametric Passive Range
    const double pxW = std::max(6.0, detectedPixelWidth);
    const double rangeStadiametric = (PHYSICAL_DIAMETER_M * FOCAL_LENGTH_PX) / pxW;

    // Method B: Barometric / Ascent Rate Passive Range
    // For standard meteorological balloons, vertical ascent speed is ~5.2 m/s
    estimatedAltitude_ += filteredVelUp_ * dt;
    const double elevationRad = std::max(2.0 * DEG2RAD, elevationDeg * DEG2RAD);
    const double rangeElevation = (estimatedAltitude_ - sensorGeo_.alt) / std::sin(elevationRad);

    // Fused passive range estimate (weighted blend)
    const double range = 0.65 * rangeStadiametric + 0.35 * std::max(100.0, rangeElevation);
    state.rangeMeters = range;

    // 2. 3D Cartesian Position in East-North-Up (ENU)
    const double azRad = azimuthDeg * DEG2RAD;
    const double cosEl = std::cos(elevationRad);
    const double east = range * cosEl * std::sin(azRad);
    const double north = range * cosEl * std::cos(azRad);
    const double up = range * std::sin(elevationRad);

    state.eastMeters = east;
    state.northMeters = north;
    state.upMeters = up;

    // 3. Velocity & Kinematics Derivation (Filtered Differentiation)
    if (!initialized_) {
        prevEast_ = east;
        prevNorth_ = north;
        prevUp_ = up;
        filteredVelEast_ = 12.5; // Typical tropospheric wind drift
        filteredVelNorth_ = 6.2;
        filteredVelUp_ = 5.2;
        initialized_ = true;
    } else {
        const double rawVe = std::clamp((east - prevEast_) / dt, -45.0, 45.0);
        const double rawVn = std::clamp((north - prevNorth_) / dt, -45.0, 45.0);
        const double rawVu = std::clamp((up - prevUp_) / dt, 1.0, 15.0);

        // Exponential smoothing filter
        const double alpha = std::min(1.0, 3.0 * dt);
        filteredVelEast_ = (1.0 - alpha) * filteredVelEast_ + alpha * rawVe;
        filteredVelNorth_ = (1.0 - alpha) * filteredVelNorth_ + alpha * rawVn;
        filteredVelUp_ = (1.0 - alpha) * filteredVelUp_ + alpha * rawVu;

        prevEast_ = east;
        prevNorth_ = north;
        prevUp_ = up;
    }

    state.velEast = filteredVelEast_;
    state.velNorth = filteredVelNorth_;
    state.velUp = filteredVelUp_;
    state.climbRate = filteredVelUp_;
    state.speedGround = std::sqrt(state.velEast * state.velEast + state.velNorth * state.velNorth);
    state.speedTotal = std::sqrt(state.speedGround * state.speedGround + state.velUp * state.velUp);

    state.flightPathAngleDeg = std::atan2(state.velUp, state.speedGround) * RAD2DEG;
    double heading = std::atan2(state.velEast, state.velNorth) * RAD2DEG;
    if (heading < 0.0) heading += 360.0;
    state.headingDeg = heading;

    // 4. Geodetic Coordinates (WGS-84)
    state.targetGeo = enuToGeo(east, north, up);

    // 5. Launch / Release Point Derivation (Back-projection to ground Z = 0)
    // Time elapsed since release = current altitude / average ascent climb rate
    const double climbRate = std::max(2.0, state.velUp);
    const double timeSinceReleaseSec = (up > 0.0) ? (up / climbRate) : 0.0;
    const double launchEast = east - state.velEast * timeSinceReleaseSec;
    const double launchNorth = north - state.velNorth * timeSinceReleaseSec;

    state.estimatedLaunchGeo = enuToGeo(launchEast, launchNorth, 0.0);

    // Distance from sensor station to launch site in kilometers
    const double distM = std::sqrt(launchEast * launchEast + launchNorth * launchNorth);
    state.launchDistanceKm = distM / 1000.0;

    state.hasValidSolution = true;

    // Record 3D Trajectory History
    TrajectoryPoint3D pt;
    pt.east = east;
    pt.north = north;
    pt.alt = up;
    pt.geo = state.targetGeo;
    pt.timestamp = sessionTime_;
    history_.push_back(pt);
    if (history_.size() > 250) {
        history_.erase(history_.begin());
    }

    return state;
}
