#include "cuda_processor.hpp"

#include <cuda_runtime.h>
#include <algorithm>
#include <cstdio>

__global__ void enhanceBgrKernel(const unsigned char* input,
                                 unsigned char* output,
                                 int totalBytes,
                                 float contrast,
                                 float brightness) {
    const int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < totalBytes) {
        const float value = (static_cast<float>(input[i]) - 127.5f) * contrast
                          + 127.5f + brightness;
        const float clipped = fminf(255.0f, fmaxf(0.0f, value));
        output[i] = static_cast<unsigned char>(clipped + 0.5f);
    }
}

CudaProcessor::CudaProcessor() = default;

CudaProcessor::~CudaProcessor() {
    if (d_input_) cudaFree(d_input_);
    if (d_output_) cudaFree(d_output_);
}

bool CudaProcessor::ensureCapacity(std::size_t bytes) {
    if (bytes <= capacity_) return true;

    if (d_input_) cudaFree(d_input_);
    if (d_output_) cudaFree(d_output_);
    d_input_ = nullptr;
    d_output_ = nullptr;
    capacity_ = 0;

    cudaError_t err = cudaMalloc(reinterpret_cast<void**>(&d_input_), bytes);
    if (err != cudaSuccess) {
        std::snprintf(error_, sizeof(error_), "cudaMalloc input: %s",
                      cudaGetErrorString(err));
        return false;
    }

    err = cudaMalloc(reinterpret_cast<void**>(&d_output_), bytes);
    if (err != cudaSuccess) {
        std::snprintf(error_, sizeof(error_), "cudaMalloc output: %s",
                      cudaGetErrorString(err));
        cudaFree(d_input_);
        d_input_ = nullptr;
        return false;
    }

    capacity_ = bytes;
    return true;
}

bool CudaProcessor::processBgr(const std::uint8_t* input,
                               std::uint8_t* output,
                               int width,
                               int height,
                               float contrast,
                               float brightness) {
    if (!input || !output || width <= 0 || height <= 0) {
        std::snprintf(error_, sizeof(error_), "Invalid input frame");
        return false;
    }

    const std::size_t bytes =
        static_cast<std::size_t>(width) * height * 3U;

    if (!ensureCapacity(bytes)) return false;

    cudaError_t err = cudaMemcpy(d_input_, input, bytes, cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        std::snprintf(error_, sizeof(error_), "H2D copy: %s",
                      cudaGetErrorString(err));
        return false;
    }

    constexpr int threads = 256;
    const int blocks = static_cast<int>((bytes + threads - 1) / threads);

    enhanceBgrKernel<<<blocks, threads>>>(
        d_input_, d_output_, static_cast<int>(bytes), contrast, brightness);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        std::snprintf(error_, sizeof(error_), "CUDA kernel launch: %s",
                      cudaGetErrorString(err));
        return false;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        std::snprintf(error_, sizeof(error_), "CUDA kernel execution: %s",
                      cudaGetErrorString(err));
        return false;
    }

    err = cudaMemcpy(output, d_output_, bytes, cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        std::snprintf(error_, sizeof(error_), "D2H copy: %s",
                      cudaGetErrorString(err));
        return false;
    }

    error_[0] = '\0';
    return true;
}

const char* CudaProcessor::lastError() const {
    return error_;
}
