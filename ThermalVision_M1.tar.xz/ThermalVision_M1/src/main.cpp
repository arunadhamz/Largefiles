#include "main_window.hpp"

#include <QApplication>
#include <QMessageBox>

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);

    if (argc < 2) {
        QMessageBox::information(
            nullptr,
            "ThermalVision M1",
            "Usage:\n  thermalvision rtsp://user:password@camera-ip:554/stream\n\n"
            "For local testing, use the sample RTSP stream instructions in README.md."
        );
        return 0;
    }

    MainWindow window(QString::fromLocal8Bit(argv[1]));
    window.show();
    return app.exec();
}
