# ThermalVision M1

A starter C++17 / CUDA / Qt 6 / GStreamer RTSP viewer for benign thermal-video
research. It decodes H.264/H.265 streams to BGR, applies a simple CUDA contrast
operation, and displays the result in Qt.

## Important input limitation

This M1 path decodes ordinary RTSP video to 8-bit BGR. It does not preserve
radiometric temperature values. For scientific temperature measurements, use a
camera/SDK/stream that exposes calibrated radiometric data and implement a
separate data path for that format.

## Dependencies

Tested design target:
- Ubuntu 22.04
- GCC 11+
- CMake 3.24+
- CUDA Toolkit compatible with installed NVIDIA driver
- Qt 6 Widgets
- OpenCV 4 (core)
- GStreamer 1.0 development packages and plugins

Install common packages:

```bash
sudo apt update
sudo apt install -y build-essential cmake git pkg-config ninja-build \
  qt6-base-dev libopencv-dev \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  gstreamer1.0-tools gstreamer1.0-plugins-base \
  gstreamer1.0-plugins-good gstreamer1.0-plugins-bad \
  gstreamer1.0-libav
```

Install the NVIDIA driver and CUDA Toolkit using NVIDIA's official instructions:
https://developer.nvidia.com/cuda-downloads

Check:

```bash
nvidia-smi
nvcc --version
pkg-config --modversion gstreamer-1.0
pkg-config --modversion opencv4
```

## Identify the GPU architecture

Run:

```bash
nvidia-smi --query-gpu=name,compute_cap --format=csv
```

If the driver does not support `compute_cap` on your setup, identify the exact
GPU model and look up its CUDA compute capability in NVIDIA's GPU documentation.

Configure CMake with the matching architecture, for example:

```bash
cmake -S . -B build -G Ninja -DCMAKE_CUDA_ARCHITECTURES=86
```

Replace `86` with the architecture for your actual GPU. Do not assume this
example matches your hardware.

## Build

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CUDA_ARCHITECTURES=86

cmake --build build -j"$(nproc)"
```

Run:

```bash
./build/thermalvision "rtsp://USER:PASSWORD@CAMERA_IP:554/STREAM_PATH"
```

Avoid putting production camera credentials in shell history. For lab testing,
use a dedicated test account/network.

## Test GStreamer independently

Inspect available plugins:

```bash
gst-inspect-1.0 rtspsrc
gst-inspect-1.0 decodebin
gst-inspect-1.0 avdec_h264
gst-inspect-1.0 avdec_h265
```

Test a stream without the application:

```bash
gst-launch-1.0 -v \
  rtspsrc location="rtsp://USER:PASSWORD@CAMERA_IP:554/STREAM_PATH" \
    protocols=tcp latency=150 ! \
  decodebin ! videoconvert ! \
  video/x-raw,format=BGR ! \
  fakesink sync=false
```

For H.264/H.265 decoding, the required decoder plugin must be installed.
`decodebin` chooses an available decoder; this starter does not force a
particular NVIDIA hardware decoder.

## Test checklist

1. Confirm `nvidia-smi` sees the intended GPU.
2. Confirm `nvcc --version` works.
3. Confirm GStreamer can connect to the RTSP stream.
4. Confirm the negotiated frame dimensions are 1280 x 1024.
5. Launch the Qt application and verify video appears.
6. Confirm the status line reports CUDA processing time and display-loop FPS.
7. Disconnect the source and verify the application exits cleanly.

## Current M1 limitations

- Assumes decoded BGR frames.
- No radiometric temperature calibration.
- No camera discovery or vendor-specific camera control.
- Uses a simple synchronous CUDA copy/kernel/copy path as a correctness baseline.
- No recording, object detector, or tracking module yet.
- The capture worker uses a simple appsink pull loop; production reconnect,
  cancellation and bus-error handling should be added before field deployment.

## Troubleshooting

### `No package 'gstreamer-app-1.0' found`

Install `libgstreamer-plugins-base1.0-dev`.

### `CUDA compiler identification is unknown`

Check that the NVIDIA driver and CUDA Toolkit are correctly installed and that
`nvcc` is on PATH.

### `no kernel image is available`

Reconfigure with the correct `CMAKE_CUDA_ARCHITECTURES` for your GPU, delete
the build directory, and rebuild.

### Video connects but no frames appear

Test the RTSP URL with `gst-launch-1.0`, verify the camera's stream path and
codec, and inspect installed decoder plugins.

### Wrong colors or image corruption

Check the negotiated caps and stride. This starter requests BGR from
`videoconvert`; confirm the actual camera stream and GStreamer negotiation.


## Local synthetic video input

The application accepts a local video path as well as an RTSP URL:

```bash
./build/thermalvision /path/to/synthetic_clouds_weather_balloon_1280x1024_h264.mp4
```

This is useful before purchasing a thermal camera. The supplied synthetic clips
are monochrome thermal-style visualizations only; they are not calibrated
temperature data and should not be interpreted as real thermal measurements.
