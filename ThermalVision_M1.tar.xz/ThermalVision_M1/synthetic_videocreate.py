#!/usr/bin/env python3
"""Generate synthetic monochrome thermal-style cloud, weather balloon, and high-speed missile boost test clips.

Physical & Thermal Simulation Parameters Modeled:
1. Speed & Kinematic Parameters:
   - Mach Velocity (M): Climbs from M=0.85 (263 m/s) at launch to M=6.4 (1984 m/s) at burnout.
   - Burn-Out Velocity (V_bo): Maximum velocity achieved at engine cutoff (t = t_bo = 6.2s).
   - Acceleration/G-Force (a): Increases from 6.2g to 14.8g during boost due to propellant mass burn-off.

2. Heat & Radiant Emission Parameters:
   - Plume Radiant Intensity (J_plume): 1.8e5 to 4.5e5 W/sr during boost (exhaust at 1,800°C to 2,400°C)
     creating core saturation (value 255), surrounding optical bloom halo, and supersonic Mach shock diamonds.
   - Skin Aero-Heating Temperature (T_skin): Stagnation shockwave heating superheats the nose cone
     to 600°C - 1,600°C, creating a prominent thermal hot-spot at the leading edge.
   - Spectral Emissivity (epsilon): Surface emissivity (0.88) defining radiant contrast against clouds.

3. Movement & Trajectory Factors:
   - Apogee (H_ap): High-altitude ballistic arc aiming for >300 km apogee.
   - Flight Path Angle (gamma): Launches steep at 78° through cloud deck and executes gravity-turn pitch-over to 26°.
   - Precession & Scintillation Rate (omega): Plume flutter at 22 Hz (scintillation) and body pitch nutation at 2.2 Hz.

Compatible with Python 3 + NumPy + Pillow (PIL) or OpenCV (cv2) + FFmpeg.
"""

from pathlib import Path
import numpy as np
import subprocess
import argparse
import math
import csv
import sys

# Dual engine support: OpenCV if installed, or native Pillow (PIL)
HAVE_CV2 = False
try:
    import cv2
    HAVE_CV2 = True
except ImportError:
    from PIL import Image, ImageDraw, ImageFilter

base = Path(__file__).resolve().parent
out_dir = base / "datasets" / "input"
out_dir.mkdir(parents=True, exist_ok=True)

W, H, FPS, SECONDS = 1280, 1024, 24, 8
N = FPS * SECONDS
T_BO = 6.2  # Rocket motor burnout time (seconds)
rng = np.random.default_rng(20261105)

def make_field(seed, h, w):
    r = np.random.default_rng(seed)
    return r.random((h, w), dtype=np.float32)

# Multi-scale smooth noise fields for realistic cloudy sky
scales = [
    (make_field(11, 5, 7), 0.48, 0.35, 0.60),
    (make_field(22, 9, 13), 0.25, 0.65, 0.85),
    (make_field(33, 18, 25), 0.17, 1.10, 1.20),
    (make_field(44, 36, 50), 0.10, 1.65, 1.70),
]

def cloud_frame(t):
    """Render multi-scale thermal cloud field with atmospheric drift and sensor grain."""
    layers = []
    for field, weight, sx, sy in scales:
        small_h, small_w = field.shape
        shift_x = int((t * sx * small_w * 0.32) % small_w)
        shift_y = int((t * sy * small_h * 0.18) % small_h)
        shifted = np.roll(np.roll(field, shift_y, axis=0), shift_x, axis=1)

        if HAVE_CV2:
            up = cv2.resize(shifted, (W, H), interpolation=cv2.INTER_CUBIC)
        else:
            im_s = Image.fromarray(shifted)
            im_l = im_s.resize((W, H), getattr(getattr(Image, 'Resampling', Image), 'BICUBIC', Image.BICUBIC))
            up = np.array(im_l, dtype=np.float32)

        layers.append((up - 0.5) * weight)

    n = sum(layers)

    if HAVE_CV2:
        n = cv2.GaussianBlur(n, (0, 0), 5.0)
    else:
        n_min, n_max = float(n.min()), float(n.max())
        n_u8 = np.clip((n - n_min) / (n_max - n_min + 1e-6) * 255.0, 0, 255).astype(np.uint8)
        im_n = Image.fromarray(n_u8, mode="L").filter(ImageFilter.GaussianBlur(radius=5.0))
        n = (np.array(im_n, dtype=np.float32) / 255.0) * (n_max - n_min) + n_min

    # Broad thermal altitude bands
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    band = 0.12 * np.sin((yy / H * 2.8) + t * 0.10 + 0.5 * np.sin(xx / W * 4.0))
    n = n + band

    # Soft contrast curve: thermal cloud masses on dark upper sky
    lo, hi = np.percentile(n, 8), np.percentile(n, 98)
    z = np.clip((n - lo) / (hi - lo + 1e-6), 0, 1)
    z = np.power(z, 0.82)
    gray = (18 + 205 * z).astype(np.uint8)

    # Sensor fixed pattern and temporal noise
    grain = rng.normal(0, 1.8, (H, W)).astype(np.float32)
    gray = np.clip(gray.astype(np.float32) + grain, 0, 255).astype(np.uint8)
    return gray

def draw_balloon(gray, t):
    """Draw civilian meteorological aerostat payload drifting smoothly."""
    cx = int(W * (0.24 + 0.48 * (t / SECONDS)))
    cy = int(H * (0.42 + 0.035 * math.sin(t * 0.7)))

    if HAVE_CV2:
        frame = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        glow = np.zeros((H, W), dtype=np.uint8)
        cv2.circle(glow, (cx, cy), 34, 70, -1, cv2.LINE_AA)
        glow = cv2.GaussianBlur(glow, (0, 0), 18)
        frame = cv2.add(frame, cv2.cvtColor(glow, cv2.COLOR_GRAY2BGR))

        # Balloon envelope
        cv2.ellipse(frame, (cx, cy), (13, 19), -8, 0, 360, (248, 248, 248), -1, cv2.LINE_AA)
        cv2.ellipse(frame, (cx, cy), (13, 19), -8, 0, 360, (190, 190, 190), 1, cv2.LINE_AA)
        cv2.line(frame, (cx - 7, cy + 15), (cx + 7, cy + 15), (100, 100, 100), 1, cv2.LINE_AA)
        # Tether and payload
        cv2.line(frame, (cx, cy + 19), (cx + 2, cy + 39), (225, 225, 225), 1, cv2.LINE_AA)
        cv2.rectangle(frame, (cx - 3, cy + 39), (cx + 4, cy + 46), (235, 235, 235), -1)
        return frame
    else:
        im = Image.fromarray(gray).convert("RGB")
        glow_im = Image.new("L", (W, H), 0)
        draw_glow = ImageDraw.Draw(glow_im)
        draw_glow.ellipse([cx - 34, cy - 34, cx + 34, cy + 34], fill=70)
        glow_im = glow_im.filter(ImageFilter.GaussianBlur(radius=18.0))

        glow_arr = np.array(glow_im, dtype=np.uint16)
        im_arr = np.array(im, dtype=np.uint16)
        for c in range(3):
            im_arr[:, :, c] = np.clip(im_arr[:, :, c] + glow_arr, 0, 255)
        im = Image.fromarray(im_arr.astype(np.uint8))

        draw = ImageDraw.Draw(im)
        draw.ellipse([cx - 13, cy - 19, cx + 13, cy + 19], fill=(248, 248, 248), outline=(190, 190, 190))
        draw.line([(cx - 7, cy + 15), (cx + 7, cy + 15)], fill=(100, 100, 100), width=1)
        draw.line([(cx, cy + 19), (cx + 2, cy + 39)], fill=(225, 225, 225), width=1)
        draw.rectangle([cx - 3, cy + 39, cx + 4, cy + 46], fill=(235, 235, 235))
        return np.array(im, dtype=np.uint8)

def compute_missile_trajectory():
    """Pre-integrate 2D trajectory positions and physical kinematics across all frames."""
    dt = 1.0 / FPS
    traj = []
    x, y = 140.0, 940.0
    v_px = 35.0

    for step in range(N):
        t = step * dt
        # Flight path angle gamma(t): steep initial launch (78°), pitch-over to 26°
        gamma_deg = 78.0 - (78.0 - 26.0) * math.pow(t / SECONDS, 1.15)
        gamma_rad = math.radians(gamma_deg)

        # Acceleration and velocity
        is_boost = (t < T_BO)
        if is_boost:
            # Propellant mass burn-off causes acceleration to rise from 6.2g to 14.8g
            a_g = 6.2 + (14.8 - 6.2) * (t / T_BO)
            a_px = 16.0 + 20.0 * (t / T_BO)
            mach = 0.85 + (6.4 - 0.85) * (t / T_BO)
            v_mps = mach * 310.0
            j_plume = (1.8 + 2.7 * (t / T_BO)) * 1e5  # W/sr
        else:
            # Post-burnout: engine shuts off, coasts at burnout velocity V_bo
            a_g = 0.0
            a_px = -6.0  # Slight aero-drag in pixel space
            mach = 6.40
            v_mps = 1984.0  # V_bo = 1984 m/s
            j_plume = 0.0

        # Compressive shock aero-heating stagnation temperature
        # T_skin rises from ambient (~25°C) to 1,600°C+ at hypersonic speeds
        t_skin_c = 25.0 + 115.0 * math.pow(mach, 1.48)

        v_px += a_px * dt
        vx = v_px * math.cos(gamma_rad)
        vy = -v_px * math.sin(gamma_rad)

        x += vx * dt
        y += vy * dt

        traj.append({
            "step": step,
            "t": t,
            "x": x,
            "y": y,
            "vx": vx,
            "vy": vy,
            "v_px": v_px,
            "v_mps": v_mps,
            "mach": mach,
            "a_g": a_g,
            "gamma_deg": gamma_deg,
            "gamma_rad": gamma_rad,
            "j_plume": j_plume,
            "t_skin_c": t_skin_c,
            "is_boost": is_boost,
        })
    return traj

# Precomputed trajectory
MISSILE_TRAJ = compute_missile_trajectory()

def draw_missile(gray, step):
    """Draw high-speed rocket/missile with plume radiance, Mach shock diamonds, and aero-heating."""
    st = MISSILE_TRAJ[step]
    t = st["t"]
    x, y = st["x"], st["y"]
    gamma_rad = st["gamma_rad"]
    is_boost = st["is_boost"]
    mach = st["mach"]
    j_plume = st["j_plume"]

    # Trajectory heading direction + precession / pitch nutation wobble
    heading_rad = math.atan2(-math.sin(gamma_rad), math.cos(gamma_rad))
    prec_wobble = 0.015 * math.sin(2.0 * math.pi * 2.2 * t)
    heading_rad += prec_wobble

    ux = math.cos(heading_rad)
    uy = math.sin(heading_rad)
    vx = -uy
    vy = ux

    # Dimensions in pixel space
    body_len = 46.0
    body_r = 5.0
    nose_len = 16.0

    p_base_x = x - (body_len * 0.5) * ux
    p_base_y = y - (body_len * 0.5) * uy
    p_sh_x = x + (body_len * 0.5) * ux
    p_sh_y = y + (body_len * 0.5) * uy
    p_nose_x = p_sh_x + nose_len * ux
    p_nose_y = p_sh_y + nose_len * uy

    # 1. Base image setup
    if HAVE_CV2:
        frame = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    else:
        im = Image.fromarray(gray).convert("RGB")

    # 2. Exhaust Plume Radiant Bloom / Optical Halo (Boost Phase)
    scint = 1.0 + 0.08 * math.sin(2.0 * math.pi * 22.0 * t)  # 22 Hz plume scintillation
    if is_boost:
        halo_r = int(58.0 * (j_plume / 4.5e5) * scint + 12.0)
        halo_intensity = int(175 * scint)

        if HAVE_CV2:
            glow = np.zeros((H, W), dtype=np.uint8)
            cv2.circle(glow, (int(p_base_x), int(p_base_y)), halo_r, min(255, halo_intensity), -1, cv2.LINE_AA)
            glow = cv2.GaussianBlur(glow, (0, 0), 22)
            frame = cv2.add(frame, cv2.cvtColor(glow, cv2.COLOR_GRAY2BGR))
        else:
            bloom_im = Image.new("L", (W, H), 0)
            draw_bloom = ImageDraw.Draw(bloom_im)
            draw_bloom.ellipse([p_base_x - halo_r, p_base_y - halo_r,
                                p_base_x + halo_r, p_base_y + halo_r], fill=min(255, halo_intensity))
            bloom_im = bloom_im.filter(ImageFilter.GaussianBlur(radius=22.0))
            b_arr = np.array(bloom_im, dtype=np.uint16)
            im_arr = np.array(im, dtype=np.uint16)
            for c in range(3):
                im_arr[:, :, c] = np.clip(im_arr[:, :, c] + b_arr, 0, 255)
            im = Image.fromarray(im_arr.astype(np.uint8))

    # 3. Draw Plume Flame Core & Mach Diamonds
    if is_boost:
        plume_len = (78.0 + 26.0 * (t / T_BO)) * scint
        plume_w = 9.5 * scint
        p_tip_x = p_base_x - plume_len * ux
        p_tip_y = p_base_y - plume_len * uy

        p_outer = [
            (p_base_x + plume_w * 0.75 * vx, p_base_y + plume_w * 0.75 * vy),
            (p_base_x - plume_w * 0.75 * vx, p_base_y - plume_w * 0.75 * vy),
            (p_tip_x - plume_w * 0.35 * vx, p_tip_y - plume_w * 0.35 * vy),
            (p_tip_x, p_tip_y),
            (p_tip_x + plume_w * 0.35 * vx, p_tip_y + plume_w * 0.35 * vy),
        ]
        p_core = [
            (p_base_x + plume_w * 0.45 * vx, p_base_y + plume_w * 0.45 * vy),
            (p_base_x - plume_w * 0.45 * vx, p_base_y - plume_w * 0.45 * vy),
            (p_base_x - plume_len * 0.65 * ux, p_base_y - plume_len * 0.65 * uy),
        ]

        if HAVE_CV2:
            pts_out = np.array([[(int(px), int(py)) for px, py in p_outer]], dtype=np.int32)
            cv2.fillPoly(frame, pts_out, (230, 245, 255), cv2.LINE_AA)
            pts_core = np.array([[(int(px), int(py)) for px, py in p_core]], dtype=np.int32)
            cv2.fillPoly(frame, pts_core, (255, 255, 255), cv2.LINE_AA)
            for k in range(1, 4):
                dx = int(p_base_x - (k * 18.0) * ux)
                dy = int(p_base_y - (k * 18.0) * uy)
                cv2.circle(frame, (dx, dy), 3, (255, 255, 255), -1, cv2.LINE_AA)
        else:
            draw = ImageDraw.Draw(im)
            draw.polygon(p_outer, fill=(230, 245, 255))
            draw.polygon(p_core, fill=(255, 255, 255))
            for k in range(1, 4):
                dx = p_base_x - (k * 18.0) * ux
                dy = p_base_y - (k * 18.0) * uy
                draw.ellipse([dx - 3, dy - 3, dx + 3, dy + 3], fill=(255, 255, 255))
    else:
        # Residual cooling nozzle after engine cutoff
        cooling = max(0.0, 1.0 - (t - T_BO) / 1.6)
        if cooling > 0:
            c_val = int(140 * cooling)
            if HAVE_CV2:
                cv2.circle(frame, (int(p_base_x), int(p_base_y)), 3, (c_val, c_val, c_val), -1, cv2.LINE_AA)
            else:
                draw = ImageDraw.Draw(im)
                draw.ellipse([p_base_x - 3, p_base_y - 3, p_base_x + 3, p_base_y + 3],
                             fill=(c_val, c_val, c_val))

    # 4. Missile Body & Stabilizing Fins
    body_poly = [
        (p_base_x + body_r * vx, p_base_y + body_r * vy),
        (p_base_x - body_r * vx, p_base_y - body_r * vy),
        (p_sh_x - body_r * vx, p_sh_y - body_r * vy),
        (p_sh_x + body_r * vx, p_sh_y + body_r * vy),
    ]
    fin_span = 12.0
    fin1 = [
        (p_base_x, p_base_y),
        (p_base_x + fin_span * vx - 6.0 * ux, p_base_y + fin_span * vy - 6.0 * uy),
        (p_base_x + fin_span * vx, p_base_y + fin_span * vy),
        (p_base_x + 8.0 * ux, p_base_y + 8.0 * uy),
    ]
    fin2 = [
        (p_base_x, p_base_y),
        (p_base_x - fin_span * vx - 6.0 * ux, p_base_y - fin_span * vy - 6.0 * uy),
        (p_base_x - fin_span * vx, p_base_y - fin_span * vy),
        (p_base_x + 8.0 * ux, p_base_y + 8.0 * uy),
    ]

    # Stagnation aero-heated nosecone
    nose_poly = [
        (p_sh_x + body_r * vx, p_sh_y + body_r * vy),
        (p_sh_x - body_r * vx, p_sh_y - body_r * vy),
        (p_nose_x, p_nose_y),
    ]

    if HAVE_CV2:
        cv2.fillPoly(frame, np.array([[(int(px), int(py)) for px, py in fin1]], dtype=np.int32), (150, 150, 150), cv2.LINE_AA)
        cv2.fillPoly(frame, np.array([[(int(px), int(py)) for px, py in fin2]], dtype=np.int32), (150, 150, 150), cv2.LINE_AA)
        cv2.fillPoly(frame, np.array([[(int(px), int(py)) for px, py in body_poly]], dtype=np.int32), (185, 185, 185), cv2.LINE_AA)
        cv2.polylines(frame, np.array([[(int(px), int(py)) for px, py in body_poly]], dtype=np.int32), True, (215, 215, 215), 1, cv2.LINE_AA)
        cv2.fillPoly(frame, np.array([[(int(px), int(py)) for px, py in nose_poly]], dtype=np.int32), (245, 245, 245), cv2.LINE_AA)
        cv2.circle(frame, (int(p_nose_x), int(p_nose_y)), 3, (255, 255, 255), -1, cv2.LINE_AA)
        return frame
    else:
        draw = ImageDraw.Draw(im)
        draw.polygon(fin1, fill=(150, 150, 150))
        draw.polygon(fin2, fill=(150, 150, 150))
        draw.polygon(body_poly, fill=(185, 185, 185), outline=(215, 215, 215))
        draw.polygon(nose_poly, fill=(245, 245, 245), outline=(255, 255, 255))
        draw.ellipse([p_nose_x - 3, p_nose_y - 3, p_nose_x + 3, p_nose_y + 3], fill=(255, 255, 255))
        return np.array(im, dtype=np.uint8)

def save_kinematics_csv(path):
    """Save full timestamped kinematic and radiometric telemetry log to CSV."""
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "time_s", "frame_idx", "x_px", "y_px", "mach", "velocity_mps",
            "acceleration_g", "flight_path_angle_deg", "plume_radiant_intensity_wsr",
            "skin_temp_celsius", "emissivity", "phase"
        ])
        for row in MISSILE_TRAJ:
            writer.writerow([
                f"{row['t']:.4f}",
                row["step"],
                f"{row['x']:.2f}",
                f"{row['y']:.2f}",
                f"{row['mach']:.2f}",
                f"{row['v_mps']:.1f}",
                f"{row['a_g']:.2f}",
                f"{row['gamma_deg']:.2f}",
                f"{row['j_plume']:.1f}",
                f"{row['t_skin_c']:.1f}",
                "0.88",
                "BOOST" if row["is_boost"] else "BURNOUT_COAST"
            ])
    print(f"  -> Saved kinematics CSV: {path.name}")

def encode_video(path, target_type):
    """Encode synthetic thermal stream to H.264 MP4 using FFmpeg pipe."""
    print(f"Generating: {path.name} ({SECONDS}s @ {FPS}fps, {W}x{H}, target={target_type})...")
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error",
        "-f", "rawvideo", "-pix_fmt", "bgr24",
        "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
        "-an", "-c:v", "libx264", "-preset", "veryfast",
        "-crf", "20", "-pix_fmt", "yuv420p",
        "-movflags", "+faststart", str(path)
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for i in range(N):
            t = i / FPS
            g = cloud_frame(t)

            if target_type == "missile":
                frame = draw_missile(g, i)
            elif target_type == "balloon":
                frame = draw_balloon(g, t)
            else:
                if HAVE_CV2:
                    frame = cv2.cvtColor(g, cv2.COLOR_GRAY2BGR)
                else:
                    frame = np.stack([g, g, g], axis=-1)

            proc.stdin.write(frame.tobytes())
    finally:
        proc.stdin.close()
    rc = proc.wait()
    if rc != 0:
        raise RuntimeError(f"ffmpeg failed with exit code {rc}")
    print(f"  -> Saved {path.name} ({path.stat().st_size / 1024 / 1024:.2f} MB)")

def main():
    parser = argparse.ArgumentParser(description="Synthetic Thermal Cloud and Aerial Target Video Generator")
    parser.add_argument("--target", choices=["missile", "balloon", "clouds", "all"], default="all",
                        help="Target type to generate (default: all)")
    args = parser.parse_args()

    engine_name = "OpenCV (cv2)" if HAVE_CV2 else "Pillow (PIL)"
    print(f"Rendering engine: {engine_name}")
    print(f"Output directory: {out_dir}")

    cloud_path = out_dir / "synthetic_clouds_only_1280x1024_h264.mp4"
    balloon_path = out_dir / "synthetic_clouds_weather_balloon_1280x1024_h264.mp4"
    missile_path = out_dir / "synthetic_clouds_missile_boost_1280x1024_h264.mp4"
    csv_path = out_dir / "synthetic_missile_kinematics.csv"

    if args.target in ("all", "missile"):
        save_kinematics_csv(csv_path)
        encode_video(missile_path, "missile")

    if args.target in ("all", "balloon"):
        encode_video(balloon_path, "balloon")

    if args.target in ("all", "clouds"):
        encode_video(cloud_path, "clouds")

    print("\nGeneration complete!")

if __name__ == "__main__":
    main()
