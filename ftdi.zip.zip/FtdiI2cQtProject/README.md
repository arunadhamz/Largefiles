# FTDI I2C Qt Project

This is a complete Qt Creator project template for communicating with an I2C slave device (Address 0x54) using an FTDI C232HM-EDHSL-0 cable on Windows.

## Setup Instructions

1. **Download the FTDI MPSSE Library:**
   - Go to the FTDI website and download the `libMPSSE-I2C` library for Windows.
   - Extract the contents.

2. **Configure the Project:**
   - Open `FtdiI2cQtProject.pro` in Qt Creator.
   - Uncomment the `INCLUDEPATH` and `LIBS` lines at the bottom of the `.pro` file.
   - Update the paths to point to the `include` directory (containing `libmpsse_i2c.h`) and `lib` directory (containing `libmpsse.lib`) from the extracted FTDI library.

3. **Deploy the DLL:**
   - Copy `libmpsse.dll` from the downloaded FTDI library into your Qt build folder (e.g., `build-FtdiI2cQtProject-Desktop_Qt_x_x_x_MSVC.../debug/` or `/release/`) right next to your generated `.exe` file. Without this, the application will crash on startup.

4. **Hardware Wiring (C232HM Cable):**
   - **Yellow:** SCL (I2C Clock)
   - **Orange & Green:** Tie these two wires together and connect to SDA (I2C Data)
   - **Black:** GND
