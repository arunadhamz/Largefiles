QT -= gui

CONFIG += c++11 console
CONFIG -= app_bundle

# The following define makes your compiler emit warnings if you use
# any feature of Qt which as been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

SOURCES +=         main.cpp

# --- FTDI MPSSE LIBRARY CONFIGURATION ---
# IMPORTANT: Adjust the paths below to point to where you extracted the FTDI libMPSSE-I2C files!

# Include path for libmpsse_i2c.h
# INCLUDEPATH += $$PWD/libMPSSE/include

# Link the static library (libmpsse.lib)
# LIBS += -L$$PWD/libMPSSE/lib -llibmpsse

# Note: Make sure libmpsse.dll is placed in your build directory (debug/release) 
# next to the generated .exe file so it can run.
