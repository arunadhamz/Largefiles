#include <QCoreApplication>
#include <QDebug>
#include <windows.h>
#include "libmpsse_i2c.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    qDebug() << "Initializing FTDI MPSSE I2C Engine...";

    // 1. Initialize the MPSSE library
    Init_libMPSSE();

    FT_HANDLE ftHandle;
    uint32_t channels = 0;
    
    // Check how many FTDI devices are connected
    I2C_GetNumChannels(&channels);
    if (channels == 0) {
        qDebug() << "No FTDI devices found. Please check connection and drivers.";
        return -1;
    }
    qDebug() << "Found" << channels << "FTDI device(s).";

    // 2. Open the first available channel (Index 0)
    FT_STATUS status = I2C_OpenChannel(0, &ftHandle);
    if (status != FT_OK) {
        qDebug() << "Failed to open FTDI channel. Error code:" << status;
        return -1;
    }

    // 3. Configure the I2C Channel
    ChannelConfig config;
    config.ClockRate = I2C_CLOCK_STANDARD_MODE; // 100kHz
    config.LatencyTimer = 255;
    config.Options = 0;
    status = I2C_InitChannel(ftHandle, &config);
    
    if (status != FT_OK) {
        qDebug() << "Failed to initialize I2C channel. Error code:" << status;
        I2C_CloseChannel(ftHandle);
        return -1;
    }
    qDebug() << "I2C Channel initialized successfully at 100kHz.";

    // 4. Write data to Slave Address 0x54 (7-bit)
    uint8_t slaveAddress = 0x54; 
    
    // Example: writing to register 0x01 the value 0xFF
    uint8_t writeBuffer[] = {0x01, 0xFF}; 
    uint32_t bytesToTransfer = sizeof(writeBuffer);
    uint32_t bytesTransferred = 0;

    // Use START and STOP bits for a standard I2C write frame
    uint32_t transferOptions = I2C_TRANSFER_OPTIONS_START_BIT | I2C_TRANSFER_OPTIONS_STOP_BIT;

    qDebug() << "Writing to slave address 0x54...";
    status = I2C_DeviceWrite(ftHandle, slaveAddress, bytesToTransfer, writeBuffer, &bytesTransferred, transferOptions);

    if (status == FT_OK) {
        qDebug() << "Success! Wrote" << bytesTransferred << "bytes to 0x54.";
    } else {
        qDebug() << "I2C Write failed with status:" << status;
    }

    // 5. Cleanup
    qDebug() << "Closing channel and cleaning up.";
    I2C_CloseChannel(ftHandle);
    Cleanup_libMPSSE();

    return a.exec();
}
